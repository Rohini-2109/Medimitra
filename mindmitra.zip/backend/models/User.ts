/**
 * MongoDB / Mongoose Schema representation for MediMitra User
 */
export interface IUser {
  _id?: string;
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  age: number;
  gender: 'male' | 'female' | 'non-binary' | 'prefer-not-to-say';
  bloodGroup: string;
  allergies: string[];
  existingConditions: string[];
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  locationConsent: boolean;
  preferredRegion: string;
  createdAt: Date;
  updatedAt: Date;
}

export const UserSchemaDefinition = {
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  age: { type: Number, required: true, min: 1, max: 125 },
  gender: { type: String, enum: ['male', 'female', 'non-binary', 'prefer-not-to-say'], default: 'prefer-not-to-say' },
  bloodGroup: { type: String, default: 'Not specified' },
  allergies: { type: [String], default: [] },
  existingConditions: { type: [String], default: [] },
  emergencyContact: {
    name: { type: String, required: true },
    phone: { type: String, required: true },
    relationship: { type: String, required: true },
  },
  locationConsent: { type: Boolean, default: false },
  preferredRegion: { type: String, default: 'IN' },
};
