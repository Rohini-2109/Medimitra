/**
 * MongoDB / Mongoose Schema representation for Wellness Tracking
 * (Sleep, Water, Physical Activity, Daily Notes)
 */
export interface IWellnessLog {
  _id?: string;
  id: string;
  userId: string;
  date: string;
  sleepHours: number;
  sleepQuality: 'poor' | 'fair' | 'good' | 'excellent';
  waterIntakeMl: number;
  waterTargetMl: number;
  physicalActivityMinutes: number;
  stepsCount: number;
  notes?: string;
  createdAt: Date;
}

export const WellnessLogSchemaDefinition = {
  userId: { type: String, required: true, index: true },
  date: { type: String, required: true, index: true },
  sleepHours: { type: Number, default: 7 },
  sleepQuality: { type: String, enum: ['poor', 'fair', 'good', 'excellent'], default: 'good' },
  waterIntakeMl: { type: Number, default: 0 },
  waterTargetMl: { type: Number, default: 2500 },
  physicalActivityMinutes: { type: Number, default: 0 },
  stepsCount: { type: Number, default: 0 },
  notes: { type: String, default: '' },
};
