/**
 * MongoDB / Mongoose Schema representation for Simulated Smart Ambulance Coordination
 * Prototypes emergency dispatch and traffic control corridor management.
 */
export interface IAmbulanceDispatch {
  _id?: string;
  id: string;
  userId: string;
  patientName: string;
  callerPhone: string;
  status: 'dispatched' | 'en_route' | 'arrived' | 'cancelled';
  origin: {
    lat: number;
    lng: number;
    address: string;
  };
  destinationHospital: {
    id: string;
    name: string;
    address: string;
    phone: string;
    lat: number;
    lng: number;
  };
  currentLocation: {
    lat: number;
    lng: number;
  };
  etaMinutes: number;
  currentJunctionIndex: number;
  junctions: {
    id: string;
    name: string;
    status: 'cleared' | 'approaching' | 'pending';
    distanceMeters: number;
    trafficLevel: 'green' | 'yellow' | 'red';
    clearedAt?: string;
  }[];
  routeCoordinates: [number, number][];
  trafficCondition: 'clear' | 'moderate' | 'heavy';
  priority: 'CRITICAL' | 'URGENT';
  alertMessage: string;
  alertAcknowledgedByControl: boolean;
  acknowledgedAt?: string;
  greenCorridorActive: boolean;
  createdAt: Date;
}

export const AmbulanceDispatchSchemaDefinition = {
  userId: { type: String, required: true },
  patientName: { type: String, required: true },
  callerPhone: { type: String, required: true },
  status: {
    type: String,
    enum: ['dispatched', 'en_route', 'arrived', 'cancelled'],
    default: 'dispatched',
  },
  origin: {
    lat: Number,
    lng: Number,
    address: String,
  },
  destinationHospital: {
    id: String,
    name: String,
    address: String,
    phone: String,
    lat: Number,
    lng: Number,
  },
  currentLocation: {
    lat: Number,
    lng: Number,
  },
  etaMinutes: { type: Number, default: 8 },
  currentJunctionIndex: { type: Number, default: 0 },
  junctions: [
    {
      id: String,
      name: String,
      status: { type: String, enum: ['cleared', 'approaching', 'pending'] },
      distanceMeters: Number,
      trafficLevel: { type: String, enum: ['green', 'yellow', 'red'] },
      clearedAt: String,
    },
  ],
  routeCoordinates: [[Number]],
  trafficCondition: { type: String, enum: ['clear', 'moderate', 'heavy'], default: 'moderate' },
  priority: { type: String, enum: ['CRITICAL', 'URGENT'], default: 'CRITICAL' },
  alertMessage: String,
  alertAcknowledgedByControl: { type: Boolean, default: false },
  acknowledgedAt: String,
  greenCorridorActive: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
};
