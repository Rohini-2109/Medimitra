/**
 * MongoDB / Mongoose Schema representation for Prescribed Medicine
 * Strict rule: User can add medicines ONLY from a doctor's prescription.
 * MediMitra does not independently prescribe or recommend medicines.
 */
export interface IMedicine {
  _id?: string;
  id: string;
  userId: string;
  medicineName: string;
  dosage: string;
  doctorName: string;
  prescriptionDate: string;
  timing: ('Morning' | 'Afternoon' | 'Evening' | 'Night')[];
  instruction: 'Before Food' | 'After Food' | 'With Food' | 'As Needed';
  durationDays: number;
  startDate: string;
  active: boolean;
  notes?: string;
  history: {
    date: string;
    takenAt: string;
    timingSlot: string;
    status: 'taken' | 'skipped';
  }[];
  createdAt: Date;
}

export const MedicineSchemaDefinition = {
  userId: { type: String, required: true, index: true },
  medicineName: { type: String, required: true, trim: true },
  dosage: { type: String, required: true },
  doctorName: { type: String, required: true },
  prescriptionDate: { type: String, required: true },
  timing: {
    type: [String],
    enum: ['Morning', 'Afternoon', 'Evening', 'Night'],
    required: true,
  },
  instruction: {
    type: String,
    enum: ['Before Food', 'After Food', 'With Food', 'As Needed'],
    default: 'After Food',
  },
  durationDays: { type: Number, required: true, min: 1 },
  startDate: { type: String, required: true },
  active: { type: Boolean, default: true },
  notes: { type: String, default: '' },
  history: [
    {
      date: String,
      takenAt: String,
      timingSlot: String,
      status: { type: String, enum: ['taken', 'skipped'] },
    },
  ],
};
