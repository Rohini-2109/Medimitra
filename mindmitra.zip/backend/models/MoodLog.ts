/**
 * MongoDB / Mongoose Schema representation for Mental Well-being Mood Log
 */
export interface IMoodLog {
  _id?: string;
  id: string;
  userId: string;
  mood: 'great' | 'good' | 'neutral' | 'anxious' | 'sad' | 'stressed';
  score: number; // 1-5
  stressLevel: number; // 1-10
  emotions: string[];
  journalNote: string;
  date: string;
  timestamp: number;
  createdAt: Date;
}

export const MoodLogSchemaDefinition = {
  userId: { type: String, required: true, index: true },
  mood: {
    type: String,
    enum: ['great', 'good', 'neutral', 'anxious', 'sad', 'stressed'],
    required: true,
  },
  score: { type: Number, required: true, min: 1, max: 5 },
  stressLevel: { type: Number, required: true, min: 1, max: 10 },
  emotions: { type: [String], default: [] },
  journalNote: { type: String, default: '' },
  date: { type: String, required: true, index: true },
  timestamp: { type: Number, required: true },
};
