/**
 * MongoDB / Mongoose Schema representation for Verified Doctor / Clinic Directory
 * Clearly marked verified demo dataset for testing.
 */
export interface IDoctorClinic {
  _id?: string;
  id: string;
  name: string;
  type: 'Doctor' | 'Clinic' | 'Hospital' | 'Emergency Center';
  specialization: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  lat: number;
  lng: number;
  timings: string;
  rating: number;
  isEmergencyFacility: boolean;
  emergencyPhone?: string;
  verifiedDemo: boolean;
}

export const DoctorClinicSchemaDefinition = {
  name: { type: String, required: true },
  type: {
    type: String,
    enum: ['Doctor', 'Clinic', 'Hospital', 'Emergency Center'],
    required: true,
  },
  specialization: { type: String, required: true },
  phone: { type: String, required: true },
  address: { type: String, required: true },
  city: { type: String, required: true },
  state: { type: String, required: true },
  lat: { type: Number, required: true },
  lng: { type: Number, required: true },
  timings: { type: String, required: true },
  rating: { type: Number, default: 4.5 },
  isEmergencyFacility: { type: Boolean, default: false },
  emergencyPhone: { type: String },
  verifiedDemo: { type: Boolean, default: true },
};
