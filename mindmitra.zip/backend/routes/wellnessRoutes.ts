import { Router, Response } from 'express';
import crypto from 'crypto';
import { db } from '../services/storage.ts';
import { requireAuth, AuthenticatedRequest } from '../middleware/auth.ts';
import { IWellnessLog } from '../models/WellnessLog.ts';

const router = Router();

// Get today's wellness log
router.get('/today', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const userId = req.userId!;
  const todayStr = new Date().toISOString().split('T')[0];

  let todayLog: IWellnessLog | undefined;
  for (const log of db.wellnessLogs.values()) {
    if (log.userId === userId && log.date === todayStr) {
      todayLog = log;
      break;
    }
  }

  if (!todayLog) {
    return res.json({ wellness: null });
  }

  return res.json({ wellness: todayLog });
});

// Get wellness history
router.get('/history', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const userId = req.userId!;
  const logs: IWellnessLog[] = [];

  for (const log of db.wellnessLogs.values()) {
    if (log.userId === userId) {
      logs.push(log);
    }
  }

  logs.sort((a, b) => b.date.localeCompare(a.date));
  return res.json({ logs });
});

// Update or log wellness data
router.post('/log', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.userId!;
    const {
      date,
      sleepHours,
      sleepQuality,
      waterIntakeMl,
      waterTargetMl,
      physicalActivityMinutes,
      stepsCount,
      notes,
    } = req.body;

    const targetDate = date || new Date().toISOString().split('T')[0];

    let existingLog: IWellnessLog | undefined;
    for (const log of db.wellnessLogs.values()) {
      if (log.userId === userId && log.date === targetDate) {
        existingLog = log;
        break;
      }
    }

    if (existingLog) {
      if (sleepHours !== undefined) existingLog.sleepHours = Number(sleepHours);
      if (sleepQuality !== undefined) existingLog.sleepQuality = sleepQuality;
      if (waterIntakeMl !== undefined) existingLog.waterIntakeMl = Number(waterIntakeMl);
      if (waterTargetMl !== undefined) existingLog.waterTargetMl = Number(waterTargetMl);
      if (physicalActivityMinutes !== undefined)
        existingLog.physicalActivityMinutes = Number(physicalActivityMinutes);
      if (stepsCount !== undefined) existingLog.stepsCount = Number(stepsCount);
      if (notes !== undefined) existingLog.notes = notes;

      db.wellnessLogs.set(existingLog.id, existingLog);
      return res.json({ message: 'Wellness log updated', wellness: existingLog });
    } else {
      const newLog: IWellnessLog = {
        id: 'well_' + crypto.randomUUID(),
        userId,
        date: targetDate,
        sleepHours: Number(sleepHours) || 7,
        sleepQuality: sleepQuality || 'good',
        waterIntakeMl: Number(waterIntakeMl) || 0,
        waterTargetMl: Number(waterTargetMl) || 2500,
        physicalActivityMinutes: Number(physicalActivityMinutes) || 0,
        stepsCount: Number(stepsCount) || 0,
        notes: notes || '',
        createdAt: new Date(),
      };
      db.wellnessLogs.set(newLog.id, newLog);
      return res.status(201).json({ message: 'Wellness log created', wellness: newLog });
    }
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to update wellness: ' + (err.message || 'Internal error') });
  }
});

export default router;
