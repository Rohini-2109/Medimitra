import { Router, Request, Response } from 'express';
import { db } from '../services/storage.ts';
import { IDoctorClinic } from '../models/DoctorClinic.ts';

const router = Router();

// Calculate distance in km using Haversine formula
function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the Earth in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

// Get nearby doctors/clinics/hospitals
router.get('/nearby', (req: Request, res: Response) => {
  try {
    const lat = req.query.lat ? parseFloat(req.query.lat as string) : 28.6289;
    const lng = req.query.lng ? parseFloat(req.query.lng as string) : 77.3758;
    const filter = (req.query.filter as string) || 'all';

    const results: (IDoctorClinic & { distanceKm: number })[] = [];

    for (const doc of db.doctors.values()) {
      if (filter !== 'all') {
        if (filter === 'emergency' && !doc.isEmergencyFacility) continue;
        if (filter === 'doctor' && doc.type !== 'Doctor') continue;
        if (filter === 'hospital' && doc.type !== 'Hospital') continue;
        if (filter === 'clinic' && doc.type !== 'Clinic') continue;
      }

      const dist = calculateDistanceKm(lat, lng, doc.lat, doc.lng);
      results.push({
        ...doc,
        distanceKm: dist,
      });
    }

    // Sort by distance
    results.sort((a, b) => a.distanceKm - b.distanceKm);

    return res.json({
      doctors: results,
      total: results.length,
      userCoordinates: { lat, lng },
      notice: 'Verified demo directory. Details are provided for clinical testing and simulation.',
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to fetch doctors: ' + (err.message || 'Internal error') });
  }
});

// Get emergency facilities only
router.get('/emergency', (_req: Request, res: Response) => {
  const emergencyHospitals: IDoctorClinic[] = [];
  for (const doc of db.doctors.values()) {
    if (doc.isEmergencyFacility) {
      emergencyHospitals.push(doc);
    }
  }
  return res.json({ facilities: emergencyHospitals });
});

export default router;
