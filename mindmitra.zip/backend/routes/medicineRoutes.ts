import { Router, Response } from 'express';
import crypto from 'crypto';
import { db } from '../services/storage.ts';
import { requireAuth, AuthenticatedRequest } from '../middleware/auth.ts';
import { IMedicine } from '../models/Medicine.ts';

const router = Router();

// Get all medicines for current user
router.get('/', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const userId = req.userId!;
  const userMeds: IMedicine[] = [];

  for (const med of db.medicines.values()) {
    if (med.userId === userId) {
      userMeds.push(med);
    }
  }

  return res.json({ medicines: userMeds });
});

// Add a doctor-prescribed medicine
// Strict requirement: only from doctor's prescription
router.post('/', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.userId!;
    const {
      medicineName,
      dosage,
      doctorName,
      prescriptionDate,
      timing,
      instruction,
      durationDays,
      startDate,
      notes,
    } = req.body;

    if (!medicineName || !dosage || !doctorName) {
      return res.status(400).json({
        error: 'Doctor name, medicine name, and dosage from a valid prescription are required.',
      });
    }

    if (!timing || !Array.isArray(timing) || timing.length === 0) {
      return res.status(400).json({
        error: 'Please select at least one prescribed timing slot (e.g. Morning, Night).',
      });
    }

    const newMed: IMedicine = {
      id: 'med_' + crypto.randomUUID(),
      userId,
      medicineName: medicineName.trim(),
      dosage: dosage.trim(),
      doctorName: doctorName.trim(),
      prescriptionDate: prescriptionDate || new Date().toISOString().split('T')[0],
      timing,
      instruction: instruction || 'After Food',
      durationDays: Number(durationDays) || 7,
      startDate: startDate || new Date().toISOString().split('T')[0],
      active: true,
      notes: notes || '',
      history: [],
      createdAt: new Date(),
    };

    db.medicines.set(newMed.id, newMed);

    return res.status(201).json({
      message: 'Prescribed medicine added successfully',
      medicine: newMed,
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to add medicine: ' + (err.message || 'Internal error') });
  }
});

// Mark dose as taken / skipped for a timing slot
router.post('/:id/take', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { date, timingSlot, status } = req.body;

    const med = db.medicines.get(id);
    if (!med || med.userId !== req.userId) {
      return res.status(404).json({ error: 'Medicine not found or unauthorized' });
    }

    const todayStr = date || new Date().toISOString().split('T')[0];
    const nowTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Filter out existing record for this slot and date if re-logging
    med.history = med.history.filter(
      (h) => !(h.date === todayStr && h.timingSlot === timingSlot)
    );

    med.history.push({
      date: todayStr,
      takenAt: nowTimeStr,
      timingSlot: timingSlot || 'Dose',
      status: status === 'skipped' ? 'skipped' : 'taken',
    });

    db.medicines.set(id, med);

    return res.json({
      message: `Dose marked as ${status === 'skipped' ? 'skipped' : 'taken'}`,
      medicine: med,
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to update dose: ' + (err.message || 'Internal error') });
  }
});

// Delete medicine
router.delete('/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const med = db.medicines.get(id);

  if (!med || med.userId !== req.userId) {
    return res.status(404).json({ error: 'Medicine not found or unauthorized' });
  }

  db.medicines.delete(id);
  return res.json({ message: 'Prescription removed successfully' });
});

export default router;
