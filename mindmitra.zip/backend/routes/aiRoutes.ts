import { Router, Response } from 'express';
import { optionalAuth, AuthenticatedRequest } from '../middleware/auth.ts';
import { generateHealthAssistantResponse, analyzeSymptoms } from '../services/aiService.ts';

const router = Router();

// Chat with AI Health Assistant
router.post('/chat', optionalAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { message, language } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message text is required.' });
    }

    let userSummary = '';
    if (req.user) {
      userSummary = `Age: ${req.user.age}, Allergies: ${req.user.allergies.join(', ') || 'None reported'}, Conditions: ${req.user.existingConditions.join(', ') || 'None reported'}`;
    }

    const response = await generateHealthAssistantResponse(message, userSummary, language || 'en');
    return res.json(response);
  } catch (err: any) {
    return res.status(500).json({ error: 'AI Assistant error: ' + (err.message || 'Internal error') });
  }
});

// Analyze Symptoms via Symptom Checker
router.post('/symptom-check', optionalAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { symptoms, duration, language } = req.body;
    if (!symptoms || typeof symptoms !== 'string') {
      return res.status(400).json({ error: 'Symptoms description is required.' });
    }

    const result = await analyzeSymptoms(symptoms, duration, language || 'en');
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: 'Symptom check error: ' + (err.message || 'Internal error') });
  }
});

export default router;
