import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { db } from '../services/storage.ts';
import { optionalAuth, AuthenticatedRequest } from '../middleware/auth.ts';
import { IAmbulanceDispatch } from '../models/AmbulanceDispatch.ts';

const router = Router();

// Activate a new simulated ambulance dispatch
router.post('/activate', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      patientName,
      callerPhone,
      originLat,
      originLng,
      originAddress,
      hospitalId,
    } = req.body;

    const user = req.user;
    const finalPatientName =
      patientName || (user ? user.name : 'Emergency Caller (Simulated)');
    const finalCallerPhone =
      callerPhone || (user ? user.emergencyContact.phone : '+91 98765 01234');

    const startLat = originLat ? parseFloat(originLat) : 28.6215;
    const startLng = originLng ? parseFloat(originLng) : 77.362;

    // Pick target hospital
    let destinationDoc = hospitalId ? db.doctors.get(hospitalId) : undefined;
    if (!destinationDoc) {
      // Pick first emergency hospital
      for (const d of db.doctors.values()) {
        if (d.isEmergencyFacility) {
          destinationDoc = d;
          break;
        }
      }
    }

    const hospital = destinationDoc || {
      id: 'doc_001',
      name: 'Metro Care Multispecialty & Emergency Hospital',
      address: '14, Healthcare Boulevard, Sector 62',
      phone: '+91 11 4567 8900',
      lat: 28.6289,
      lng: 77.3758,
    };

    // Synthesize realistic coordinates & junctions
    const mid1: [number, number] = [
      startLat + (hospital.lat - startLat) * 0.25,
      startLng + (hospital.lng - startLng) * 0.25,
    ];
    const mid2: [number, number] = [
      startLat + (hospital.lat - startLat) * 0.6,
      startLng + (hospital.lng - startLng) * 0.6,
    ];
    const mid3: [number, number] = [
      startLat + (hospital.lat - startLat) * 0.85,
      startLng + (hospital.lng - startLng) * 0.85,
    ];

    const routeCoordinates: [number, number][] = [
      [startLat, startLng],
      mid1,
      mid2,
      mid3,
      [hospital.lat, hospital.lng],
    ];

    const junctions = [
      {
        id: 'junc_' + crypto.randomUUID().slice(0, 5),
        name: 'Sector 59 Main Avenue Junction',
        status: 'approaching' as const,
        distanceMeters: 450,
        trafficLevel: 'yellow' as const,
      },
      {
        id: 'junc_' + crypto.randomUUID().slice(0, 5),
        name: 'MG Ring Road Expressway Flyover',
        status: 'pending' as const,
        distanceMeters: 1100,
        trafficLevel: 'green' as const,
      },
      {
        id: 'junc_' + crypto.randomUUID().slice(0, 5),
        name: 'Civil Hospital Ingress Crossroad',
        status: 'pending' as const,
        distanceMeters: 2300,
        trafficLevel: 'red' as const,
      },
    ];

    const dispatchId = 'amb_' + Math.floor(1000 + Math.random() * 9000);
    const alertMessage = `EMERGENCY AMBULANCE APPROACHING | ETA: 7 minutes | Next Junction: ${junctions[0].name} | Please facilitate emergency traffic movement.`;

    const newDispatch: IAmbulanceDispatch = {
      id: dispatchId,
      userId: user ? user.id : 'guest_' + crypto.randomUUID(),
      patientName: finalPatientName,
      callerPhone: finalCallerPhone,
      status: 'en_route',
      origin: {
        lat: startLat,
        lng: startLng,
        address: originAddress || 'Current User Geolocation',
      },
      destinationHospital: {
        id: hospital.id,
        name: hospital.name,
        address: hospital.address,
        phone: hospital.phone,
        lat: hospital.lat,
        lng: hospital.lng,
      },
      currentLocation: {
        lat: startLat,
        lng: startLng,
      },
      etaMinutes: 7,
      currentJunctionIndex: 0,
      junctions,
      routeCoordinates,
      trafficCondition: 'moderate',
      priority: 'CRITICAL',
      alertMessage,
      alertAcknowledgedByControl: false,
      greenCorridorActive: false,
      createdAt: new Date(),
    };

    db.ambulanceDispatches.set(newDispatch.id, newDispatch);

    return res.status(201).json({
      message: 'Emergency Ambulance Dispatched (Simulated Prototype)',
      dispatch: newDispatch,
      simulationNotice:
        'PROTOTYPE NOTICE: This is an internal emergency coordination simulation. No real emergency services or traffic police are dispatched.',
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to activate ambulance: ' + (err.message || 'Internal error') });
  }
});

// Get active ambulance dispatches (For Traffic Control Dashboard)
router.get('/active', (_req: Request, res: Response) => {
  const activeList: IAmbulanceDispatch[] = [];
  for (const item of db.ambulanceDispatches.values()) {
    if (item.status === 'dispatched' || item.status === 'en_route') {
      activeList.push(item);
    }
  }
  return res.json({ dispatches: activeList });
});

// Get specific ambulance status
router.get('/:id', (req: Request, res: Response) => {
  const dispatch = db.ambulanceDispatches.get(req.params.id);
  if (!dispatch) {
    return res.status(404).json({ error: 'Ambulance dispatch record not found' });
  }
  return res.json({ dispatch });
});

// Acknowledge alert and trigger Green Corridor (Traffic Control Dashboard Action)
router.post('/:id/ack-alert', (req: Request, res: Response) => {
  const dispatch = db.ambulanceDispatches.get(req.params.id);
  if (!dispatch) {
    return res.status(404).json({ error: 'Ambulance dispatch not found' });
  }

  dispatch.alertAcknowledgedByControl = true;
  dispatch.acknowledgedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  dispatch.greenCorridorActive = true;
  dispatch.trafficCondition = 'clear';

  // Mark current junction cleared if pending
  if (dispatch.junctions[dispatch.currentJunctionIndex]) {
    dispatch.junctions[dispatch.currentJunctionIndex].status = 'cleared';
    dispatch.junctions[dispatch.currentJunctionIndex].trafficLevel = 'green';
    dispatch.junctions[dispatch.currentJunctionIndex].clearedAt = dispatch.acknowledgedAt;
  }

  // Advance alert message
  const nextJunc = dispatch.junctions[dispatch.currentJunctionIndex + 1];
  if (nextJunc) {
    dispatch.alertMessage = `GREEN CORRIDOR ACTIVE | ETA: ${Math.max(1, dispatch.etaMinutes - 2)} minutes | Next Junction: ${nextJunc.name} | Signal Preemption Engaged.`;
  } else {
    dispatch.alertMessage = `GREEN CORRIDOR ACTIVE | Approaching Hospital Ingress. Traffic Cleared.`;
  }

  db.ambulanceDispatches.set(dispatch.id, dispatch);

  return res.json({
    message: 'Alert acknowledged. Green traffic corridor prioritized.',
    dispatch,
  });
});

// Simulate step forward along route & junctions
router.post('/:id/step', (req: Request, res: Response) => {
  const dispatch = db.ambulanceDispatches.get(req.params.id);
  if (!dispatch) {
    return res.status(404).json({ error: 'Ambulance dispatch not found' });
  }

  if (dispatch.etaMinutes > 1) {
    dispatch.etaMinutes -= 1;
  }

  if (dispatch.currentJunctionIndex < dispatch.junctions.length - 1) {
    dispatch.junctions[dispatch.currentJunctionIndex].status = 'cleared';
    dispatch.junctions[dispatch.currentJunctionIndex].trafficLevel = 'green';
    dispatch.currentJunctionIndex += 1;
    dispatch.junctions[dispatch.currentJunctionIndex].status = 'approaching';

    // Move current location closer to hospital
    const coordIdx = Math.min(dispatch.currentJunctionIndex + 1, dispatch.routeCoordinates.length - 1);
    dispatch.currentLocation = {
      lat: dispatch.routeCoordinates[coordIdx][0],
      lng: dispatch.routeCoordinates[coordIdx][1],
    };

    dispatch.alertMessage = `EMERGENCY AMBULANCE APPROACHING | ETA: ${dispatch.etaMinutes} mins | Next Junction: ${dispatch.junctions[dispatch.currentJunctionIndex].name} | Please facilitate emergency traffic movement.`;
  } else {
    dispatch.status = 'arrived';
    dispatch.etaMinutes = 0;
    dispatch.currentLocation = {
      lat: dispatch.destinationHospital.lat,
      lng: dispatch.destinationHospital.lng,
    };
    dispatch.alertMessage = `Ambulance arrived safely at ${dispatch.destinationHospital.name}. Emergency team notified.`;
  }

  db.ambulanceDispatches.set(dispatch.id, dispatch);
  return res.json({ message: 'Simulation step updated', dispatch });
});

// Cancel dispatch
router.post('/:id/cancel', (req: Request, res: Response) => {
  const dispatch = db.ambulanceDispatches.get(req.params.id);
  if (!dispatch) {
    return res.status(404).json({ error: 'Ambulance dispatch not found' });
  }
  dispatch.status = 'cancelled';
  db.ambulanceDispatches.set(dispatch.id, dispatch);
  return res.json({ message: 'Ambulance dispatch cancelled', dispatch });
});

export default router;
