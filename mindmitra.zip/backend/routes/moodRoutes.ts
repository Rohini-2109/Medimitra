import { Router, Response } from 'express';
import crypto from 'crypto';
import { db } from '../services/storage.ts';
import { requireAuth, AuthenticatedRequest } from '../middleware/auth.ts';
import { IMoodLog } from '../models/MoodLog.ts';

const router = Router();

// Get mood history for current user
router.get('/history', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const userId = req.userId!;
  const userLogs: IMoodLog[] = [];

  for (const log of db.moodLogs.values()) {
    if (log.userId === userId) {
      userLogs.push(log);
    }
  }

  // Sort by date descending
  userLogs.sort((a, b) => b.timestamp - a.timestamp);

  return res.json({ logs: userLogs });
});

// Log a new mood check-in
router.post('/log', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.userId!;
    const { mood, score, stressLevel, emotions, journalNote, date } = req.body;

    if (!mood) {
      return res.status(400).json({ error: 'Mood is required.' });
    }

    const todayDate = date || new Date().toISOString().split('T')[0];
    const newLog: IMoodLog = {
      id: 'mood_' + crypto.randomUUID(),
      userId,
      mood,
      score: Number(score) || 3,
      stressLevel: Number(stressLevel) || 3,
      emotions: Array.isArray(emotions) ? emotions : emotions ? [emotions] : [],
      journalNote: journalNote || '',
      date: todayDate,
      timestamp: Date.now(),
      createdAt: new Date(),
    };

    db.moodLogs.set(newLog.id, newLog);

    return res.status(201).json({
      message: 'Mood check-in logged successfully',
      log: newLog,
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to save mood log: ' + (err.message || 'Internal error') });
  }
});

// Delete a mood log entry
router.delete('/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const log = db.moodLogs.get(id);

  if (!log || log.userId !== req.userId) {
    return res.status(404).json({ error: 'Mood entry not found or unauthorized' });
  }

  db.moodLogs.delete(id);
  return res.json({ message: 'Mood entry deleted successfully' });
});

export default router;
