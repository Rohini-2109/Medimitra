import crypto from 'crypto';
import { IUser } from '../models/User.ts';
import { IMedicine } from '../models/Medicine.ts';
import { IMoodLog } from '../models/MoodLog.ts';
import { IWellnessLog } from '../models/WellnessLog.ts';
import { IDoctorClinic } from '../models/DoctorClinic.ts';
import { IAmbulanceDispatch } from '../models/AmbulanceDispatch.ts';

// Helper for hashing passwords
export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// In-Memory Data Store with optional MongoDB connection compatibility
class DataStore {
  public users: Map<string, IUser> = new Map();
  public medicines: Map<string, IMedicine> = new Map();
  public moodLogs: Map<string, IMoodLog> = new Map();
  public wellnessLogs: Map<string, IWellnessLog> = new Map();
  public doctors: Map<string, IDoctorClinic> = new Map();
  public ambulanceDispatches: Map<string, IAmbulanceDispatch> = new Map();

  constructor() {
    this.seedInitialData();
  }

  private seedInitialData() {
    // 1. Seed Demo User
    const demoUserId = 'user_demo_mindmitra_001';
    const demoUser: IUser = {
      id: demoUserId,
      name: 'Demo Patient',
      email: 'demo@medimitra.health',
      passwordHash: hashPassword('MediMitra@2026'),
      age: 28,
      gender: 'female',
      bloodGroup: 'O+ Positive',
      allergies: ['Penicillin'],
      existingConditions: ['Mild Asthma'],
      emergencyContact: {
        name: 'Emergency Contact',
        phone: '+91 98765 01234',
        relationship: 'Family Member',
      },
      locationConsent: true,
      preferredRegion: 'IN',
      createdAt: new Date('2026-01-15T09:00:00Z'),
      updatedAt: new Date(),
    };
    this.users.set(demoUser.id, demoUser);

    // 2. Seed Verified Doctor & Emergency Directory
    const seedDoctors: IDoctorClinic[] = [
      {
        id: 'doc_001',
        name: 'Metro Care Multispecialty & Emergency Hospital',
        type: 'Hospital',
        specialization: '24/7 Emergency, Trauma, Critical Care & Cardiology',
        phone: '+91 11 4567 8900',
        address: '14, Healthcare Boulevard, Sector 62',
        city: 'New Delhi / NCR',
        state: 'Delhi',
        lat: 28.6289,
        lng: 77.3758,
        timings: 'Open 24 Hours (Emergency Services Active)',
        rating: 4.8,
        isEmergencyFacility: true,
        emergencyPhone: '102 / 112',
        verifiedDemo: true,
      },
      {
        id: 'doc_002',
        name: 'Dr. Ananya Sen, MD',
        type: 'Doctor',
        specialization: 'Internal Medicine & General Physician',
        phone: '+91 98765 43210',
        address: 'Clinic 3B, Mediplex Towers, Ring Road',
        city: 'New Delhi / NCR',
        state: 'Delhi',
        lat: 28.6312,
        lng: 77.3715,
        timings: 'Mon - Sat: 09:30 AM - 01:30 PM, 05:00 PM - 08:30 PM',
        rating: 4.9,
        isEmergencyFacility: false,
        verifiedDemo: true,
      },
      {
        id: 'doc_003',
        name: 'Hope Mind Wellness & Psychiatry Clinic',
        type: 'Clinic',
        specialization: 'Mental Health, Anxiety, Depression & Psychotherapy',
        phone: '+91 98112 34567',
        address: 'Suite 204, Serenity House, Green Park Extension',
        city: 'New Delhi / NCR',
        state: 'Delhi',
        lat: 28.6255,
        lng: 77.3698,
        timings: 'Mon - Fri: 10:00 AM - 06:00 PM',
        rating: 4.7,
        isEmergencyFacility: false,
        verifiedDemo: true,
      },
      {
        id: 'doc_004',
        name: 'Apex Heart Institute & Cardiac Emergency',
        type: 'Hospital',
        specialization: 'Interventional Cardiology & Cardiac Emergency',
        phone: '+91 11 2685 4100',
        address: 'Plot 8, Institutional Area, Phase 2',
        city: 'New Delhi / NCR',
        state: 'Delhi',
        lat: 28.635,
        lng: 77.382,
        timings: 'Open 24 Hours',
        rating: 4.9,
        isEmergencyFacility: true,
        emergencyPhone: '+91 11 2685 4111',
        verifiedDemo: true,
      },
      {
        id: 'doc_005',
        name: 'Dr. Arvind Patel, DNB (Peds)',
        type: 'Doctor',
        specialization: 'Pediatrics & Adolescent Medicine',
        phone: '+91 98220 98765',
        address: 'Child Health Hub, B-Block Market',
        city: 'New Delhi / NCR',
        state: 'Delhi',
        lat: 28.622,
        lng: 77.378,
        timings: 'Mon - Sat: 10:00 AM - 02:00 PM',
        rating: 4.6,
        isEmergencyFacility: false,
        verifiedDemo: true,
      },
      {
        id: 'doc_006',
        name: 'City Orthopedic & Trauma Care Clinic',
        type: 'Clinic',
        specialization: 'Orthopedics, Fractures & Physical Therapy',
        phone: '+91 98334 56789',
        address: 'Ground Floor, Mobility Center, Main Road',
        city: 'New Delhi / NCR',
        state: 'Delhi',
        lat: 28.6375,
        lng: 77.368,
        timings: 'Mon - Sat: 09:00 AM - 07:00 PM',
        rating: 4.5,
        isEmergencyFacility: false,
        verifiedDemo: true,
      },
    ];
    seedDoctors.forEach((d) => this.doctors.set(d.id, d));

    // 3. Seed Prescribed Medicines (Strictly doctor prescribed)
    const seedMedicines: IMedicine[] = [
      {
        id: 'med_001',
        userId: demoUserId,
        medicineName: 'Amoxicillin 500mg',
        dosage: '1 Capsule',
        doctorName: 'Dr. Ananya Sen, MD',
        prescriptionDate: '2026-09-05',
        timing: ['Morning', 'Night'],
        instruction: 'After Food',
        durationDays: 7,
        startDate: '2026-09-06',
        active: true,
        notes: 'Prescribed for bacterial sinus infection. Complete entire course.',
        history: [
          { date: '2026-09-10', takenAt: '08:30 AM', timingSlot: 'Morning', status: 'taken' },
          { date: '2026-09-10', takenAt: '09:15 PM', timingSlot: 'Night', status: 'taken' },
          { date: '2026-09-11', takenAt: '08:45 AM', timingSlot: 'Morning', status: 'taken' },
        ],
        createdAt: new Date('2026-09-05'),
      },
      {
        id: 'med_002',
        userId: demoUserId,
        medicineName: 'Pantoprazole 40mg',
        dosage: '1 Tablet',
        doctorName: 'Dr. Ananya Sen, MD',
        prescriptionDate: '2026-09-05',
        timing: ['Morning'],
        instruction: 'Before Food',
        durationDays: 14,
        startDate: '2026-09-06',
        active: true,
        notes: 'Take 30 minutes before breakfast with a glass of water.',
        history: [
          { date: '2026-09-10', takenAt: '07:45 AM', timingSlot: 'Morning', status: 'taken' },
          { date: '2026-09-11', takenAt: '07:50 AM', timingSlot: 'Morning', status: 'taken' },
        ],
        createdAt: new Date('2026-09-05'),
      },
      {
        id: 'med_003',
        userId: demoUserId,
        medicineName: 'Montelukast & Levocetirizine',
        dosage: '1 Tablet',
        doctorName: 'Dr. Vikram Malhotra',
        prescriptionDate: '2026-08-20',
        timing: ['Night'],
        instruction: 'After Food',
        durationDays: 30,
        startDate: '2026-08-21',
        active: true,
        notes: 'For seasonal allergen protection and airway comfort.',
        history: [
          { date: '2026-09-10', takenAt: '10:00 PM', timingSlot: 'Night', status: 'taken' },
        ],
        createdAt: new Date('2026-08-20'),
      },
    ];
    seedMedicines.forEach((m) => this.medicines.set(m.id, m));

    // 4. Seed Mood History
    const sampleDates = [
      { date: '2026-09-06', mood: 'good', score: 4, stress: 3, note: 'Productive morning walk and healthy sleep.' },
      { date: '2026-09-07', mood: 'neutral', score: 3, stress: 5, note: 'Busy workday, felt slightly overwhelmed before lunch.' },
      { date: '2026-09-08', mood: 'anxious', score: 2, stress: 7, note: 'Mild headache and deadline pressure. Did 10 mins box breathing.' },
      { date: '2026-09-09', mood: 'good', score: 4, stress: 4, note: 'Better headspace after talking with a friend.' },
      { date: '2026-09-10', mood: 'great', score: 5, stress: 2, note: 'Felt very energized, hydrated well, 8 hours sleep.' },
      { date: '2026-09-11', mood: 'good', score: 4, stress: 3, note: 'Feeling balanced, focused on positive routine.' },
    ] as const;

    sampleDates.forEach((d, index) => {
      const moodId = `mood_00${index + 1}`;
      this.moodLogs.set(moodId, {
        id: moodId,
        userId: demoUserId,
        mood: d.mood,
        score: d.score,
        stressLevel: d.stress,
        emotions: d.mood === 'great' ? ['Grateful', 'Energetic'] : d.mood === 'good' ? ['Calm', 'Content'] : d.mood === 'anxious' ? ['Restless', 'Tense'] : ['Neutral'],
        journalNote: d.note,
        date: d.date,
        timestamp: new Date(d.date + 'T18:00:00Z').getTime(),
        createdAt: new Date(d.date),
      });
    });

    // 5. Seed Wellness Logs
    const sampleWellness = [
      { date: '2026-09-08', sleep: 6.5, quality: 'fair', water: 2100, steps: 6400, active: 30 },
      { date: '2026-09-09', sleep: 7.2, quality: 'good', water: 2350, steps: 7800, active: 40 },
      { date: '2026-09-10', sleep: 8.0, quality: 'excellent', water: 2700, steps: 9100, active: 55 },
      { date: '2026-09-11', sleep: 7.5, quality: 'good', water: 1850, steps: 6500, active: 35 },
    ] as const;

    sampleWellness.forEach((w, index) => {
      const wId = `well_00${index + 1}`;
      this.wellnessLogs.set(wId, {
        id: wId,
        userId: demoUserId,
        date: w.date,
        sleepHours: w.sleep,
        sleepQuality: w.quality,
        waterIntakeMl: w.water,
        waterTargetMl: 2500,
        physicalActivityMinutes: w.active,
        stepsCount: w.steps,
        notes: 'Consistent routine maintained.',
        createdAt: new Date(w.date),
      });
    });

    // 6. Seed Active Ambulance Prototype Dispatch
    const activeAmbulance: IAmbulanceDispatch = {
      id: 'amb_sim_9042',
      userId: demoUserId,
      patientName: 'Simulated Patient (Prototype)',
      callerPhone: '+91 98765 01234',
      status: 'en_route',
      origin: {
        lat: 28.6215,
        lng: 77.362,
        address: 'Residential Block 12, Sector 59',
      },
      destinationHospital: {
        id: 'doc_001',
        name: 'Metro Care Multispecialty & Emergency Hospital',
        address: '14, Healthcare Boulevard, Sector 62',
        phone: '+91 11 4567 8900',
        lat: 28.6289,
        lng: 77.3758,
      },
      currentLocation: {
        lat: 28.6252,
        lng: 77.3685,
      },
      etaMinutes: 4,
      currentJunctionIndex: 1,
      junctions: [
        {
          id: 'junc_1',
          name: 'Sector 59 Main Avenue Junction',
          status: 'cleared',
          distanceMeters: 0,
          trafficLevel: 'green',
          clearedAt: '22:12:30',
        },
        {
          id: 'junc_2',
          name: 'Central Expressway Crossroad',
          status: 'approaching',
          distanceMeters: 450,
          trafficLevel: 'yellow',
        },
        {
          id: 'junc_3',
          name: 'Metro Care Hospital Ingress Junction',
          status: 'pending',
          distanceMeters: 1200,
          trafficLevel: 'green',
        },
      ],
      routeCoordinates: [
        [28.6215, 77.362],
        [28.6234, 77.365],
        [28.6252, 77.3685],
        [28.627, 77.372],
        [28.6289, 77.3758],
      ],
      trafficCondition: 'moderate',
      priority: 'CRITICAL',
      alertMessage:
        'EMERGENCY AMBULANCE APPROACHING | ETA: 4 minutes | Next Junction: Central Expressway Crossroad | Please facilitate emergency traffic movement.',
      alertAcknowledgedByControl: false,
      greenCorridorActive: true,
      createdAt: new Date(),
    };
    this.ambulanceDispatches.set(activeAmbulance.id, activeAmbulance);
  }
}

export const db = new DataStore();
