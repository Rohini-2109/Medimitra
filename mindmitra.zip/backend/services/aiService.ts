import { GoogleGenAI } from '@google/genai';

let genAIClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!genAIClient) {
    genAIClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return genAIClient;
}

export interface ChatResponse {
  reply: string;
  isDisclaimerIncluded: boolean;
  urgencyLevel: 'routine' | 'moderate' | 'emergency';
}

export interface SymptomCheckResult {
  extractedSymptoms: string[];
  duration: string;
  healthCategories: string[];
  urgencyLevel: 'Routine / Home Care' | 'Prompt Doctor Visit' | 'Immediate Emergency Care';
  generalGuidance: string[];
  potentialQuestionsForDoctor: string[];
  medicalDisclaimer: string;
}

const MEDICAL_DISCLAIMER_MAP: Record<string, string> = {
  te: 'వైద్య నిరాకరణ: మెడిమిత్ర అనేది విద్య మరియు శ్రేయస్సు ప్రయోజనాల కోసం రూపొందించబడిన AI సహాయక గైడ్ మాత్రమే. ఇది వ్యాధి నిర్ధారణలు, ప్రిస్క్రిప్షన్లు లేదా చికిత్స ప్రణాళికలను అందించదు. వ్యక్తిగత వైద్య సలహా లేదా అత్యవసర పరిస్థితుల కోసం ఎల్లప్పుడూ లైసెన్స్ పొందిన వైద్యుడిని సంప్రదించండి.',
  hi: 'चिकित्सा अस्वीकरण: मेडि मित्र केवल सामान्य स्वास्थ्य और जागरूकता के लिए एक AI स्वास्थ्य सहायक है। यह किसी बीमारी का निदान, दवाई या उपचार नहीं बताता है। व्यक्तिगत चिकित्सीय सलाह के लिए हमेशा डॉक्टर से संपर्क करें।',
  ta: 'மருத்துவ மறுப்புரை: மேடிமித்ரா என்பது கல்வி மற்றும் நல்வாழ்வு நோக்கங்களுக்கான ஒரு AI சுகாதார வழிகாட்டி மட்டுமே. இது நோயறிதல், மருந்துகள் அல்லது சிகிச்சை திட்டங்களை வழங்காது. தனிப்பயனாக்கப்பட்ட மருத்துவ ஆலோசனைக்கு எப்போதும் தகுதியான மருத்துவரை அணுகவும்.',
  kn: 'ವೈದ್ಯಕೀಯ ಹಕ್ಕುತ್ಯಾಗ: ಮೇಡಿಮಿತ್ರ ಕೇವಲ ಶೈಕ್ಷಣಿಕ ಮತ್ತು ಸ್ವಾಸ್ಥ್ಯ ಉದ್ದೇಶಗಳಿಗಾಗಿ ರಚಿಸಲಾದ AI ಆರೋಗ್ಯ ಮಾರ್ಗದರ್ಶಿಯಾಗಿದೆ. ಇದು ಯಾವುದೇ ರೋಗನಿರ್ಣಯ, ಔಷಧಿ ಅಥವಾ ಚಿಕಿತ್ಸೆಯನ್ನು ನೀಡುವುದಿಲ್ಲ. ವೈಯಕ್ತಿಕ ವೈದ್ಯಕೀಯ ಸಲಹೆಗಾಗಿ ಯಾವಾಗಲೂ ಅರ್ಹ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸಿ.',
  en: 'Medical Disclaimer: MediMitra is an AI health & wellness assistive guide designed for educational purposes only. It DOES NOT provide medical diagnoses, prescriptions, or treatment plans. Always consult a licensed healthcare physician for personalized medical advice or urgent clinical conditions.',
};

const getDisclaimer = (lang: string): string => {
  return MEDICAL_DISCLAIMER_MAP[lang] || MEDICAL_DISCLAIMER_MAP.en;
};

const LANG_NAME_MAP: Record<string, string> = {
  te: 'Telugu (తెలుగు)',
  hi: 'Hindi (हिन्दी)',
  ta: 'Tamil (தமிழ்)',
  kn: 'Kannada (ಕನ್ನಡ)',
  en: 'English',
};

/**
 * Health Assistant conversation generator
 */
export async function generateHealthAssistantResponse(
  userQuery: string,
  userProfileSummary?: string,
  lang: string = 'en'
): Promise<ChatResponse> {
  const language = LANG_NAME_MAP[lang] ? lang : 'en';
  const targetLangName = LANG_NAME_MAP[language];

  // Check for crisis / self-harm keywords for instant safety response
  const crisisKeywords = [
    'suicide', 'kill myself', 'end my life', 'want to die', 'self-harm', 'cut myself', 'hanging',
    'ఆత్మహత్య', 'చనిపోవాలని ఉంది', 'आत्महत्या', 'मरना चाहता', 'தற்கொலை', 'ಆತ್ಮಹತ್ಯೆ'
  ];
  const lowerQuery = userQuery.toLowerCase();
  const isCrisis = crisisKeywords.some((keyword) => lowerQuery.includes(keyword));

  if (isCrisis) {
    const crisisReplies: Record<string, string> = {
      te: `మీ భద్రత మరియు శ్రేయస్సు మాకు ఎంతో ముఖ్యం. మీరు తీవ్రమైన మానసిక ఆందోళన లేదా ఒత్తిడితో బాధపడుతుంటే, దయచేసి వెంటనే ఉచిత సహాయ కేంద్రాన్ని సంప్రదించండి. మీరు ఒంటరిగా లేరు, వెంటనే సహాయం అందుబాటులో ఉంది:\n\n• భారతదేశంలో: టెలి-మానస్ (Tele-MANAS) హెల్ప్‌లైన్ 14416 లేదా 1800-891-4416 (24 గంటలు ఉచితం & గోప్యమైనది), లేదా 112 కు కాల్ చేయండి.\n• దయచేసి ప్రశాంతంగా ఉండండి మరియు తక్షణమే వైద్య నిపుణుడిని లేదా మీ కుటుంబ సభ్యులను సంప్రదించండి.`,
      hi: `आपकी सुरक्षा और मानसिक स्वास्थ्य हमारे लिए अत्यंत महत्वपूर्ण है। यदि आप अत्यधिक तनाव या किसी कठिन परिस्थिति से गुजर रहे हैं, तो कृपया तुरंत सहायता प्राप्त करें। आप अकेले नहीं हैं, 24 घंटे सहायता उपलब्ध है:\n\n• भारत में: टेली-मानस (Tele-MANAS) 14416 या 1800-891-4416 (24 घंटे निःशुल्क और गोपनीय), या 112 पर कॉल करें।\n• कृपया सुरक्षित रहें और तुरंत किसी चिकित्सक या अपने परिवार के किसी सदस्य से संपर्क करें।`,
      ta: `உங்கள் பாதுகாப்பு மற்றும் நல்வாழ்வு எங்களுக்கு மிகவும் முக்கியம். நீங்கள் கடுமையான மன உளைச்சலில் இருந்தால், தயவுசெய்து உடனடியாக இலவச உதவி மையத்தை அணுகவும். நீங்கள் தனியாக இல்லை, உடனடி உதவி உள்ளது:\n\n• இந்தியாவில்: டெலி-மானாஸ் (Tele-MANAS) 14416 அல்லது 1800-891-4416 (24 மணிநேரமும் இலவசம்), அல்லது 112 ஐ அழைக்கவும்.\n• தயவுசெய்து மருத்துவ நிபுணர் அல்லது குடும்பத்தினரின் உதவியை உடனடியாகப் பெறவும்.`,
      kn: `ನಿಮ್ಮ ಸುರಕ್ಷತೆ ಮತ್ತು ಯೋಗಕ್ಷೇಮ ನಮಗೆ ಅತ್ಯಂತ ಮುಖ್ಯವಾಗಿದೆ. ನೀವು ತೀವ್ರ ಮಾನಸಿಕ ಆತಂಕ ಅಥವಾ ಒತ್ತಡದಲ್ಲಿದ್ದರೆ, ದಯವಿಟ್ಟು ತಕ್ಷಣವೇ ಉಚಿತ ಸಹಾಯವಾಣಿಯನ್ನು ಸಂಪರ್ಕಿಸಿ. ನೀವು ಒಬ್ಬಂಟಿಯಾಗಿಲ್ಲ, ತಕ್ಷಣದ ಸಹಾಯ ಲಭ್ಯವಿದೆ:\n\n• ಭಾರತದಲ್ಲಿ: ಟೆಲಿ-ಮಾನಸ್ (Tele-MANAS) 14416 ಅಥವಾ 1800-891-4416 (24 ಗಂಟೆ ಉಚಿತ ಮತ್ತು ಗೌಪ್ಯ), ಅಥವಾ 112 ಗೆ ಕರೆ ಮಾಡಿ.\n• ದಯವಿಟ್ಟು ವೈದ್ಯಕೀಯ ತಜ್ಞರು ಅಥವಾ ನಿಮ್ಮ ಕುಟುಂಬದವರ ಸಹಾಯವನ್ನು ತಕ್ಷಣವೇ ಪಡೆಯಿರಿ.`,
      en: `I care about your safety and well-being. If you are experiencing overwhelming feelings or thoughts of self-harm, please reach out to dedicated crisis support right now. You are not alone, and compassionate help is available immediately:\n\n• In India: Tele-MANAS at 14416 or 1800-891-4416 (24x7 Free & Confidential), or call 112\n• In the US/Canada: Call or text 988 (Suicide & Crisis Lifeline)\n• In the UK: Call 111 or text SHOUT to 85258\n• In other countries: Reach out to your local emergency helpline or a trusted family member / physician immediately.\n\nPlease stay safe and talk to a healthcare professional or trusted loved one today.`
    };

    return {
      reply: crisisReplies[language] || crisisReplies.en,
      isDisclaimerIncluded: true,
      urgencyLevel: 'emergency',
    };
  }

  const ai = getGenAI();

  const systemInstruction = `You are MediMitra, an empathetic, evidence-based AI Personal Health and Wellness Assistant.
CRITICAL MANDATORY LANGUAGE RULE:
- Respond ONLY in the user's currently selected language: ${targetLangName}.
- Do not switch to English.
- Do not mix languages unless the user explicitly requests a translation.
- If the user wrote in ${targetLangName}, understand it and reply ONLY in ${targetLangName}.
- Use simple, easy-to-understand everyday language suitable for low-literacy and elderly users.
- Keep medical terminology simple and explain unavoidable medical terms in ${targetLangName}.

CLINICAL SAFETY & ETHICAL RULES:
1. You provide general health education, wellness lifestyle tips, and preventive knowledge only.
2. DO NOT diagnose any illness, medical condition, or disease.
3. DO NOT prescribe medications, drugs, or dosages.
4. If the user presents symptoms that could represent severe or acute issues (e.g. chest pain, shortness of breath, severe head trauma, high persistent fever, stroke symptoms, uncontrolled bleeding), IMMEDIATELY recommend urgent emergency medical attention or contacting emergency services (112 / 108).
5. DO NOT generate harmful, dangerous, or unverified treatments.
6. Always communicate with warmth, calm reassurance, and clear sentence phrasing.
7. VOICE SYNTHESIS QUALITY:
   - Your response will be spoken aloud to the user by a natural female voice engine.
   - Speak in clear, natural, complete sentences with proper punctuation so sentence pauses sound natural.
   - DO NOT include emojis, pictographs, markdown tables, or UI code so audio playback is clear and soothing.
   - Conclude with the provided medical disclaimer.
${userProfileSummary ? `User Background: ${userProfileSummary}` : ''}`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: userQuery,
        config: {
          systemInstruction,
          temperature: 0.4,
        },
      });

      const text = response.text || '';
      let urgency: 'routine' | 'moderate' | 'emergency' = 'routine';
      if (
        lowerQuery.includes('chest pain') ||
        lowerQuery.includes('stroke') ||
        lowerQuery.includes('difficulty breathing') ||
        lowerQuery.includes('unconscious') ||
        lowerQuery.includes('ఛాతీ నొప్పి') ||
        lowerQuery.includes('सीने में दर्द')
      ) {
        urgency = 'emergency';
      } else if (
        lowerQuery.includes('severe') ||
        lowerQuery.includes('fever') ||
        lowerQuery.includes('infection') ||
        lowerQuery.includes('vomiting blood') ||
        lowerQuery.includes('తీవ్ర') ||
        lowerQuery.includes('తేడా') ||
        lowerQuery.includes('बुखार')
      ) {
        urgency = 'moderate';
      }

      return {
        reply: `${text}\n\n---\n*${getDisclaimer(language)}*`,
        isDisclaimerIncluded: true,
        urgencyLevel: urgency,
      };
    } catch (err) {
      console.warn('Gemini API call failed, using clinical multilingual fallback engine:', err);
    }
  }

  // Multilingual Fallback response engine if API key is not yet set or request fails
  let fallbackReply = '';

  if (language === 'te') {
    if (lowerQuery.includes('headache') || lowerQuery.includes('తలనొప్పి') || lowerQuery.includes('migraine')) {
      fallbackReply = `మీకు ఉదయం నుంచి తలనొప్పి ఉందని అర్థమైంది. మీకు జ్వరం, వాంతులు లేదా చూపు మసకబారడం వంటి ఇతర లక్షణాలు ఏమైనా ఉన్నాయా?

సాధారణ ఉపశమనం కోసం కొన్ని జాగ్రత్తలు:
• **నీరు త్రాగండి**: తలనొప్పికి శరీరంలో నీటి శాతం తగ్గడం (డీహైడ్రేషన్) సాధారణ కారణం. నెమ్మదిగా ఒక గ్లాసు గోరువెచ్చని నీరు త్రాగండి.
• **విశ్రాంతి తీసుకోండి**: కాంతి తక్కువగా ఉండే నిశ్శబ్ద గదిలో కళ్ళు మూసుకుని కాసేపు పడుకోండి. మొబైల్ లేదా టీవీ స్క్రీన్లను చూడకండి.
• **చల్లని గుడ్డ**: నుదుటిపై లేదా మెడ వెనుక భాగంలో చల్లని తడి గుడ్డ ఉంచడం వల్ల ఉపశమనం లభిస్తుంది.
• **డాక్టర్ను ఎప్పుడు కలవాలి**: తలనొప్పి హఠాత్తుగా తీవ్రమైనా, వాంతులు వచ్చినా, లేదా మెడ బిగుసుకుపోయినా ఆలస్యం చేయకుండా వెంటనే డాక్టర్ను సంప్రదించండి.`;
    } else if (lowerQuery.includes('cold') || lowerQuery.includes('cough') || lowerQuery.includes('దగ్గు') || lowerQuery.includes('జ్వరం') || lowerQuery.includes('throat')) {
      fallbackReply = `జలుబు మరియు దగ్గు ఉపశమనం కొరకు జాగ్రత్తలు:
• **గోరువెచ్చని ద్రవాలు**: రోజంతా గోరువెచ్చని నీరు, తులసి టీ లేదా వేడి సూప్ త్రాగండి.
• **ఆవిరి పట్టడం**: రోజుకు రెండు సార్లు వేడి నీటి ఆవిరి పట్టడం ద్వారా గొంతు మరియు ముక్కు ఉపశమనం పొందుతాయి.
• **విశ్రాంతి**: శరీరానికి తగినంత విశ్రాంతి ఇవ్వండి. డాక్టర్ సలహా లేకుండా సొంతంగా యాంటీబయాటిక్స్ తీసుకోకండి.
• **హెచ్చరిక**: 3 రోజులకు మించి అధిక జ్వరం ఉన్నా లేదా శ్వాస తీసుకోవడంలో ఇబ్బంది ఉన్నా వెంటనే ఆసుపత్రికి వెళ్ళండి.`;
    } else if (lowerQuery.includes('stomach') || lowerQuery.includes('కడుపు') || lowerQuery.includes('acidity')) {
      fallbackReply = `కడుపులో అసౌకర్యానికి సాధారణ సలహాలు:
• **తేలికపాటి ఆహారం**: మజ్జిగ, అన్నం, అరటిపండు వంటి సులభంగా జీర్ణమయ్యే ఆహారం తీసుకోండి.
• **నివారించవలసినవి**: మసాలాలు, నూనె పదార్థాలు, కాఫీ మరియు శీతల పానీయాలను దూరంగా ఉంచండి.
• **హెచ్చరిక**: కడుపు నొప్పి తీవ్రంగా ఉన్నా లేదా వాంతులు ఆగకపోయినా వెంటనే వైద్యుడిని సంప్రదించండి.`;
    } else {
      fallbackReply = `మీ సందేహాన్ని పంచుకున్నందుకు ధన్యవాదాలు. మీ ఆరోగ్యం కోసం సాధారణ సూచనలు:
• **తగినంత నీరు మరియు నిద్ర**: ప్రతిరోజూ తగినంత నీరు త్రాగడం మరియు కనీసం 7-8 గంటలు నిద్రపోవడం చాలా ముఖ్యం.
• **లక్షణాల నమోదు**: మీ అసౌకర్యం ఎప్పుడు ప్రారంభమైందో మరియు ఏవైనా మార్పులు ఉన్నాయో గమనించండి.
• **వైద్య సంప్రదింపులు**: ఏవైనా ఇబ్బందులు కొనసాగితే లైసెన్స్ పొందిన వైద్యుడిని సంప్రదించడం ఎల్లప్పుడూ శ్రేయస్కరం.`;
    }
  } else if (language === 'hi') {
    if (lowerQuery.includes('headache') || lowerQuery.includes('सिर') || lowerQuery.includes('migraine')) {
      fallbackReply = `मुझे समझ आया कि आपको सिरदर्द की समस्या हो रही है। क्या इसके साथ बुखार, उल्टी या धुंधला दिखने जैसी कोई अन्य तकलीफ भी है?

सामान्य और सुरक्षित देखभाल के सुझाव:
• **पानी पिएं**: सिरदर्द का सबसे सामान्य कारण शरीर में पानी की कमी (डिहाइड्रेशन) हो सकता है। एक या दो गिलास गुनगुना पानी धीरे-धीरे पिएं।
• **शांत वातावरण में विश्राम**: किसी शांत और मंद रोशनी वाले कमरे में आराम करें। फोन या टीवी की स्क्रीन से दूर रहें।
• **ठंडी पट्टी**: माथे पर ठंडा या गीला कपड़ा रखने से नसों को आराम मिलता है।
• **डॉक्टर से कब मिलें**: यदि सिरदर्द अचानक बहुत तेज हो, उल्टी हो रही हो या गर्दन में जकड़न हो, तो तुरंत डॉक्टर को दिखाएं।`;
    } else if (lowerQuery.includes('cold') || lowerQuery.includes('cough') || lowerQuery.includes('खांसी') || lowerQuery.includes('बुखार') || lowerQuery.includes('throat')) {
      fallbackReply = `खांसी और जुकाम में राहत के सामान्य उपाय:
• **गर्म तरल पदार्थ**: दिन भर गुनगुना पानी, हर्बल चाय या काढ़ा पिएं।
• **भाप लें**: गर्म पानी की भाप लें और नमक के पानी से गरारे करें।
• **विश्राम**: पर्याप्त आराम करें। डॉक्टर की सलाह के बिना खुद से कोई एंटीबायोटिक दवाई न लें।
• **सावधानी**: यदि बुखार 3 दिन से ज्यादा रहे या सांस फूलने लगे, तो तुरंत डॉक्टर से संपर्क करें।`;
    } else if (lowerQuery.includes('stomach') || lowerQuery.includes('पेट') || lowerQuery.includes('acidity')) {
      fallbackReply = `पेट की परेशानी में सामान्य राहत के उपाय:
• **हल्का सुपाच्य भोजन**: दलिया, खिचड़ी, छाछ या केला लें।
• **परहेज**: ज्यादा मसालेदार, तला-भुना खाना और चाय-कॉफ़ी से बचें।
• **सावधानी**: यदि पेट में असहनीय तेज दर्द हो तो तुरंत अस्पताल जाएं।`;
    } else {
      fallbackReply = `आपके प्रश्न के लिए धन्यवाद। सामान्य स्वास्थ्य जागरूकता:
• **पानी और पोषण**: दिनभर पर्याप्त पानी पिएं और संतुलित भोजन लें।
• **भरपूर नींद**: रोजाना 7-8 घंटे की गहरी नींद सेहत के लिए आवश्यक है।
• **डॉक्टर की सलाह**: यदि किसी भी तरह की शारीरिक तकलीफ बनी रहे, तो अपने चिकित्सक से परामर्श लेना सबसे सुरक्षित कदम है।`;
    }
  } else if (language === 'ta') {
    if (lowerQuery.includes('headache') || lowerQuery.includes('தலை') || lowerQuery.includes('migraine')) {
      fallbackReply = `உங்களுக்கு தலைவலி இருப்பது புரிகிறது. இதனுடன் காய்ச்சல் அல்லது வாந்தி போன்ற அறிகுறிகள் உள்ளதா?

பொதுவான வீட்டுப் பராமரிப்பு குறிப்புகள்:
• **தண்ணீர் குடியுங்கள்**: நீர்ச்சத்து குறைபாடு தலைவலிக்கு முக்கியக் காரணம். மெதுவாக தண்ணீர் குடியுங்கள்.
• **அமைதியான அறையில் ஓய்வு**: வெளிச்சம் குறைந்த அமைதியான அறையில் ஓய்வெடுக்கவும்.
• **குளிர்ந்த ஒத்தடம்**: நெற்றியில் குளிர்ந்த துணியை வைக்கவும்.
• **எப்போது மருத்துவரை அணுக வேண்டும்**: தலைவலி மிகக் கடுமையாக இருந்தால் உடனே மருத்துவரை அணுகவும்.`;
    } else {
      fallbackReply = `உங்கள் கேள்விக்கு நன்றி. பொதுவான நலவாழ்வு குறிப்புகள்:
• **நீர்ச்சத்து & ஓய்வு**: போதிய அளவு தண்ணீர் குடித்து 7-8 மணிநேரம் உறங்குங்கள்.
• **அறிகுறிகளைக் கவனியுங்கள்**: உடலில் ஏற்படும் மாற்றங்களைக் குறித்து வைத்துக்கொள்ளுங்கள்.
• **மருத்துவர் ஆலோசனை**: அறிகுறிகள் நீடித்தால் தகுதியான மருத்துவரை அணுகுவது மிகச் சிறந்தது.`;
    }
  } else if (language === 'kn') {
    if (lowerQuery.includes('headache') || lowerQuery.includes('ತಲೆ') || lowerQuery.includes('migraine')) {
      fallbackReply = `ನಿಮಗೆ ತಲೆನೋವು ಇರುವುದು ಅರ್ಥವಾಯಿತು. ಇದರೊಂದಿಗೆ ಜ್ವರ ಅಥವಾ ವಾಂತಿಯ ಲಕ್ಷಣಗಳಿವೆಯೇ?

ಸುರಕ್ಷಿತ ಮನೆ ಆರೈಕೆ ಸಲಹೆಗಳು:
• **ನೀರು ಕುಡಿಯಿರಿ**: ನಿರ್ಜಲೀಕರಣವು ತಲೆನೋವಿಗೆ ಸಾಮಾನ್ಯ ಕಾರಣ. ಸಾಕಷ್ಟು ನೀರು ಕುಡಿಯಿರಿ.
• **ಶಾಂತ ಕೋಣೆಯಲ್ಲಿ ವಿಶ್ರಾಂತಿ**: ಬೆಳಕು ಕಡಿಮೆಯಿರುವ ಕೋಣೆಯಲ್ಲಿ ವಿಶ್ರಾಂತಿ ತೆಗೆದುಕೊಳ್ಳಿ.
• **ತಣ್ಣೀರಿನ ಪಟ್ಟಿ**: ಹಣೆಯ ಮೇಲೆ ತಣ್ಣೀರಿನ ಬಟ್ಟೆಯನ್ನು ಇರಿಸಿ.
• **ವೈದ್ಯರನ್ನು ಯಾವಾಗ ಭೇಟಿ ಮಾಡಬೇಕು**: ತಲೆನೋವು ಅತಿಯಾಗಿದ್ದರೆ ತಕ್ಷಣ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸಿ.`;
    } else {
      fallbackReply = `ನಿಮ್ಮ ಪ್ರಶ್ನೆಗೆ ಧನ್ಯವಾದಗಳು. ಸಾಮಾನ್ಯ ಆರೋಗ್ಯ ಸಲಹೆಗಳು:
• **ನೀರು ಮತ್ತು ವಿಶ್ರಾಂತಿ**: ಸಾಕಷ್ಟು ನೀರು ಕುಡಿಯಿರಿ ಮತ್ತು 7-8 ಗಂಟೆಗಳ ನಿದ್ರೆ ಮಾಡಿ.
• **ಲಕ್ಷಣಗಳನ್ನು ಗಮನಿಸಿ**: ನಿಮ್ಮ ದೇಹದಲ್ಲಿನ ಬದಲಾವಣೆಗಳನ್ನು ಗಮನದಲ್ಲಿಟ್ಟುಕೊಳ್ಳಿ.
• **ವೈದ್ಯರ ಸಲಹೆ**: ತೊಂದರೆ ಮುಂದುವರಿದರೆ ಅರ್ಹ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸುವುದು ಉತ್ತಮ.`;
    }
  } else {
    // English fallback
    if (lowerQuery.includes('headache') || lowerQuery.includes('migraine')) {
      fallbackReply = `I understand you have had a headache since morning. Do you also have any fever, nausea, or visual disturbance?

Here are gentle, safe home care steps:
• **Hydrate**: Dehydration is a common trigger. Drink a large glass of room-temperature water slowly.
• **Rest in a Calm Room**: Lie down in a quiet, dimly lit space without screen glare.
• **Cool Compress**: Place a cool, damp cloth across your forehead or back of your neck.
• **When to Seek Immediate Care**: If the headache is sudden and unusually severe ("thunderclap"), accompanied by high fever, neck stiffness, confusion, or weakness, please seek emergency medical evaluation right away.`;
    } else if (lowerQuery.includes('cold') || lowerQuery.includes('cough') || lowerQuery.includes('throat') || lowerQuery.includes('fever')) {
      fallbackReply = `Gentle supportive care for cough, cold, and fever:
• **Warm Fluids**: Sip warm water, herbal teas, or broths throughout the day.
• **Steam & Gargle**: Gentle steam inhalation and warm salt water gargles soothe upper airways.
• **Rest**: Allow your body ample rest. Avoid taking unprescribed antibiotics.
• **When to Seek Care**: If fever persists beyond 3 days, or if you experience shortness of breath, please consult a physician.`;
    } else if (lowerQuery.includes('stomach') || lowerQuery.includes('acidity') || lowerQuery.includes('digestion')) {
      fallbackReply = `Supportive digestive care:
• **Bland Diet**: Opt for light, easily digestible foods like rice, bananas, or oats.
• **Avoid Triggers**: Stay away from deep-fried, heavily spiced meals and caffeine.
• **When to Seek Care**: Severe sharp abdominal pain, repeated vomiting, or inability to retain fluids requires prompt clinical assessment.`;
    } else {
      fallbackReply = `General health & wellness principles:
• **Hydration & Rest**: Prioritize restorative sleep and adequate daily water intake.
• **Observation**: Keep a simple note of when discomfort began and any relieving factors.
• **Medical Consultation**: For any persistent or concerning symptoms, consulting a licensed physician is always the safest course of action.`;
    }
  }

  fallbackReply += `\n\n---\n*${getDisclaimer(language)}*`;

  return {
    reply: fallbackReply,
    isDisclaimerIncluded: true,
    urgencyLevel: 'routine',
  };
}

/**
 * Structured Symptom Checker Parser & Triage Engine
 */
export async function analyzeSymptoms(
  symptomInput: string,
  durationInput?: string,
  lang: string = 'en'
): Promise<SymptomCheckResult> {
  const language = lang === 'te' ? 'te' : lang === 'hi' ? 'hi' : 'en';
  const targetLangName =
    language === 'te' ? 'Telugu (తెలుగు)' : language === 'hi' ? 'Hindi (हिन्दी)' : 'English';

  const ai = getGenAI();

  if (ai) {
    try {
      const prompt = `Analyze these reported symptoms for an educational wellness triage prototype:
Symptoms: "${symptomInput}"
Reported Duration: "${durationInput || 'Not specified'}"
Language Requirement: MUST produce ALL text fields in ${targetLangName}.

CRITICAL INSTRUCTIONS:
- DO NOT provide a medical diagnosis.
- Extract symptoms accurately in ${targetLangName}.
- Categorize into health categories in ${targetLangName}.
- For urgencyLevel, use clear wording in ${targetLangName}:
  - Telugu: "ఇంటి సంరక్షణ / విశ్రాంతి" or "డాక్టర్ను సంప్రదించండి" or "తక్షణ అత్యవసర సంరక్షణ"
  - Hindi: "घरेलू देखभाल / आराम" or "डॉक्टर से परामर्श लें" or "तत्काल आपातकालीन देखभाल"
  - English: "Routine / Home Care" or "Prompt Doctor Visit" or "Immediate Emergency Care"
- Provide 3-4 bullet points of safe general self-care precautions in ${targetLangName}.
- Provide 3-4 questions the user can ask their doctor in ${targetLangName}.
- Return ONLY valid JSON matching this schema:
{
  "extractedSymptoms": ["string"],
  "duration": "string",
  "healthCategories": ["string"],
  "urgencyLevel": "string",
  "generalGuidance": ["string"],
  "potentialQuestionsForDoctor": ["string"]
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
      });

      const jsonStr = (response.text || '{}').trim();
      const parsed = JSON.parse(jsonStr);

      return {
        extractedSymptoms: parsed.extractedSymptoms || [symptomInput],
        duration: parsed.duration || durationInput || (language === 'te' ? 'ఇటీవల' : language === 'hi' ? 'हाल ही में' : 'Recent'),
        healthCategories: parsed.healthCategories || [language === 'te' ? 'సాధారణ ఆరోగ్యం' : language === 'hi' ? 'सामान्य स्वास्थ्य' : 'General Health & Wellness'],
        urgencyLevel: parsed.urgencyLevel || (language === 'te' ? 'డాక్టర్ను సంప్రదించండి' : language === 'hi' ? 'डॉक्टर से परामर्श लें' : 'Prompt Doctor Visit'),
        generalGuidance: parsed.generalGuidance || [
          language === 'te' ? 'తగినంత నీరు త్రాగి విశ్రాంతి తీసుకోండి' : language === 'hi' ? 'पर्याप्त पानी पिएं और आराम करें' : 'Maintain adequate hydration and rest',
          language === 'te' ? 'డాక్టర్ సలహా లేకుండా సొంతంగా మందులు వేసుకోవద్దు' : language === 'hi' ? 'बिना डॉक्टर की सलाह के खुद से दवाएं न लें' : 'Avoid self-medicating with unprescribed medications',
          language === 'te' ? 'లక్షణాలు ఎక్కువైతే వెంటనే డాక్టర్ను కలవండి' : language === 'hi' ? 'यदि लक्षण बढ़ें तो तुरंत डॉक्टर को दिखाएं' : 'Monitor for any escalating red flag signs',
        ],
        potentialQuestionsForDoctor: parsed.potentialQuestionsForDoctor || [
          language === 'te' ? 'ఈ లక్షణాలకు ప్రధాన కారణం ఏమిటి?' : language === 'hi' ? 'इन लक्षणों का मुख्य कारण क्या हो सकता है?' : 'What could be causing these symptoms?',
          language === 'te' ? 'ఏవైనా పరీక్షలు చేయించుకోవాలా?' : language === 'hi' ? 'क्या किसी जांच की आवश्यकता है?' : 'Are diagnostic tests recommended?',
        ],
        medicalDisclaimer: getDisclaimer(language),
      };
    } catch (err) {
      console.warn('Gemini symptom checker parsing failed, using localized rule engine:', err);
    }
  }

  // Multilingual Fallback symptom categorization
  const lower = symptomInput.toLowerCase();
  const symptoms: string[] = [];
  const categories: string[] = [];

  let urgencyEn = 'Routine / Home Care';
  if (lower.includes('chest pain') || lower.includes('breathing') || lower.includes('fainting') || lower.includes('seizure') || lower.includes('ఛాతీ') || lower.includes('सीने')) {
    urgencyEn = 'Immediate Emergency Care';
  } else if (lower.includes('fever') || lower.includes('cough') || lower.includes('sore throat') || lower.includes('జ్వరం') || lower.includes('బుఖార్')) {
    urgencyEn = lower.includes('high') || lower.includes('తీవ్ర') || lower.includes('तेज') ? 'Prompt Doctor Visit' : 'Routine / Home Care';
  }

  if (language === 'te') {
    if (urgencyEn === 'Immediate Emergency Care') {
      categories.push('శ్వాస & అత్యవసర విభాగం');
    } else {
      categories.push('సాధారణ శ్రేయస్సు');
    }
    symptoms.push(symptomInput);

    const urgencyTe =
      urgencyEn === 'Immediate Emergency Care'
        ? 'తక్షణ అత్యవసర సంరక్షణ'
        : urgencyEn === 'Prompt Doctor Visit'
        ? 'డాక్టర్ను సంప్రదించండి'
        : 'ఇంటి సంరక్షణ / సాధారణం';

    return {
      extractedSymptoms: symptoms,
      duration: durationInput || '1-3 రోజులు',
      healthCategories: categories,
      urgencyLevel: urgencyTe as any,
      generalGuidance: [
        'రోజుకు కనీసం 2-3 లీటర్ల గోరువెచ్చని నీరు త్రాగండి.',
        'శరీరానికి తగినంత విశ్రాంతి మరియు నిద్ర ఇవ్వండి.',
        'డాక్టర్ సూచించని యాంటీబయాటిక్స్ లేదా నొప్పి నివారణ మందులు వాడవద్దు.',
        urgencyEn === 'Immediate Emergency Care'
          ? '⚠️ అత్యవసర హెచ్చరిక సంకేతాలు ఉన్నాయి. వెంటనే సమీపంలోని ఆసుపత్రికి వెళ్ళండి.'
          : 'లక్షణాలు 24-48 గంటలకు పైగా కొనసాగితే వైద్యుడిని సంప్రదించండి.',
      ],
      potentialQuestionsForDoctor: [
        'ఈ లక్షణాల వెనుక ఉన్న ముఖ్య కారణం ఏమిటి?',
        'నేను ఏవైనా నిర్దిష్ట పరీక్షలు చేయించుకోవాలా?',
        'పరిస్థితి విషమించకుండా నేను ఎలాంటి జాగ్రత్తలు తీసుకోవాలి?',
      ],
      medicalDisclaimer: getDisclaimer('te'),
    };
  }

  if (language === 'hi') {
    if (urgencyEn === 'Immediate Emergency Care') {
      categories.push('कार्डियोरेस्पिरेटरी और आपातकालीन');
    } else {
      categories.push('सामान्य स्वास्थ्य और देखभाल');
    }
    symptoms.push(symptomInput);

    const urgencyHi =
      urgencyEn === 'Immediate Emergency Care'
        ? 'तत्काल आपातकालीन देखभाल'
        : urgencyEn === 'Prompt Doctor Visit'
        ? 'डॉक्टर से परामर्श लें'
        : 'घरेलू देखभाल / सामान्य';

    return {
      extractedSymptoms: symptoms,
      duration: durationInput || '1-3 दिन',
      healthCategories: categories,
      urgencyLevel: urgencyHi as any,
      generalGuidance: [
        'पर्याप्त मात्रा में पानी, सूप या इलेक्ट्रोलाइट्स का सेवन करें।',
        'शरीर को भरपूर आराम दें और स्क्रीन से दूरी बनाएं।',
        'बिना डॉक्टरी पर्ची के कोई भी एंटीबायोटिक दवाई न लें।',
        urgencyEn === 'Immediate Emergency Care'
          ? '⚠️ उच्च चिंताजनक लक्षण। तुरंत नजदीकी आपातकालीन अस्पताल जाएं।'
          : 'यदि 24 से 48 घंटे में आराम न मिले तो डॉक्टर से संपर्क करें।',
      ],
      potentialQuestionsForDoctor: [
        'इन लक्षणों का सबसे संभावित कारण क्या हो सकता है?',
        'क्या किसी रक्त परीक्षण या स्कैन की आवश्यकता है?',
        'किन चेतावनी संकेतों पर तुरंत अस्पताल जाना चाहिए?',
      ],
      medicalDisclaimer: getDisclaimer('hi'),
    };
  }

  // English
  categories.push('General Wellness & Physiological Care');
  symptoms.push(symptomInput);

  return {
    extractedSymptoms: symptoms,
    duration: durationInput || 'Recent / 1-3 days',
    healthCategories: categories,
    urgencyLevel: urgencyEn as any,
    generalGuidance: [
      'Record your symptoms, temperature, and any peak times of discomfort.',
      'Maintain gentle hydration with water, warm broths, or electrolytes.',
      'Refrain from taking unprescribed medicines or changing existing prescriptions.',
      urgencyEn === 'Immediate Emergency Care'
        ? '⚠️ High-concern indicators detected. Seek immediate emergency evaluation at your nearest emergency department.'
        : 'If symptoms persist or worsen over the next 24-48 hours, schedule a clinical consultation.',
    ],
    potentialQuestionsForDoctor: [
      'What are the most likely benign versus serious causes for these symptoms?',
      'Are there specific tests (like blood work or imaging) you would recommend?',
      'What warning signs should prompt immediate emergency care?',
    ],
    medicalDisclaimer: getDisclaimer('en'),
  };
}
