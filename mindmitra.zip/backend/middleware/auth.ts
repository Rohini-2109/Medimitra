import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { db } from '../services/storage.ts';
import { IUser } from '../models/User.ts';

const JWT_SECRET = process.env.JWT_SECRET || 'mindmitra_jwt_secret_token_default_2026';

export interface AuthenticatedRequest extends Request {
  user?: IUser;
  userId?: string;
}

export function generateToken(user: IUser): string {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      name: user.name,
    },
    JWT_SECRET,
    { expiresIn: '30d' }
  );
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      // If demo mode header is present
      const demoHeader = req.headers['x-demo-user'];
      if (demoHeader) {
        const demoUser = db.users.get('user_demo_mindmitra_001');
        if (demoUser) {
          req.user = demoUser;
          req.userId = demoUser.id;
          return next();
        }
      }
      return res.status(401).json({ error: 'Authentication required. Please log in.' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string; email: string };

    const user = db.users.get(decoded.id);
    if (!user) {
      return res.status(401).json({ error: 'User session invalid. Please log in again.' });
    }

    req.user = user;
    req.userId = user.id;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired authentication token.' });
  }
}

export function optionalAuth(req: AuthenticatedRequest, _res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      const decoded = jwt.verify(token, JWT_SECRET) as { id: string };
      const user = db.users.get(decoded.id);
      if (user) {
        req.user = user;
        req.userId = user.id;
      }
    }
  } catch {
    // Ignore error for optional auth
  }
  next();
}
