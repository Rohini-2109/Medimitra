import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

import authRoutes from './backend/routes/authRoutes.ts';
import aiRoutes from './backend/routes/aiRoutes.ts';
import moodRoutes from './backend/routes/moodRoutes.ts';
import medicineRoutes from './backend/routes/medicineRoutes.ts';
import wellnessRoutes from './backend/routes/wellnessRoutes.ts';
import doctorRoutes from './backend/routes/doctorRoutes.ts';
import ambulanceRoutes from './backend/routes/ambulanceRoutes.ts';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body Parser Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Root & Standard Health Checks (Cloud Run & container ingress probes)
  app.get(['/health', '/healthz'], (_req, res) => {
    res.status(200).send('OK');
  });

  // API Health Check
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'MediMitra API',
      timestamp: new Date().toISOString(),
      modules: [
        'User Profile & Auth (JWT)',
        'AI Health Assistant (Gemini / Guardrails)',
        'Mental Well-being & Mood Tracking',
        'Symptom Checker & Triage',
        'Nearby Doctor Finder',
        'Prescribed Medicine Management',
        'Wellness Tracking',
        'Smart Ambulance Traffic Coordination (Simulation)',
        'Emergency Support & Helplines',
      ],
    });
  });

  // Mount API Endpoints
  app.use('/api/auth', authRoutes);
  app.use('/api/ai', aiRoutes);
  app.use('/api/mood', moodRoutes);
  app.use('/api/medicines', medicineRoutes);
  app.use('/api/wellness', wellnessRoutes);
  app.use('/api/doctors', doctorRoutes);
  app.use('/api/ambulance', ambulanceRoutes);

  // Global API error handler
  app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error('Server error:', err);
    res.status(500).json({ error: err.message || 'Internal server error' });
  });

  // Vite middleware for development vs static production serve
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MindMitra server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
