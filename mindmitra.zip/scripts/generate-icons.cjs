const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// Minimal pure-Node PNG generator
function createPNG(width, height, drawPixel) {
  // PNG signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8); // 8 bits per channel
  ihdr.writeUInt8(6, 9); // RGBA
  ihdr.writeUInt8(0, 10); // Deflate
  ihdr.writeUInt8(0, 11); // Filter method 0
  ihdr.writeUInt8(0, 12); // No interlace

  const ihdrChunk = makeChunk('IHDR', ihdr);

  // Raw image data with scanline filter bytes
  const scanlineLength = width * 4 + 1;
  const rawData = Buffer.alloc(height * scanlineLength);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * scanlineLength;
    rawData[rowOffset] = 0; // Filter: None
    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = drawPixel(x, y, width, height);
      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const idatData = zlib.deflateSync(rawData);
  const idatChunk = makeChunk('IDAT', idatData);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function makeChunk(type, data) {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);

  const typeBuffer = Buffer.from(type, 'ascii');
  const crcInput = Buffer.concat([typeBuffer, data]);
  const crc = crc32(crcInput);

  const crcBuffer = Buffer.alloc(4);
  crcBuffer.writeUInt32BE(crc >>> 0, 0);

  return Buffer.concat([length, typeBuffer, data, crcBuffer]);
}

// Standard CRC32 table
let crcTable;
function getCrcTable() {
  if (crcTable) return crcTable;
  crcTable = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) c = 0xedb88320 ^ (c >>> 1);
      else c = c >>> 1;
    }
    crcTable[n] = c;
  }
  return crcTable;
}

function crc32(buf) {
  const table = getCrcTable();
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = table[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

// Draw MediMitra health icon
function getPixel(x, y, w, h, isMaskable = false) {
  const cx = w / 2;
  const cy = h / 2;
  const r = w / 2;
  const dx = x - cx;
  const dy = y - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);

  // Background gradient: Blue (#2563eb to #1d4ed8)
  const bgR = Math.round(37 - (10 * y) / h);
  const bgG = Math.round(99 - (20 * y) / h);
  const bgB = Math.round(235 - (20 * y) / h);

  if (isMaskable) {
    // Maskable icon must have safe zone: central 80% circle
    // White inner disc inside safe zone
    const innerRadius = w * 0.36;
    if (dist <= innerRadius) {
      // Check medical cross
      const crossThickness = w * 0.10;
      const crossLength = w * 0.44;
      const inHorizBar = Math.abs(dy) <= crossThickness / 2 && Math.abs(dx) <= crossLength / 2;
      const inVertBar = Math.abs(dx) <= crossThickness / 2 && Math.abs(dy) <= crossLength / 2;

      if (inHorizBar || inVertBar) {
        // Red cross
        return [220, 38, 38, 255];
      }
      return [255, 255, 255, 255]; // White disc
    }
    return [bgR, bgG, bgB, 255]; // Full bleed background
  }

  // Standard icon with rounded corners
  const cornerRadius = w * 0.22;
  const inBox =
    x >= cornerRadius && x <= w - cornerRadius &&
    y >= cornerRadius && y <= h - cornerRadius;

  let insideShape = false;
  if (inBox) {
    insideShape = true;
  } else {
    // Check four corners
    const c1 = [cornerRadius, cornerRadius];
    const c2 = [w - cornerRadius, cornerRadius];
    const c3 = [cornerRadius, h - cornerRadius];
    const c4 = [w - cornerRadius, h - cornerRadius];

    for (const [ccx, ccy] of [c1, c2, c3, c4]) {
      const cornerDx = Math.abs(x - ccx);
      const cornerDy = Math.abs(y - ccy);
      if (x < cornerRadius || x > w - cornerRadius) {
        if (y < cornerRadius || y > h - cornerRadius) {
          if (cornerDx * cornerDx + cornerDy * cornerDy <= cornerRadius * cornerRadius) {
            insideShape = true;
            break;
          }
        }
      }
    }
    if (!insideShape && ((x >= cornerRadius && x <= w - cornerRadius) || (y >= cornerRadius && y <= h - cornerRadius))) {
      insideShape = true;
    }
  }

  if (!insideShape) {
    return [0, 0, 0, 0]; // transparent
  }

  // Inner white circle
  const innerRadius = w * 0.36;
  if (dist <= innerRadius) {
    // Medical cross
    const crossThickness = w * 0.10;
    const crossLength = w * 0.46;
    const inHorizBar = Math.abs(dy) <= crossThickness / 2 && Math.abs(dx) <= crossLength / 2;
    const inVertBar = Math.abs(dx) <= crossThickness / 2 && Math.abs(dy) <= crossLength / 2;

    if (inHorizBar || inVertBar) {
      return [220, 38, 38, 255]; // Red cross
    }
    return [255, 255, 255, 255]; // White disc
  }

  return [bgR, bgG, bgB, 255];
}

const publicDir = path.resolve(__dirname, '../public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Generate icons
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPNG(192, 192, (x, y, w, h) => getPixel(x, y, w, h, false)));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPNG(512, 512, (x, y, w, h) => getPixel(x, y, w, h, false)));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPNG(512, 512, (x, y, w, h) => getPixel(x, y, w, h, true)));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPNG(180, 180, (x, y, w, h) => getPixel(x, y, w, h, false)));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), createPNG(64, 64, (x, y, w, h) => getPixel(x, y, w, h, false)));

console.log('Successfully generated all PWA icons in public/');
