import React from 'react';
import {
  HeartPulse,
  Home,
  Bot,
  Heart,
  Stethoscope,
  Pill,
  Siren,
  Globe,
  Sliders,
  User,
  LogOut,
  HelpCircle,
  Radio,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { useSettings } from '../context/SettingsContext.tsx';
import { Language } from '../services/languageService.ts';

export type NavTab =
  | 'home'
  | 'assistant'
  | 'health'
  | 'doctors'
  | 'medicines'
  | 'emergency'
  | 'profile'
  | 'symptoms'
  | 'traffic';

interface Props {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenDisclaimer: () => void;
  onOpenVoiceAssistant?: () => void;
}

export const Navbar: React.FC<Props> = ({
  activeTab,
  onSelectTab,
  onOpenDisclaimer,
  onOpenVoiceAssistant,
}) => {
  const { user, logout } = useAuth();
  const { language, setLanguage, isEasyMode, toggleEasyMode, t, supportedLanguages } = useSettings();

  const primaryNavItems = [
    { id: 'home' as NavTab, label: t('navHome'), icon: Home },
    { id: 'assistant' as NavTab, label: t('navAssistant'), icon: Bot },
    { id: 'health' as NavTab, label: t('navHealth'), icon: Heart },
    { id: 'doctors' as NavTab, label: t('navDoctor'), icon: Stethoscope },
    { id: 'medicines' as NavTab, label: t('navMedicines'), icon: Pill },
    { id: 'emergency' as NavTab, label: t('navEmergency'), icon: Siren, isEmergency: true },
  ];

  return (
    <>
      {/* Top Main Navigation Bar */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200/90 shadow-2xs w-full">
        <div className="w-full px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20 gap-2 sm:gap-4">
            {/* Brand Logo & Tagline */}
            <div
              onClick={() => onSelectTab('home')}
              className="flex items-center gap-2 sm:gap-3 cursor-pointer select-none shrink-0"
            >
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
                <HeartPulse className="w-6 h-6 sm:w-7 sm:h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-xl sm:text-2xl text-slate-900 tracking-tight">
                    Medi<span className="text-blue-600">Mitra</span>
                  </span>
                  {isEasyMode && (
                    <span className="text-[10px] font-extrabold uppercase bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full">
                      ♿ Easy
                    </span>
                  )}
                </div>
                <p className="hidden sm:block text-[11px] text-slate-500 font-medium">
                  {t('tagline')}
                </p>
              </div>
            </div>

            {/* Desktop Center Navigation (Only 6 clean items) */}
            <nav className="hidden lg:flex items-center gap-1.5">
              {primaryNavItems.map((item) => {
                const Icon = item.icon;
                const isActive =
                  activeTab === item.id ||
                  (item.id === 'emergency' && activeTab === 'traffic') ||
                  (item.id === 'home' && activeTab === 'symptoms');

                if (item.isEmergency) {
                  return (
                    <button
                      key={item.id}
                      id={`nav-${item.id}-btn`}
                      onClick={() => onSelectTab(item.id)}
                      className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition ${
                        isActive
                          ? 'bg-red-600 text-white shadow-md shadow-red-500/25 ring-2 ring-red-300'
                          : 'bg-red-50 hover:bg-red-100 text-red-700 border border-red-200'
                      }`}
                    >
                      <Siren className="w-4 h-4 animate-bounce text-red-500" />
                      <span>{item.label}</span>
                    </button>
                  );
                }

                return (
                  <button
                    key={item.id}
                    id={`nav-${item.id}-btn`}
                    onClick={() => onSelectTab(item.id)}
                    className={`flex items-center gap-2 px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            {/* Right Controls: Language Selector, Easy Mode, Profile */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Language Selector */}
              <div className="relative flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200">
                <Globe className="w-3.5 h-3.5 text-slate-500 ml-1.5 mr-1 shrink-0" />
                {supportedLanguages.map((langDef) => (
                  <button
                    key={langDef.code}
                    id={`lang-${langDef.code}-btn`}
                    onClick={() => setLanguage(langDef.code)}
                    className={`px-2 sm:px-2.5 py-1 text-xs font-bold rounded-xl transition ${
                      language === langDef.code
                        ? 'bg-white text-blue-700 shadow-xs font-black'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title={langDef.displayName}
                  >
                    {langDef.nativeName}
                  </button>
                ))}
              </div>

              {/* Easy Mode Toggle Button */}
              <button
                id="toggle-easy-mode-btn"
                onClick={toggleEasyMode}
                className={`hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-bold border transition ${
                  isEasyMode
                    ? 'bg-amber-100 text-amber-900 border-amber-300 ring-2 ring-amber-200'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
                title="Toggle Accessibility Easy Mode for larger buttons and audio"
              >
                <span>♿</span>
                <span>{isEasyMode ? 'Easy: ON' : 'Easy Mode'}</span>
              </button>

              {/* Profile / Logout */}
              <button
                id="nav-profile-btn"
                onClick={() => onSelectTab('profile')}
                className={`flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-2xl border transition ${
                  activeTab === 'profile'
                    ? 'border-blue-600 bg-blue-50 text-blue-900'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
                title="Profile & Safety Settings"
              >
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                  {user?.name ? user.name.charAt(0).toUpperCase() : <User className="w-4 h-4" />}
                </div>
                <span className="hidden md:inline text-xs font-bold max-w-[80px] truncate">
                  {user?.name ? user.name.split(' ')[0] : 'Profile'}
                </span>
              </button>

              {/* Medical Disclaimer Info */}
              <button
                onClick={onOpenDisclaimer}
                className="p-2 text-slate-400 hover:text-blue-600 rounded-xl hover:bg-slate-100 transition"
                title="Medical Disclaimer & Safety Protocol"
              >
                <HelpCircle className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Sticky Bottom Navigation Bar (Very clean, 5-6 large touch targets) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200/90 py-1.5 px-2 shadow-lg flex items-center justify-around">
        {primaryNavItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            activeTab === item.id ||
            (item.id === 'emergency' && activeTab === 'traffic') ||
            (item.id === 'home' && activeTab === 'symptoms');

          if (item.isEmergency) {
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className="flex flex-col items-center justify-center p-1 relative -top-3"
              >
                <div className="w-12 h-12 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-500/30 ring-4 ring-white">
                  <Siren className="w-6 h-6 animate-bounce" />
                </div>
                <span className="text-[10px] font-black text-red-600 mt-1 uppercase">
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
                isActive ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
              <span className={`text-[10px] mt-0.5 ${isActive ? 'font-bold' : 'font-medium'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
