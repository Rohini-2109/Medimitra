import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Check, X, AlertCircle } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onTranscriptCaptured: (text: string) => void;
}

export const VoiceInputModal: React.FC<Props> = ({ isOpen, onClose, onTranscriptCaptured }) => {
  const [isListening, setIsListening] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>('');
  const [recognition, setRecognition] = useState<any>(null);
  const [isSupported, setIsSupported] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (!SpeechRecognition) {
        setIsSupported(false);
        return;
      }

      const instance = new SpeechRecognition();
      instance.continuous = true;
      instance.interimResults = true;
      instance.lang = 'en-US';

      instance.onresult = (event: any) => {
        let currentText = '';
        for (let i = 0; i < event.results.length; i++) {
          currentText += event.results[i][0].transcript + ' ';
        }
        setTranscript(currentText.trim());
      };

      instance.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          setErrorMessage('Microphone access was denied. Please allow microphone permissions or type your symptoms.');
        } else {
          setErrorMessage(`Audio capture note: ${event.error}. You can also type symptoms below.`);
        }
        setIsListening(false);
      };

      instance.onend = () => {
        setIsListening(false);
      };

      setRecognition(instance);
    }
  }, []);

  const toggleListening = () => {
    if (!recognition) return;
    setErrorMessage(null);

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      try {
        setTranscript('');
        recognition.start();
        setIsListening(true);
      } catch (err: any) {
        setErrorMessage('Unable to start speech recognition. Please type your symptoms.');
      }
    }
  };

  const handleApply = () => {
    if (transcript.trim()) {
      onTranscriptCaptured(transcript.trim());
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-bold text-slate-900 flex items-center gap-2">
            <Mic className="w-5 h-5 text-blue-600" />
            Voice Symptom Dictation
          </h3>
          <button
            onClick={() => {
              if (recognition && isListening) recognition.stop();
              onClose();
            }}
            className="text-slate-400 hover:text-slate-600 rounded-lg p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!isSupported ? (
          <div className="bg-amber-50 border border-amber-200 text-amber-900 rounded-xl p-4 text-xs">
            <p className="font-semibold mb-1">Voice Recognition Note</p>
            Your browser environment does not support speech recognition. Please use standard text input for your symptom checker inquiry.
          </div>
        ) : (
          <div className="flex flex-col items-center py-4">
            <button
              id="mic-pulse-btn"
              onClick={toggleListening}
              className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                isListening
                  ? 'bg-rose-500 text-white ring-8 ring-rose-100 scale-105 animate-pulse'
                  : 'bg-blue-600 text-white hover:bg-blue-700 shadow-md'
              }`}
            >
              {isListening ? <Mic className="w-8 h-8" /> : <MicOff className="w-8 h-8" />}
            </button>

            <span className="text-xs font-semibold mt-3 text-slate-700">
              {isListening ? 'Listening... Speak your symptoms clearly.' : 'Tap the microphone to start speaking'}
            </span>

            {errorMessage && (
              <p className="mt-2 text-xs text-rose-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                {errorMessage}
              </p>
            )}

            {/* Transcript preview or fallback text area */}
            <div className="w-full mt-4">
              <label className="text-xs font-semibold text-slate-600 mb-1 block">
                Recognized Transcript:
              </label>
              <textarea
                value={transcript}
                onChange={(e) => setTranscript(e.target.value)}
                placeholder="Spoken symptoms will appear here in real time... (e.g. 'I have had a mild dry cough and slight fever since yesterday morning')"
                className="w-full text-xs p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-blue-600 h-24 resize-none text-slate-800"
              />
            </div>
          </div>
        )}

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
          >
            Cancel
          </button>
          <button
            id="apply-transcript-btn"
            onClick={handleApply}
            disabled={!transcript.trim()}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition shadow-xs"
          >
            <Check className="w-4 h-4" />
            Use Spoken Symptoms
          </button>
        </div>
      </div>
    </div>
  );
};
