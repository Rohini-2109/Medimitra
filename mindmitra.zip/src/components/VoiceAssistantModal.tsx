import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  RotateCcw,
  X,
  Sparkles,
  ShieldAlert,
  ArrowRight,
  HeartPulse,
  Send,
} from 'lucide-react';
import { useSettings } from '../context/SettingsContext.tsx';
import { api } from '../services/api.ts';
import { HealthAssistantMessage } from '../types/index.ts';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
  onNavigateToEmergency?: () => void;
  onNavigateToDoctors?: () => void;
}

export const VoiceAssistantModal: React.FC<Props> = ({
  isOpen,
  onClose,
  initialPrompt,
  onNavigateToEmergency,
  onNavigateToDoctors,
}) => {
  const { language, t, speak, isSpeaking, stopSpeech, isEasyMode } = useSettings();
  const [isListening, setIsListening] = useState<boolean>(false);
  const [speechTranscript, setSpeechTranscript] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [recognitionInstance, setRecognitionInstance] = useState<any>(null);
  const initialWelcomeText =
    language === 'te'
      ? 'నమస్కారం! నేను మెడిమిత్ర. మీ సమస్యను మాట్లాడి చెప్పండి. ఉదాహరణకు: "ఉదయం నుండి తలనొప్పిగా ఉంది" లేదా "దగ్గరి డాక్టర్ ఎక్కడ?".'
      : language === 'hi'
      ? 'नमस्ते! मैं मेडि मित्र हूँ। बोलकर अपनी समस्या बताएं, जैसे: "सुबह से सिरदर्द है" या "नजदीकी डॉक्टर कहाँ हैं?".'
      : 'Hello! I am MediMitra, your personal voice health companion. Tap the microphone and speak naturally, for example: "I have had a headache since morning" or "Where is the nearest doctor?".';

  const [messages, setMessages] = useState<HealthAssistantMessage[]>([
    {
      id: 'msg_initial',
      sender: 'assistant',
      text: initialWelcomeText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  // Update initial welcome message whenever language changes if only initial welcome exists
  useEffect(() => {
    setMessages((prev) => {
      if (prev.length <= 1 && prev[0]?.id === 'msg_initial') {
        return [
          {
            id: 'msg_initial',
            sender: 'assistant',
            text: initialWelcomeText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ];
      }
      return prev;
    });
  }, [language, initialWelcomeText]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Suggested Voice Prompts
  const quickVoicePrompts = [
    {
      label: language === 'te' ? '🤕 ఉదయం నుండి తలనొప్పిగా ఉంది' : language === 'hi' ? '🤕 सुबह से सिरदर्द है' : '🤕 I have headache since morning',
      text: language === 'te' ? 'నాకు ఉదయం నుండి తలనొప్పిగా ఉంది, ఏమి చేయాలి?' : language === 'hi' ? 'मुझे सुबह से सिरदर्द है, क्या करना चाहिए?' : 'I have had a headache since morning. What gentle self-care steps can I follow?',
    },
    {
      label: language === 'te' ? '🌡️ జ్వరం మరియు శరీర నొప్పులు' : language === 'hi' ? '🌡️ बुखार और बदन दर्द' : '🌡️ Fever and mild body pain',
      text: language === 'te' ? 'నాకు కొద్దిగా జ్వరం మరియు ఒళ్లు నొప్పులు ఉన్నాయి' : language === 'hi' ? 'मुझे हल्का बुखार और शरीर में दर्द महसूस हो रहा है' : 'I have mild fever and body aches since yesterday.',
    },
    {
      label: language === 'te' ? '🩺 దగ్గరి డాక్టర్ను ఎలా కలవాలి?' : language === 'hi' ? '🩺 नजदीकी डॉक्टर से कब मिलें?' : '🩺 When should I see a doctor?',
      text: language === 'te' ? 'సాధారణంగా ఏ లక్షణాలు ఉంటే డాక్టర్ను సంప్రదించాలి?' : language === 'hi' ? 'किन लक्षणों में डॉक्टर को तुरंत दिखाना चाहिए?' : 'What warning signs mean I should see a doctor right away?',
    },
    {
      label: language === 'te' ? '💧 రోజుకు ఎంత నీరు తాగాలి?' : language === 'hi' ? '💧 दिन में कितना पानी पीना चाहिए?' : '💧 Daily hydration advice',
      text: language === 'te' ? 'ఆరోగ్యంగా ఉండటానికి రోజుకు ఎన్ని లీటర్ల నీరు తాగాలి?' : language === 'hi' ? 'स्वस्थ रहने के लिए दिन में कितना पानी पीना चाहिए?' : 'How much water should an adult drink daily for healthy hydration?',
    },
  ];

  // Initialize Speech Recognition
  useEffect(() => {
    if (typeof window !== 'undefined' && isOpen) {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;

        const langCode = language === 'te' ? 'te-IN' : language === 'hi' ? 'hi-IN' : 'en-IN';
        recognition.lang = langCode;

        recognition.onresult = (event: any) => {
          let current = '';
          for (let i = 0; i < event.results.length; i++) {
            current += event.results[i][0].transcript;
          }
          setSpeechTranscript(current);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.onerror = (e: any) => {
          console.warn('Speech recognition warning:', e.error);
          setIsListening(false);
        };

        setRecognitionInstance(recognition);
      }
    }

    return () => {
      stopSpeech();
    };
  }, [isOpen, language]);

  // If initial prompt provided, submit immediately
  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleProcessQuery(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const toggleMic = () => {
    stopSpeech();

    if (isListening) {
      if (recognitionInstance) recognitionInstance.stop();
      setIsListening(false);
      if (speechTranscript.trim()) {
        handleProcessQuery(speechTranscript.trim());
      }
    } else {
      setSpeechTranscript('');
      setIsListening(true);
      try {
        if (recognitionInstance) {
          recognitionInstance.start();
        } else {
          // Fallback simulation for unsupported browsers/iframes
          setTimeout(() => {
            const fallbackText =
              language === 'te'
                ? 'నాకు ఉదయం నుండి తలనొప్పిగా ఉంది.'
                : language === 'hi'
                ? 'मुझे सुबह से सिरदर्द है।'
                : 'I have headache since morning.';
            setSpeechTranscript(fallbackText);
            setIsListening(false);
            handleProcessQuery(fallbackText);
          }, 3000);
        }
      } catch (err) {
        console.warn('Mic start error:', err);
        setIsListening(false);
      }
    }
  };

  const handleProcessQuery = async (queryText: string) => {
    if (!queryText.trim() || isLoading) return;

    const userMsg: HealthAssistantMessage = {
      id: 'usr_' + Date.now(),
      sender: 'user',
      text: queryText.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setSpeechTranscript('');
    setIsLoading(true);

    try {
      const res = await api.chatAssistant(queryText.trim(), language);

      const assistantMsg: HealthAssistantMessage = {
        id: 'ast_' + Date.now(),
        sender: 'assistant',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        urgencyBadge: res.urgencyLevel,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Automatically read the response aloud to support low-literacy and elderly users!
      speak(res.reply);
    } catch (err: any) {
      const fallbackReply =
        language === 'te'
          ? 'క్షమించండి, ప్రాసెస్ చేయలేకపోయాము. దయచేసి విశ్రాంతి తీసుకోండి, పుష్కలంగా నీరు తాగండి. సమస్య తీవ్రంగా ఉంటే వైద్యుడిని సంప్రదించండి.'
          : language === 'hi'
          ? 'माफ़ कीजिए, उत्तर प्राप्त नहीं हुआ। कृपया पर्याप्त आराम करें और पानी पिएं। यदि परेशानी अधिक हो तो डॉक्टर को दिखाएं।'
          : 'Thank you for sharing. Please remember to rest in a quiet space and hydrate. If your symptoms are severe, sudden, or persistent, please consult a qualified doctor promptly.';

      const errAssistantMsg: HealthAssistantMessage = {
        id: 'ast_err_' + Date.now(),
        sender: 'assistant',
        text: fallbackReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errAssistantMsg]);
      speak(fallbackReply);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-2xl w-full h-[92vh] sm:h-[85vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 to-indigo-700 text-white p-4 sm:p-5 flex items-center justify-between shrink-0 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center backdrop-blur-xs">
              <HeartPulse className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base sm:text-lg tracking-tight">MediMitra</h3>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-white/20 text-white px-2 py-0.5 rounded-full">
                  Voice Assistant
                </span>
              </div>
              <p className="text-[11px] text-blue-100 font-medium">
                {t('tagline')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {isSpeaking && (
              <button
                onClick={stopSpeech}
                className="px-2.5 py-1 bg-amber-400 text-amber-950 rounded-xl text-xs font-bold flex items-center gap-1 animate-pulse"
                title="Stop audio"
              >
                <MicOff className="w-3.5 h-3.5" />
                <span>Stop Voice</span>
              </button>
            )}

            <button
              onClick={() => {
                stopSpeech();
                if (recognitionInstance && isListening) recognitionInstance.stop();
                onClose();
              }}
              className="p-2 text-white/80 hover:text-white rounded-xl hover:bg-white/10 transition"
              aria-label="Close"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Clinical Boundary Strip */}
        <div className="bg-blue-50 border-b border-blue-100 py-2 px-4 text-[11px] text-blue-900 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-blue-600 shrink-0" />
            <span>{t('medicalDisclaimerNotice')}</span>
          </div>
          <button
            onClick={() => speak(t('medicalDisclaimerNotice'))}
            className="p-1 text-blue-700 hover:text-blue-900"
            title="Read notice"
          >
            <Volume2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50/50">
          {messages.map((msg) => {
            const isAst = msg.sender === 'assistant';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isAst ? 'justify-start' : 'justify-end'}`}
              >
                {isAst && (
                  <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                    <HeartPulse className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-3xl p-4 sm:p-5 shadow-2xs space-y-2.5 ${
                    isAst
                      ? 'bg-white text-slate-800 border border-slate-200/80'
                      : 'bg-blue-600 text-white font-medium ml-auto'
                  }`}
                >
                  <p className="text-sm sm:text-base leading-relaxed whitespace-pre-wrap">
                    {msg.text}
                  </p>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-100/80 text-[11px] text-slate-400">
                    <span>{msg.timestamp}</span>

                    {isAst && (
                      <button
                        onClick={() => speak(msg.text)}
                        className="flex items-center gap-1 text-blue-600 hover:text-blue-800 font-bold px-2 py-1 rounded-lg hover:bg-blue-50 transition"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>{t('listen')}</span>
                      </button>
                    )}
                  </div>

                  {/* If assistant mentioned doctor or emergency */}
                  {isAst && msg.urgencyBadge === 'emergency' && (
                    <div className="pt-2">
                      <button
                        onClick={() => {
                          onClose();
                          if (onNavigateToEmergency) onNavigateToEmergency();
                        }}
                        className="w-full py-2.5 px-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs"
                      >
                        <span>🚨 Launch Emergency Ambulance Mode</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 animate-pulse">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="bg-white rounded-2xl px-4 py-3 border border-slate-200 shadow-2xs flex items-center gap-2 text-xs text-slate-500 font-medium">
                <div className="w-2 h-2 rounded-full bg-blue-600 animate-ping" />
                <span>MediMitra is formulating safe health guidance...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Tap Chips */}
        <div className="px-4 py-2 bg-white border-t border-slate-100 overflow-x-auto no-scrollbar flex items-center gap-2 shrink-0">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0">
            Quick Prompts:
          </span>
          {quickVoicePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleProcessQuery(p.text)}
              className="text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 py-1.5 px-3 rounded-full shrink-0 transition border border-slate-200"
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Interactive Voice Waveform & Microphone Footer */}
        <div className="bg-slate-50 border-t border-slate-200 p-4 sm:p-5 shrink-0 space-y-3 text-center">
          {/* Audio Waveform Animation when listening */}
          {isListening ? (
            <div className="flex items-center justify-center gap-1.5 py-1">
              <div className="w-1.5 h-6 bg-red-500 rounded-full animate-bounce" />
              <div className="w-1.5 h-10 bg-red-600 rounded-full animate-bounce [animation-delay:0.15s]" />
              <div className="w-1.5 h-8 bg-red-500 rounded-full animate-bounce [animation-delay:0.3s]" />
              <div className="w-1.5 h-12 bg-red-600 rounded-full animate-bounce [animation-delay:0.45s]" />
              <div className="w-1.5 h-7 bg-red-500 rounded-full animate-bounce [animation-delay:0.2s]" />
              <span className="text-xs font-bold text-red-600 ml-2 animate-pulse">
                {t('listening')}
              </span>
            </div>
          ) : (
            <p className="text-xs font-semibold text-slate-500">
              {t('voiceInputDesc')}
            </p>
          )}

          {speechTranscript && (
            <div className="p-2.5 bg-white rounded-xl border border-blue-200 text-xs font-medium text-blue-950 text-left max-h-16 overflow-y-auto">
              <span className="font-bold text-blue-700 block text-[10px] uppercase">Recognized:</span>
              "{speechTranscript}"
            </div>
          )}

          {/* Central Microphone Controls */}
          <div className="flex items-center justify-center gap-4">
            <button
              id="voice-modal-mic-btn"
              onClick={toggleMic}
              className={`relative rounded-full flex items-center justify-center transition-all duration-300 ${
                isEasyMode ? 'w-24 h-24' : 'w-18 h-18 sm:w-20 sm:h-20'
              } ${
                isListening
                  ? 'bg-red-600 text-white ring-8 ring-red-200 scale-105 shadow-xl'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/25 active:scale-95'
              }`}
              title={isListening ? t('stopListening') : t('tapToSpeak')}
            >
              {isListening ? (
                <Mic className="w-9 h-9 animate-pulse" />
              ) : (
                <Mic className="w-8 h-8" />
              )}
            </button>

            {speechTranscript.trim() && !isListening && (
              <button
                onClick={() => handleProcessQuery(speechTranscript.trim())}
                className="py-3 px-5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-2xl shadow-xs transition flex items-center gap-2"
              >
                <span>{t('askMediMitra')}</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center justify-center gap-4 text-xs font-bold text-slate-600">
            <span>{isListening ? t('stopListening') : t('tapToSpeak')}</span>
            <span>•</span>
            <button
              onClick={() => {
                setMessages([
                  {
                    id: 'msg_reset_' + Date.now(),
                    sender: 'assistant',
                    text:
                      language === 'te'
                        ? 'చాట్ రీసెట్ చేయబడింది. మీకు ఏ విధంగా సహాయపడగలను?'
                        : language === 'hi'
                        ? 'बातचीत रीसेट कर दी गई है। मैं आपकी कैसे मदद कर सकता हूँ?'
                        : 'Conversation refreshed. How may I assist your wellness journey today?',
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  },
                ]);
              }}
              className="text-slate-400 hover:text-blue-600 flex items-center gap-1 font-semibold"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
