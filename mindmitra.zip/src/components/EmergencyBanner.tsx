import React, { useState } from 'react';
import { AlertTriangle, Phone, ShieldAlert, ChevronDown, HeartPulse } from 'lucide-react';

export const EmergencyBanner: React.FC<{ onOpenSOS: () => void }> = ({ onOpenSOS }) => {
  const [selectedRegion, setSelectedRegion] = useState<string>('IN');
  const [showNumbers, setShowNumbers] = useState<boolean>(false);

  const emergencyContacts: Record<
    string,
    { country: string; ambulance: string; police: string; mentalHealth: string; general: string }
  > = {
    IN: {
      country: 'India',
      ambulance: '102 / 108',
      police: '100',
      mentalHealth: '14416 (Tele-MANAS)',
      general: '112 (National Emergency)',
    },
    US: {
      country: 'United States',
      ambulance: '911',
      police: '911',
      mentalHealth: '988 (Crisis Lifeline)',
      general: '911',
    },
    UK: {
      country: 'United Kingdom',
      ambulance: '999',
      police: '999',
      mentalHealth: '111',
      general: '999 / 112',
    },
    EU: {
      country: 'European Union',
      ambulance: '112',
      police: '112',
      mentalHealth: '116 123',
      general: '112',
    },
    AU: {
      country: 'Australia',
      ambulance: '000',
      police: '000',
      mentalHealth: '13 11 14 (Lifeline)',
      general: '000',
    },
    CA: {
      country: 'Canada',
      ambulance: '911',
      police: '911',
      mentalHealth: '988',
      general: '911',
    },
  };

  const current = emergencyContacts[selectedRegion] || emergencyContacts.IN;

  return (
    <div className="bg-rose-50 border-b border-rose-200 text-rose-950 px-4 py-2 text-xs md:text-sm">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 flex-1 min-w-[260px]">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600"></span>
          </span>
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <p className="font-medium truncate">
            <span className="font-bold text-rose-700">Immediate Medical Emergency?</span> Call{' '}
            <span className="font-bold underline text-rose-800">{current.general}</span> or proceed to nearest trauma center.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Region selector */}
          <div className="relative">
            <button
              id="emergency-region-btn"
              onClick={() => setShowNumbers(!showNumbers)}
              className="flex items-center gap-1 bg-white border border-rose-300 rounded px-2 py-1 text-xs font-semibold text-rose-800 hover:bg-rose-100 transition shadow-xs"
            >
              <Phone className="w-3 h-3 text-rose-600" />
              <span>{current.country}: {current.general}</span>
              <ChevronDown className="w-3 h-3 opacity-70" />
            </button>

            {showNumbers && (
              <div className="absolute right-0 mt-1 w-64 bg-white rounded-lg shadow-xl border border-rose-200 z-50 p-3 text-xs text-slate-800">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
                  <span className="font-bold text-slate-900 flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-600" /> Regional Helplines
                  </span>
                  <select
                    value={selectedRegion}
                    onChange={(e) => setSelectedRegion(e.target.value)}
                    className="border border-slate-300 rounded px-1.5 py-0.5 text-xs bg-slate-50 font-medium"
                  >
                    {Object.entries(emergencyContacts).map(([code, data]) => (
                      <option key={code} value={code}>
                        {data.country}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5 font-medium">
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-600">National Emergency:</span>
                    <a href={`tel:${current.general.split(' ')[0]}`} className="font-bold text-rose-600 hover:underline">
                      {current.general}
                    </a>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-600">Ambulance Direct:</span>
                    <span className="font-bold text-slate-900">{current.ambulance}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-600">Crisis / Mental Health:</span>
                    <span className="font-bold text-blue-700">{current.mentalHealth}</span>
                  </div>
                </div>
                <p className="mt-2 text-[10px] text-slate-500 leading-tight border-t pt-1.5">
                  MediMitra is not an emergency dispatch provider. In true crises, dial your national emergency number directly.
                </p>
              </div>
            )}
          </div>

          <button
            id="emergency-dispatch-open-btn"
            onClick={onOpenSOS}
            className="flex items-center gap-1 bg-rose-600 hover:bg-rose-700 text-white font-bold px-3 py-1 rounded text-xs transition shadow-xs hover:shadow-sm"
          >
            <HeartPulse className="w-3.5 h-3.5 animate-pulse" />
            <span>Emergency SOS</span>
          </button>
        </div>
      </div>
    </div>
  );
};
