import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Sparkles } from 'lucide-react';

export const BreathingExercise: React.FC = () => {
  const [isActive, setIsActive] = useState<boolean>(false);
  const [phase, setPhase] = useState<'Inhale' | 'Hold' | 'Exhale' | 'Rest'>('Inhale');
  const [countdown, setCountdown] = useState<number>(4);
  const [cyclesCompleted, setCyclesCompleted] = useState<number>(0);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isActive) {
      interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            // Transition phase
            setPhase((currentPhase) => {
              if (currentPhase === 'Inhale') return 'Hold';
              if (currentPhase === 'Hold') return 'Exhale';
              if (currentPhase === 'Exhale') return 'Rest';
              // Completed a cycle
              setCyclesCompleted((c) => c + 1);
              return 'Inhale';
            });
            return 4;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (interval) clearInterval(interval);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive]);

  const reset = () => {
    setIsActive(false);
    setPhase('Inhale');
    setCountdown(4);
    setCyclesCompleted(0);
  };

  const getPhaseColor = () => {
    switch (phase) {
      case 'Inhale':
        return 'from-blue-400 to-sky-500 text-blue-900 border-blue-300';
      case 'Hold':
        return 'from-cyan-400 to-blue-500 text-cyan-900 border-cyan-300';
      case 'Exhale':
        return 'from-indigo-400 to-violet-500 text-indigo-900 border-indigo-300';
      case 'Rest':
        return 'from-sky-300 to-blue-400 text-slate-800 border-sky-300';
    }
  };

  const getInstruction = () => {
    switch (phase) {
      case 'Inhale':
        return 'Breathe in slowly through your nose...';
      case 'Hold':
        return 'Gently hold your breath in calm stillness...';
      case 'Exhale':
        return 'Release breath slowly through your mouth...';
      case 'Rest':
        return 'Pause and feel your body relaxing...';
    }
  };

  return (
    <div className="bg-gradient-to-br from-blue-50 via-sky-50/40 to-indigo-50/50 border border-blue-100 rounded-2xl p-6 shadow-sm flex flex-col items-center justify-center text-center">
      <div className="flex items-center gap-1.5 text-xs font-bold text-blue-700 uppercase tracking-wider mb-2">
        <Sparkles className="w-4 h-4 text-blue-600" />
        <span>Box Breathing (4-4-4-4 Technique)</span>
      </div>
      <p className="text-xs text-slate-600 mb-6 max-w-sm">
        Used by healthcare professionals to reset nervous system tension, slow pulse rate, and alleviate acute stress.
      </p>

      {/* Visual Breathing Ring / Circle */}
      <div className="relative w-48 h-48 flex items-center justify-center mb-6">
        {/* Outer animated halo */}
        <div
          className={`absolute inset-0 rounded-full bg-gradient-to-tr ${getPhaseColor()} opacity-20 transition-all duration-1000 ${
            isActive && (phase === 'Inhale' || phase === 'Hold') ? 'scale-110' : 'scale-95'
          }`}
        />

        {/* Pulsing core orb */}
        <div
          className={`w-36 h-36 rounded-full bg-white border-4 ${getPhaseColor()} shadow-lg flex flex-col items-center justify-center transition-all duration-1000 ${
            isActive && phase === 'Inhale'
              ? 'scale-110 shadow-blue-200'
              : isActive && phase === 'Exhale'
              ? 'scale-90 shadow-indigo-100'
              : 'scale-100'
          }`}
        >
          <span className="text-sm font-bold tracking-wide uppercase text-slate-800 mb-0.5">
            {phase}
          </span>
          <span className="text-3xl font-extrabold text-blue-800">
            {isActive ? countdown : '4'}s
          </span>
        </div>
      </div>

      <p className="text-sm font-medium text-blue-950 mb-6 h-6 animate-fade-in">
        {isActive ? getInstruction() : 'Press Start to begin guided breathing.'}
      </p>

      {/* Controls */}
      <div className="flex items-center gap-3">
        <button
          id="toggle-breathing-btn"
          onClick={() => setIsActive(!isActive)}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm text-white transition shadow-sm ${
            isActive
              ? 'bg-amber-600 hover:bg-amber-700'
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {isActive ? (
            <>
              <Pause className="w-4 h-4" /> Pause
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-white" /> Start Guided Pacing
            </>
          )}
        </button>

        <button
          id="reset-breathing-btn"
          onClick={reset}
          className="p-2.5 rounded-xl border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 transition"
          title="Reset"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {cyclesCompleted > 0 && (
        <div className="mt-4 text-xs font-semibold text-blue-800 bg-blue-100/70 px-3 py-1 rounded-full">
          Cycles Completed: {cyclesCompleted} (Well done!)
        </div>
      )}
    </div>
  );
};
