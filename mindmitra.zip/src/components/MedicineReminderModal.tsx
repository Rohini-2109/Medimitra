import React from 'react';
import { Pill, CheckCircle2, Clock, Volume2, X, AlertCircle } from 'lucide-react';
import { useSettings } from '../context/SettingsContext.tsx';

export const MedicineReminderModal: React.FC = () => {
  const { language, activeReminder, dismissReminder, takeReminderDose, t, speak } = useSettings();

  if (!activeReminder) return null;

  const reminderHeader =
    language === 'te'
      ? '💊 మందుల సమయం'
      : language === 'hi'
      ? '💊 दवा का समय'
      : '💊 Medicine Time';

  const reminderSubtext =
    language === 'te'
      ? 'మీ మందు తీసుకునే సమయం వచ్చింది.'
      : language === 'hi'
      ? 'आपकी दवा लेने का समय हो गया है।'
      : 'It is time for your scheduled medicine.';

  const handleSpeakReminder = () => {
    const textToSpeak =
      language === 'te'
        ? `మందుల సమయం. మీ మందు తీసుకునే సమయం వచ్చింది. మందు పేరు: ${activeReminder.medicineName}. మోతాదు: ${activeReminder.dosage}. సూచన: ${activeReminder.instruction}.`
        : language === 'hi'
        ? `दवा का समय। आपकी दवा लेने का समय हो गया है। दवा का नाम: ${activeReminder.medicineName}। खुराक: ${activeReminder.dosage}। निर्देश: ${activeReminder.instruction}।`
        : `Medicine Time. It is time for your scheduled medicine. Medicine: ${activeReminder.medicineName}. Dosage: ${activeReminder.dosage}. Instruction: ${activeReminder.instruction}.`;
    speak(textToSpeak);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/65 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border-2 border-blue-500 space-y-6 text-center">
        {/* Top Header */}
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-2 text-xs font-black text-blue-700 uppercase tracking-wider bg-blue-50 py-1.5 px-3 rounded-xl border border-blue-100">
            <Clock className="w-4 h-4 animate-pulse text-blue-600" />
            <span>{reminderHeader}</span>
          </div>

          <button
            onClick={dismissReminder}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-full hover:bg-slate-100 transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Big Icon */}
        <div className="w-20 h-20 bg-blue-600 text-white rounded-3xl mx-auto flex items-center justify-center shadow-lg shadow-blue-500/25">
          <Pill className="w-10 h-10" />
        </div>

        {/* Medicine Details */}
        <div className="space-y-2">
          <p className="text-sm sm:text-base font-bold text-slate-700">
            "{reminderSubtext}"
          </p>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            {activeReminder.medicineName}
          </h2>
          <p className="text-sm font-semibold text-blue-700 bg-blue-50/70 inline-block px-3 py-1 rounded-full border border-blue-200/50">
            {activeReminder.dosage}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            {activeReminder.doctorName} • {activeReminder.instruction}
          </p>
        </div>

        {/* Read aloud button */}
        <button
          onClick={handleSpeakReminder}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-blue-600 bg-slate-100 hover:bg-blue-50 px-4 py-2 rounded-xl transition"
        >
          <Volume2 className="w-4 h-4 text-blue-600" />
          <span>{t('listen')}</span>
        </button>

        {/* Huge Actions */}
        <div className="space-y-3 pt-2">
          <button
            id="reminder-taken-btn"
            onClick={() => takeReminderDose(activeReminder.id, activeReminder.timing[0] || 'Morning')}
            className="w-full py-4 px-6 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-base sm:text-lg font-black rounded-2xl shadow-md transition flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-6 h-6" />
            <span>{t('taken')}</span>
          </button>

          <button
            id="reminder-later-btn"
            onClick={dismissReminder}
            className="w-full py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-bold rounded-2xl transition"
          >
            {t('remindLater')} (15 mins)
          </button>
        </div>

        <div className="pt-1 text-[11px] text-slate-400 border-t border-slate-100 flex items-center justify-center gap-1.5">
          <AlertCircle className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span>Doctor-prescribed dose record. MediMitra does not alter prescriptions.</span>
        </div>
      </div>
    </div>
  );
};
