import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile } from '../types/index.ts';
import { api, authStorage } from '../services/api.ts';

interface AuthContextType {
  user: UserProfile | null;
  token: string | null;
  isLoading: boolean;
  error: string | null;
  locationPermission: boolean;
  userCoords: { lat: number; lng: number } | null;
  requestLocationPermission: () => Promise<boolean>;
  login: (credentials: { email: string; password: string }) => Promise<void>;
  register: (data: any) => Promise<void>;
  demoLogin: () => Promise<void>;
  logout: () => void;
  updateProfile: (profile: Partial<UserProfile>) => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(authStorage.getToken());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [locationPermission, setLocationPermission] = useState<boolean>(false);
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>({
    lat: 28.6289,
    lng: 77.3758,
  });

  // Request browser location
  const requestLocationPermission = async (): Promise<boolean> => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return false;
    }

    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          setUserCoords(coords);
          setLocationPermission(true);
          // If logged in, update consent in profile
          if (user) {
            api.updateProfile({ locationConsent: true }).catch(() => {});
          }
          resolve(true);
        },
        (err) => {
          console.warn('Geolocation denied or unavailable:', err.message);
          // Fallback to default realistic demo coordinates
          setUserCoords({ lat: 28.6289, lng: 77.3758 });
          setLocationPermission(false);
          resolve(false);
        },
        { enableHighAccuracy: true, timeout: 8000 }
      );
    });
  };

  // Load user on mount
  useEffect(() => {
    const initAuth = async () => {
      try {
        const storedToken = authStorage.getToken();
        const hasExplicitLogin = localStorage.getItem('mindmitra_explicit_login');
        if (storedToken && hasExplicitLogin === 'true') {
          const res = await api.getCurrentUser();
          setUser(res.user);
          setLocationPermission(Boolean(res.user.locationConsent));
        } else {
          // If not explicitly logged in, clear any legacy token and show login/register
          authStorage.clearToken();
          localStorage.removeItem('mindmitra_explicit_login');
          setToken(null);
          setUser(null);
        }
      } catch {
        authStorage.clearToken();
        localStorage.removeItem('mindmitra_explicit_login');
        setToken(null);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    initAuth();
  }, []);

  const login = async (credentials: { email: string; password: string }) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.login(credentials);
      authStorage.setToken(res.token);
      localStorage.setItem('mindmitra_explicit_login', 'true');
      setToken(res.token);
      setUser(res.user);
      setLocationPermission(Boolean(res.user.locationConsent));
    } catch (err: any) {
      setError(err.message || 'Login failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const demoLogin = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.demoLogin();
      authStorage.setToken(res.token);
      localStorage.setItem('mindmitra_explicit_login', 'true');
      setToken(res.token);
      setUser(res.user);
      setLocationPermission(Boolean(res.user.locationConsent));
    } catch (err: any) {
      setError(err.message || 'Demo login failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: any) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.register(data);
      authStorage.setToken(res.token);
      localStorage.setItem('mindmitra_explicit_login', 'true');
      setToken(res.token);
      setUser(res.user);
      setLocationPermission(Boolean(res.user.locationConsent));
    } catch (err: any) {
      setError(err.message || 'Registration failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    authStorage.clearToken();
    localStorage.removeItem('mindmitra_explicit_login');
    setToken(null);
    setUser(null);
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    setError(null);
    try {
      const res = await api.updateProfile(updates);
      setUser(res.user);
      setLocationPermission(Boolean(res.user.locationConsent));
    } catch (err: any) {
      setError(err.message || 'Failed to update profile');
      throw err;
    }
  };

  const clearError = () => setError(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        error,
        locationPermission,
        userCoords,
        requestLocationPermission,
        login,
        register,
        demoLogin,
        logout,
        updateProfile,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
