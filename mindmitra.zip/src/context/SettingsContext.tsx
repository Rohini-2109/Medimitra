import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Language,
  TranslationDict,
  translations,
  SpeechService,
  SUPPORTED_LANGUAGES,
  LanguageDefinition,
  getLanguageConfig,
} from '../services/languageService.ts';
import { PrescribedMedicine } from '../types/index.ts';
import { api } from '../services/api.ts';

interface SettingsContextType {
  language: Language;
  languageConfig: LanguageDefinition;
  supportedLanguages: LanguageDefinition[];
  setLanguage: (lang: Language) => void;
  isEasyMode: boolean;
  setIsEasyMode: (val: boolean) => void;
  toggleEasyMode: () => void;
  t: (key: keyof TranslationDict) => string;
  speak: (text: string) => void;
  stopSpeech: () => void;
  isSpeaking: boolean;
  activeReminder: PrescribedMedicine | null;
  dismissReminder: () => void;
  takeReminderDose: (medicineId: string, timingSlot: string) => Promise<void>;
  triggerDemoReminder: () => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const LANG_KEY = 'medimitra_preferred_lang';
const EASY_MODE_KEY = 'medimitra_easy_mode';

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('en');
  const [isEasyMode, setIsEasyModeState] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [activeReminder, setActiveReminder] = useState<PrescribedMedicine | null>(null);

  useEffect(() => {
    SpeechService.init();
    try {
      const savedLang = localStorage.getItem(LANG_KEY) as Language;
      if (
        savedLang &&
        (savedLang === 'en' ||
          savedLang === 'te' ||
          savedLang === 'hi' ||
          savedLang === 'ta' ||
          savedLang === 'kn')
      ) {
        setLanguageState(savedLang);
      }
      const savedEasyMode = localStorage.getItem(EASY_MODE_KEY);
      if (savedEasyMode === 'true') {
        setIsEasyModeState(true);
      }
    } catch {
      // ignore
    }
  }, []);

  const languageConfig = getLanguageConfig(language);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(LANG_KEY, lang);
    } catch {}
    
    // Dynamic announcement in the selected native language and native female voice
    const config = getLanguageConfig(lang);
    SpeechService.speak(config.announcement, lang);
  };

  const setIsEasyMode = (val: boolean) => {
    setIsEasyModeState(val);
    try {
      localStorage.setItem(EASY_MODE_KEY, String(val));
    } catch {}

    const note = val ? t('easyModeEnabled') : t('easyModeDisabled');
    SpeechService.speak(note, language);
  };

  const toggleEasyMode = () => {
    setIsEasyMode(!isEasyMode);
  };

  const t = (key: keyof TranslationDict): string => {
    const dict = translations[language] || translations.en;
    return dict[key] || translations.en[key] || String(key);
  };

  const speak = (text: string) => {
    setIsSpeaking(true);
    SpeechService.speak(
      text,
      language,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false)
    );
  };

  const stopSpeech = () => {
    SpeechService.stop();
    setIsSpeaking(false);
  };

  const dismissReminder = () => {
    setActiveReminder(null);
  };

  const takeReminderDose = async (medicineId: string, timingSlot: string) => {
    try {
      await api.markDose(medicineId, timingSlot, 'taken');
      setActiveReminder(null);
      speak(t('doseTaken'));
    } catch (e) {
      console.warn('Could not mark dose:', e);
      setActiveReminder(null);
    }
  };

  const triggerDemoReminder = () => {
    const demoMed: PrescribedMedicine = {
      id: 'med_demo_active',
      userId: 'user_active',
      medicineName: 'Amlodipine 5mg',
      dosage: '1 Tablet Daily',
      doctorName: 'Dr. Ananya Sen, MD',
      prescriptionDate: '2026-09-10',
      timing: ['Morning'],
      instruction: 'After Breakfast with water',
      durationDays: 30,
      history: [],
    };
    setActiveReminder(demoMed);

    const alertMsg =
      language === 'te'
        ? 'మందుల సమయం. మీ మందు తీసుకునే సమయం వచ్చింది.'
        : language === 'hi'
        ? 'दवा का समय। आपकी दवा लेने का समय हो गया है।'
        : 'Medicine Time. It is time for your scheduled medicine.';
    speak(alertMsg);
  };

  return (
    <SettingsContext.Provider
      value={{
        language,
        languageConfig,
        supportedLanguages: SUPPORTED_LANGUAGES,
        setLanguage,
        isEasyMode,
        setIsEasyMode,
        toggleEasyMode,
        t,
        speak,
        stopSpeech,
        isSpeaking,
        activeReminder,
        dismissReminder,
        takeReminderDose,
        triggerDemoReminder,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within SettingsProvider');
  }
  return context;
};
