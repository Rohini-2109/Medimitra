export type Language = 'en' | 'te' | 'hi' | 'ta' | 'kn';

export interface LanguageDefinition {
  code: Language;
  language: string;
  displayName: string;
  nativeName: string;
  locale: string;
  ttsLocale: string;
  preferredFemaleVoices: string[];
  fallbackVoices: string[];
  announcement: string;
  flagEmoji: string;
}

/**
 * Dynamic Language Configurations
 * For every supported language:
 * - language code
 * - display name
 * - locale
 * - TTS locale
 * - preferred female voice
 * - fallback voice from the SAME language
 */
export const SUPPORTED_LANGUAGES: LanguageDefinition[] = [
  {
    code: 'en',
    language: 'English',
    displayName: 'English (India)',
    nativeName: 'English',
    locale: 'en-IN',
    ttsLocale: 'en-IN',
    preferredFemaleVoices: [
      'heera', 'veena', 'neerja', 'ananya', 'zira', 'samantha', 'karen', 'victoria', 'female', 'natural', 'google'
    ],
    fallbackVoices: ['en-in', 'en_in', 'en-gb', 'en-us', 'en'],
    announcement: 'English language selected.',
    flagEmoji: '🇮🇳',
  },
  {
    code: 'te',
    language: 'Telugu',
    displayName: 'తెలుగు (Telugu)',
    nativeName: 'తెలుగు',
    locale: 'te-IN',
    ttsLocale: 'te-IN',
    preferredFemaleVoices: [
      'chitra', 'geeta', 'shruti', 'sunita', 'priya', 'female', 'woman', 'natural', 'google telugu', 'te-in'
    ],
    fallbackVoices: ['te-in', 'te_in', 'te'],
    announcement: 'తెలుగు భాష ఎంపిక చేయబడింది.',
    flagEmoji: '🇮🇳',
  },
  {
    code: 'hi',
    language: 'Hindi',
    displayName: 'हिंदी (Hindi)',
    nativeName: 'हिंदी',
    locale: 'hi-IN',
    ttsLocale: 'hi-IN',
    preferredFemaleVoices: [
      'swara', 'kalpana', 'geeta', 'shruti', 'sunita', 'priya', 'female', 'woman', 'natural', 'google hi', 'hi-in'
    ],
    fallbackVoices: ['hi-in', 'hi_in', 'hi'],
    announcement: 'हिंदी भाषा चुनी गई है।',
    flagEmoji: '🇮🇳',
  },
  {
    code: 'ta',
    language: 'Tamil',
    displayName: 'தமிழ் (Tamil)',
    nativeName: 'தமிழ்',
    locale: 'ta-IN',
    ttsLocale: 'ta-IN',
    preferredFemaleVoices: [
      'vani', 'priya', 'geeta', 'shruti', 'female', 'woman', 'natural', 'google tamil', 'ta-in'
    ],
    fallbackVoices: ['ta-in', 'ta_in', 'ta'],
    announcement: 'தமிழ் மொழி தேர்ந்தெடுக்கப்பட்டது.',
    flagEmoji: '🇮🇳',
  },
  {
    code: 'kn',
    language: 'Kannada',
    displayName: 'ಕನ್ನಡ (Kannada)',
    nativeName: 'ಕನ್ನಡ',
    locale: 'kn-IN',
    ttsLocale: 'kn-IN',
    preferredFemaleVoices: [
      'sapna', 'priya', 'geeta', 'shruti', 'female', 'woman', 'natural', 'google kannada', 'kn-in'
    ],
    fallbackVoices: ['kn-in', 'kn_in', 'kn'],
    announcement: 'ಕನ್ನಡ ಭಾಷೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಲಾಗಿದೆ.',
    flagEmoji: '🇮🇳',
  },
];

export function getLanguageConfig(lang: Language): LanguageDefinition {
  return SUPPORTED_LANGUAGES.find((l) => l.code === lang) || SUPPORTED_LANGUAGES[0];
}

export interface TranslationDict {
  appName: string;
  tagline: string;
  howCanIHelp: string;
  talkToMediMitra: string;
  tapToSpeak: string;
  listening: string;
  speakNow: string;
  speakAgain: string;
  listen: string;
  stopListening: string;
  voiceInputDesc: string;
  
  // Dynamic Language-Specific Buttons
  askMediMitra: string;
  speak: string;
  speakNaturallyDesc: string;
  askPlaceholder: string;
  callEmergency: string;
  emergencyVoiceAnnouncement: string;
  emergencyVoiceTitle: string;
  requestAmbulance: string;
  notifyFamily: string;
  emergencyActiveSOS: string;
  waterLoggedSuccess: string;
  talkIntro: string;
  initialAssistantGreeting: string;
  notFeelingWell: string;
  notFeelingWellQuery: string;
  medicineRoutineQuery: string;
  doctorAdviceQuery: string;
  emergencyQuery: string;
  emergencyStep1: string;
  emergencyStep2: string;
  emergencyStep3: string;
  emergencyStep4: string;
  listenToVoice: string;
  listenToInstructions: string;
  replay: string;
  typeOrSpeak: string;
  quickPrompts: string;
  conversationHistory: string;
  stop: string;
  speaking: string;
  doseTaken: string;
  easyModeEnabled: string;
  easyModeDisabled: string;

  // 5 Main Actions
  myHealth: string;
  myHealthSub: string;
  findDoctor: string;
  findDoctorSub: string;
  medicines: string;
  medicinesSub: string;
  nearbyHospital: string;
  nearbyHospitalSub: string;
  emergency: string;
  emergencySub: string;
  
  // Navigation
  navHome: string;
  navAssistant: string;
  navHealth: string;
  navDoctor: string;
  navMedicines: string;
  navEmergency: string;
  
  // Modes & Toggles
  easyMode: string;
  easyModeActive: string;
  languageSelect: string;
  medicalDisclaimerNotice: string;
  
  // Symptom Checker
  symptomCheckerTitle: string;
  symptomCheckerSub: string;
  tapSymptomsBelow: string;
  headache: string;
  fever: string;
  cough: string;
  stomachProblem: string;
  breathingProblem: string;
  bodyPain: string;
  tellByVoice: string;
  otherProblem: string;
  symptomNextStep: string;
  routineCare: string;
  promptDoctorVisit: string;
  immediateEmergency: string;
  
  // Health & Wellness
  water: string;
  waterGoal: string;
  addWater250: string;
  sleep: string;
  sleepHours: string;
  activity: string;
  steps: string;
  activeMinutes: string;
  mood: string;
  moodGood: string;
  moodOkay: string;
  moodNeutral: string;
  moodLow: string;
  moodStressed: string;
  nutritionGuidance: string;
  wellnessInsight: string;
  
  // Medicine
  medicineReminders: string;
  medicineTime: string;
  taken: string;
  remindLater: string;
  morning: string;
  afternoon: string;
  night: string;
  addPrescription: string;
  
  // Emergency & Ambulance
  emergencyHelp: string;
  emergencyActivated: string;
  stayCalm: string;
  callingAmbulance: string;
  nearestHospital: string;
  eta: string;
  smartTrafficHero: string;
  trafficCorridorCleared: string;
  simulationNotice: string;
  callDoctor: string;
  getDirections: string;
}

export const translations: Record<Language, TranslationDict> = {
  en: {
    appName: 'MediMitra',
    tagline: 'Your Health. Your Companion. Your Safety.',
    howCanIHelp: 'How can I help you today?',
    talkToMediMitra: 'TALK TO MEDIMITRA',
    tapToSpeak: 'TAP TO SPEAK',
    listening: 'Listening to your voice...',
    speakNow: 'Speak naturally about how you feel...',
    speakAgain: 'Speak Again',
    listen: 'Listen',
    stopListening: 'Done Speaking',
    voiceInputDesc: 'Describe symptoms, ask medicine questions, or request emergency help.',

    // Dynamic Language-Specific Buttons
    askMediMitra: 'Ask MediMitra',
    speak: 'Speak',
    speakNaturallyDesc: 'Speak naturally. MediMitra will listen and respond.',
    askPlaceholder: 'Ask me about your health...',
    callEmergency: 'Call Emergency',
    emergencyVoiceAnnouncement: 'Emergency assistance has been activated. Locating your current coordinates. Finding the nearest hospital.',
    emergencyVoiceTitle: '🚑 Emergency Voice Announcement',
    requestAmbulance: 'Request Ambulance',
    notifyFamily: 'Notify Family',
    emergencyActiveSOS: 'Emergency SOS Active',
    waterLoggedSuccess: '250 ml of water logged. Good job staying hydrated!',
    talkIntro: 'Talk to MediMitra. Speak naturally about how you feel.',
    initialAssistantGreeting: 'Hello! I am MediMitra, your personal voice health companion. Speak or type your health question below.',
    notFeelingWell: "I don't feel well",
    notFeelingWellQuery: "I don't feel well today. I feel tired and have a mild headache. What general care steps should I follow?",
    medicineRoutineQuery: 'How should I maintain a consistent routine for my doctor-prescribed medicines?',
    doctorAdviceQuery: 'What symptoms indicate I should visit a doctor or specialist right away?',
    emergencyQuery: 'What are the key warning signs of medical emergencies like chest pain or stroke?',
    emergencyStep1: 'Emergency situation detected.',
    emergencyStep2: 'Locating your current coordinates.',
    emergencyStep3: 'Finding the nearest hospital.',
    emergencyStep4: 'Preparing the ambulance corridor.',
    listenToVoice: 'Listen to Voice',
    listenToInstructions: 'Listen to Instructions',
    replay: 'Replay',
    typeOrSpeak: 'Type or Speak Your Question',
    quickPrompts: 'Quick Health Prompts',
    conversationHistory: 'Full Conversation History',
    stop: 'Stop',
    speaking: 'Speaking...',
    doseTaken: 'Dose marked as taken. Well done staying on schedule.',
    easyModeEnabled: 'Easy mode activated with larger buttons and clear icons.',
    easyModeDisabled: 'Standard view activated.',

    myHealth: 'My Health',
    myHealthSub: 'Water, sleep, activity & wellness',
    findDoctor: 'Find Doctor',
    findDoctorSub: 'Nearby verified clinics & specialists',
    medicines: 'Medicines',
    medicinesSub: 'Doctor prescriptions & daily reminders',
    nearbyHospital: 'Nearby Hospital',
    nearbyHospitalSub: 'Emergency trauma centers & beds',
    emergency: 'Emergency',
    emergencySub: 'Instant SOS & Smart Ambulance routing',

    navHome: 'Home',
    navAssistant: 'Assistant',
    navHealth: 'Health',
    navDoctor: 'Doctor',
    navMedicines: 'Medicines',
    navEmergency: 'Emergency',

    easyMode: 'Easy Mode',
    easyModeActive: 'Easy Mode Active (Large Display)',
    languageSelect: 'Language',
    medicalDisclaimerNotice: 'MediMitra provides general health information and does NOT replace a doctor or diagnose diseases.',

    symptomCheckerTitle: 'Visual Symptom Guidance',
    symptomCheckerSub: 'Tap what you feel or speak. No medical jargon required.',
    tapSymptomsBelow: 'Tap what you are experiencing:',
    headache: 'Headache',
    fever: 'Fever',
    cough: 'Cough',
    stomachProblem: 'Stomach problem',
    breathingProblem: 'Breathing problem',
    bodyPain: 'Body Pain',
    tellByVoice: 'Tell us by voice',
    otherProblem: 'Other symptom',
    symptomNextStep: 'Recommended Next Step',
    routineCare: 'General Self-Care & Hydration',
    promptDoctorVisit: 'Consult a Qualified Physician',
    immediateEmergency: 'Seek Immediate Emergency Care',

    water: 'WATER',
    waterGoal: 'Daily Target',
    addWater250: '+ 250 ml',
    sleep: 'SLEEP',
    sleepHours: 'Hours Today',
    activity: 'ACTIVITY',
    steps: 'Steps',
    activeMinutes: 'Active Mins',
    mood: 'MOOD',
    moodGood: 'Good',
    moodOkay: 'Okay',
    moodNeutral: 'Neutral',
    moodLow: 'Low',
    moodStressed: 'Stressed',
    nutritionGuidance: 'Healthy Nutrition Guide',
    wellnessInsight: 'Wellness Insight',

    medicineReminders: 'Prescribed Medicine Reminders',
    medicineTime: 'MEDICINE TIME',
    taken: 'Taken',
    remindLater: 'Remind Me Later',
    morning: 'Morning',
    afternoon: 'Afternoon',
    night: 'Night',
    addPrescription: 'Add Doctor Prescription',

    emergencyHelp: 'EMERGENCY HELP',
    emergencyActivated: 'Emergency mode activated. Please stay calm.',
    stayCalm: 'Emergency dispatchers & nearest hospital have been notified.',
    callingAmbulance: 'Ambulance dispatched & smart traffic corridor enabled',
    nearestHospital: 'Nearest Emergency Hospital',
    eta: 'ETA',
    smartTrafficHero: 'Smart Ambulance Traffic Preemption System',
    trafficCorridorCleared: 'Corridor Traffic Signal Preemption: Green wave active',
    simulationNotice: 'Expo Demonstration / Simulated Traffic Coordination',
    callDoctor: 'Call Now',
    getDirections: 'Get Directions',
  },

  te: {
    appName: 'MediMitra',
    tagline: 'మీ ఆరోగ్యం. మీ సహచరుడు. మీ భద్రత.',
    howCanIHelp: 'నేను మీకు ఎలా సహాయపడగలను?',
    talkToMediMitra: 'మాట్లాడండి',
    tapToSpeak: 'మాట్లాడటానికి నొక్కండి',
    listening: 'మీ మాటలు వింటున్నాము...',
    speakNow: 'మీ సమస్యను స్పష్టంగా చెప్పండి...',
    speakAgain: 'మళ్లీ మాట్లాడండి',
    listen: 'వినండి',
    stopListening: 'పూర్తయింది',
    voiceInputDesc: 'లక్షణాలు చెప్పండి, మందుల సమయం తెలుసుకోండి లేదా సహాయం అడగండి.',

    // Dynamic Language-Specific Buttons
    askMediMitra: 'మేడిమిత్రను అడగండి',
    speak: 'మాట్లాడండి',
    speakNaturallyDesc: 'సహజంగా మాట్లాడండి. మేడిమిత్ర విని సమాధానం ఇస్తుంది.',
    askPlaceholder: 'మీ ఆరోగ్యం గురించి అడగండి...',
    callEmergency: 'అత్యవసర సహాయం కోసం కాల్ చేయండి',
    emergencyVoiceAnnouncement: 'అత్యవసర సహాయం ప్రారంభించబడింది. మీ ప్రస్తుత స్థానాన్ని గుర్తిస్తున్నాము. సమీపంలోని ఆసుపత్రిని కనుగొంటున్నాము.',
    emergencyVoiceTitle: '🚑 అత్యవసర వాయిస్ ప్రకటన',
    requestAmbulance: 'అంబులెన్స్ పిలవండి',
    notifyFamily: 'కుటుంబానికి తెలియజేయండి',
    emergencyActiveSOS: 'అత్యవసర SOS ప్రారంభించబడింది',
    waterLoggedSuccess: '250 మిల్లీలీటర్ల నీరు తాగినట్లు నమోదు చేయబడింది. చాలా మంచిది!',
    talkIntro: 'మేడిమిత్రతో మాట్లాడండి. మీ సమస్యను చెప్పండి.',
    initialAssistantGreeting: 'నమస్కారం! నేను మీ వ్యక్తిగత ఆరోగ్య సహాయకుడిని. మీ సమస్యను వాయిస్ ద్వారా లేదా టైప్ చేసి అడగండి.',
    notFeelingWell: 'నాకు ఆరోగ్యం బాగాలేదు',
    notFeelingWellQuery: 'నాకు ఆరోగ్యం బాగాలేదు, నీరసంగా మరియు తలనొప్పిగా ఉంది. ఏమి చేయాలి?',
    medicineRoutineQuery: 'నా ప్రిస్క్రిప్షన్ మందులు సమయానికి ఎలా వేసుకోవాలి?',
    doctorAdviceQuery: 'సాధారణంగా ఏ లక్షణాలకు డాక్టర్ను తప్పనిసరిగా కలవాలి?',
    emergencyQuery: 'తీవ్రమైన ఛాతీ నొప్పి లేదా అత్యవసర పరిస్థితి ఉంటే ఏమి చేయాలి?',
    emergencyStep1: 'అత్యవసర పరిస్థితి గుర్తించబడింది.',
    emergencyStep2: 'మీ ప్రస్తుత స్థానాన్ని గుర్తిస్తున్నాము.',
    emergencyStep3: 'సమీపంలోని ఆసుపత్రిని కనుగొంటున్నాము.',
    emergencyStep4: 'అంబులెన్స్ మార్గం సిద్ధం చేస్తున్నాము.',
    listenToVoice: 'వాయిస్ వినండి',
    listenToInstructions: 'సూచనలను వినండి',
    replay: 'మళ్లీ వినండి',
    typeOrSpeak: 'టైప్ చేసి లేదా మాట్లాడి అడగండి',
    quickPrompts: 'త్వరిత ప్రశ్నలు',
    conversationHistory: 'సంభాషణ చరిత్ర',
    stop: 'ఆపండి',
    speaking: 'వింటున్నారు...',
    doseTaken: 'మందు తీసుకున్నట్లు నమోదు చేయబడింది. ధన్యవాదాలు.',
    easyModeEnabled: 'సులభమైన వీక్షణ పెద్ద బటన్లతో ప్రారంభించబడింది.',
    easyModeDisabled: 'సాధారణ వీక్షణకు మార్చబడింది.',

    myHealth: 'నా ఆరోగ్యం',
    myHealthSub: 'నీరు, నిద్ర, నడక మరియు శ్రేయస్సు',
    findDoctor: 'డాక్టర్ను కనుగొనండి',
    findDoctorSub: 'దగ్గరి వైద్యులు మరియు క్లినిక్లు',
    medicines: 'మందులు',
    medicinesSub: 'వైద్యుల ప్రిస్క్రిప్షన్ & రిమైండర్లు',
    nearbyHospital: 'సమీపంలోని ఆసుపత్రి',
    nearbyHospitalSub: 'అత్యవసర చికిత్స కేంద్రాలు',
    emergency: 'అత్యవసరం',
    emergencySub: 'తక్షణ SOS & స్మార్ట్ అంబులెన్స్ సేవ',

    navHome: 'హోమ్',
    navAssistant: 'మేడిమిత్ర',
    navHealth: 'ఆరోగ్యం',
    navDoctor: 'డాక్టర్',
    navMedicines: 'మందులు',
    navEmergency: 'అత్యవసరం',

    easyMode: 'పెద్ద బటన్లు (సులభం)',
    easyModeActive: 'సులభమైన వీక్షణ ప్రారంభించబడింది',
    languageSelect: 'భాష',
    medicalDisclaimerNotice: 'మెడిమిత్ర కేవలం సాధారణ ఆరోగ్య సలహాలు ఇస్తుంది. ఇది డాక్టర్ స్థానాన్ని భర్తీ చేయదు.',

    symptomCheckerTitle: 'లక్షణాల తనిఖీ',
    symptomCheckerSub: 'మీ సమస్యను నొక్కండి లేదా మాట్లాడి చెప్పండి.',
    tapSymptomsBelow: 'మీకు ఎలా అనిపిస్తుందో ఎంచుకోండి:',
    headache: 'తలనొప్పి',
    fever: 'జ్వరం',
    cough: 'దగ్గు',
    stomachProblem: 'కడుపు నొప్పి',
    breathingProblem: 'శ్వాస సమస్య',
    bodyPain: 'శరీర నొప్పులు',
    tellByVoice: 'వాయిస్ ద్వారా చెప్పండి',
    otherProblem: 'ఇతర సమస్య',
    symptomNextStep: 'తదుపరి సిఫార్సు',
    routineCare: 'ఇంటి సంరక్షణ & విశ్రాంతి',
    promptDoctorVisit: 'డాక్టర్ను సంప్రదించండి',
    immediateEmergency: 'వెంటనే అత్యవసర చికిత్స తీసుకోండి',

    water: 'నీరు',
    waterGoal: 'రోజువారీ లక్ష్యం',
    addWater250: '+ 250 మి.లీ',
    sleep: 'నిద్ర',
    sleepHours: 'గంటల నిద్ర',
    activity: 'నడక & వ్యాయామం',
    steps: 'అడుగులు',
    activeMinutes: 'చురుకైన సమయం',
    mood: 'మానసిక స్థితి',
    moodGood: 'బాగుంది',
    moodOkay: 'పర్వాలేదు',
    moodNeutral: 'సాధారణం',
    moodLow: 'నీరసం',
    moodStressed: 'ఒత్తిడి',
    nutritionGuidance: 'ఆరోగ్యకరమైన ఆహారం',
    wellnessInsight: 'ఆరోగ్య అంతర్దృష్టి',

    medicineReminders: 'మందుల సమయ పట్టిక',
    medicineTime: 'మందులు వేసుకునే సమయం',
    taken: 'వేసుకున్నాను',
    remindLater: 'తర్వాత గుర్తుచేయి',
    morning: 'ఉదయం',
    afternoon: 'మధ్యాహ్నం',
    night: 'రాత్రి',
    addPrescription: 'డాక్టర్ మందులు జోడించండి',

    emergencyHelp: 'అత్యవసర సహాయం',
    emergencyActivated: 'అత్యవసర ప్రక్రియ ప్రారంభించబడింది. దయచేసి ప్రశాంతంగా ఉండండి.',
    stayCalm: 'దగ్గరి ఆసుపత్రి మరియు సహాయకులకు సమాచారం అందించబడింది.',
    callingAmbulance: 'అంబులెన్స్ బయలుదేరింది, ట్రాఫిక్ సిగ్నల్ క్లియర్ అవుతోంది.',
    nearestHospital: 'దగ్గరి అత్యవసర ఆసుపత్రి',
    eta: 'చేరే సమయం',
    smartTrafficHero: 'స్మార్ట్ అంబులెన్స్ ట్రాఫిక్ సమన్వయం',
    trafficCorridorCleared: 'ట్రాఫిక్ గ్రీన్ కారిడార్ సిద్ధం చేయబడింది',
    simulationNotice: 'డెమో ప్రదర్శన / సిమ్యులేటెడ్ ట్రాఫిక్ కోఆర్డినేషన్',
    callDoctor: 'కాల్ చేయండి',
    getDirections: 'మార్గం చూడండి',
  },

  hi: {
    appName: 'MediMitra',
    tagline: 'आपका स्वास्थ्य। आपका साथी। आपकी सुरक्षा।',
    howCanIHelp: 'आज मैं आपकी क्या सहायता कर सकता हूँ?',
    talkToMediMitra: 'बात करें',
    tapToSpeak: 'बोलने के लिए दबाएं',
    listening: 'आपकी आवाज सुन रहे हैं...',
    speakNow: 'अपनी परेशानी खुलकर बताएं...',
    speakAgain: 'फिर से बोलें',
    listen: 'सुनें',
    stopListening: 'पूरा हुआ',
    voiceInputDesc: 'लक्षण बताएं, दवाई का समय पूछें या आपातकालीन मदद मांगें।',

    // Dynamic Language-Specific Buttons
    askMediMitra: 'मेडीमित्र से पूछें',
    speak: 'बोलें',
    speakNaturallyDesc: 'सहजता से बोलें। मेडीमित्र सुनकर उत्तर देगी।',
    askPlaceholder: 'अपने स्वास्थ्य के बारे में पूछें...',
    callEmergency: 'आपातकालीन सहायता के लिए कॉल करें',
    emergencyVoiceAnnouncement: 'आपातकालीन सहायता सक्रिय हो गई है। आपकी वर्तमान लोकेशन पहचानी जा रही है। नजदीकी अस्पताल खोजा जा रहा है।',
    emergencyVoiceTitle: '🚑 आपातकालीन वॉइस घोषणा',
    requestAmbulance: 'एम्बुलेंस बुलाएं',
    notifyFamily: 'परिवार को सूचित करें',
    emergencyActiveSOS: 'आपातकालीन SOS सक्रिय',
    waterLoggedSuccess: '250 मिलीलीटर पानी दर्ज किया गया। बहुत बढ़िया!',
    talkIntro: 'मेडि मित्र से बात करें। अपनी परेशानी बताएं।',
    initialAssistantGreeting: 'नमस्ते! मैं आपका व्यक्तिगत स्वास्थ्य सहायक हूँ। बोलकर या लिखकर अपनी स्वास्थ्य संबंधी बात साझा करें।',
    notFeelingWell: 'मेरी तबीयत ठीक नहीं है',
    notFeelingWellQuery: 'मेरी तबीयत ठीक नहीं लग रही है, मुझे सिरदर्द और थकान है। क्या सावधानी बरतें?',
    medicineRoutineQuery: 'डॉक्टर की दी हुई दवाएं सही समय पर कैसे लें?',
    doctorAdviceQuery: 'किन परिस्थितियों में डॉक्टर से परामर्श लेना अनिवार्य है?',
    emergencyQuery: 'अचानक सीने में दर्द या सांस में गंभीर समस्या हो तो क्या करें?',
    emergencyStep1: 'आपातकालीन स्थिति का पता चला है।',
    emergencyStep2: 'आपकी वर्तमान लोकेशन पहचानी जा रही है।',
    emergencyStep3: 'नजदीकी अस्पताल खोजा जा रहा है।',
    emergencyStep4: 'एम्बुलेंस का मार्ग तैयार किया जा रहा है।',
    listenToVoice: 'वॉइस सुनें',
    listenToInstructions: 'निर्देश सुनें',
    replay: 'पुनः सुनें',
    typeOrSpeak: 'टाइप करके या बोलकर पूछें',
    quickPrompts: 'त्वरित सवाल',
    conversationHistory: 'बातचीत का इतिहास',
    stop: 'रोकें',
    speaking: 'बोल रहे हैं...',
    doseTaken: 'दवाई लेने की पुष्टि दर्ज कर ली गई है।',
    easyModeEnabled: 'आसान मोड बड़े बटनों के साथ सक्रिय है।',
    easyModeDisabled: 'सामान्य मोड सक्रिय है।',

    myHealth: 'मेरा स्वास्थ्य',
    myHealthSub: 'पानी, नींद, कदम और स्वास्थ्य ट्रैकिंग',
    findDoctor: 'डॉक्टर खोजें',
    findDoctorSub: 'नजदीकी प्रमाणित डॉक्टर और क्लीनिक',
    medicines: 'दवाइयाँ',
    medicinesSub: 'डॉक्टर द्वारा दी गई दवाएं और रिमाइंडर',
    nearbyHospital: 'नजदीकी अस्पताल',
    nearbyHospitalSub: 'इमरजेंसी ट्रॉमा सेंटर और बेड',
    emergency: 'आपातकाल',
    emergencySub: 'तत्काल SOS और स्मार्ट एम्बुलेंस',

    navHome: 'होम',
    navAssistant: 'सहायक',
    navHealth: 'स्वास्थ्य',
    navDoctor: 'डॉक्टर',
    navMedicines: 'दवाइयाँ',
    navEmergency: 'आपातकाल',

    easyMode: 'आसान मोड (बड़े बटन)',
    easyModeActive: 'आसान मोड सक्रिय है',
    languageSelect: 'भाषा',
    medicalDisclaimerNotice: 'मेडि मित्र सामान्य स्वास्थ्य जानकारी देता है। यह डॉक्टर का विकल्प नहीं है।',

    symptomCheckerTitle: 'लक्षणों की सरल जांच',
    symptomCheckerSub: 'अपनी परेशानी पर टैप करें या बोलकर बताएं।',
    tapSymptomsBelow: 'आपको क्या परेशानी महसूस हो रही है:',
    headache: 'सिरदर्द',
    fever: 'बुखार',
    cough: 'खांसी',
    stomachProblem: 'पेट की समस्या',
    breathingProblem: 'सांस लेने में तकलीफ',
    bodyPain: 'शरीर में दर्द',
    tellByVoice: 'बोलकर बताएं',
    otherProblem: 'अन्य लक्षण',
    symptomNextStep: 'उचित अगला कदम',
    routineCare: 'सामान्य देखभाल व आराम',
    promptDoctorVisit: 'डॉक्टर से परामर्श लें',
    immediateEmergency: 'तुरंत अस्पताल जाएं',

    water: 'पानी',
    waterGoal: 'दैनिक लक्ष्य',
    addWater250: '+ 250 मि.ली.',
    sleep: 'नींद',
    sleepHours: 'आज के घंटे',
    activity: 'शारीरिक गतिविधि',
    steps: 'कदम',
    activeMinutes: 'सक्रिय मिनट',
    mood: 'मनोदशा (मूड)',
    moodGood: 'अच्छा',
    moodOkay: 'ठीक',
    moodNeutral: 'सामान्य',
    moodLow: 'उदास',
    moodStressed: 'तनावग्रस्त',
    nutritionGuidance: 'स्वास्थ्यवर्धक आहार',
    wellnessInsight: 'स्वास्थ्य सलाह',

    medicineReminders: 'दवाई समय सारिणी',
    medicineTime: 'दवाई का समय',
    taken: 'ले ली',
    remindLater: 'बाद में याद दिलाएं',
    morning: 'सुबह',
    afternoon: 'दोपहर',
    night: 'रात',
    addPrescription: 'पर्चे की दवाई जोड़ें',

    emergencyHelp: 'आपातकालीन सहायता',
    emergencyActivated: 'आपातकालीन सेवा सक्रिय की गई। कृपया शांत रहें।',
    stayCalm: 'नजदीकी अस्पताल और सहायता केंद्र को सूचित कर दिया गया है।',
    callingAmbulance: 'एम्बुलेंस भेजी जा चुकी है और ग्रीन कॉरिडोर सक्रिय है।',
    nearestHospital: 'निकटतम आपातकालीन अस्पताल',
    eta: 'पहुंचने का समय',
    smartTrafficHero: 'स्मार्ट एम्बुलेंस ट्रैफिक कोऑर्डिनेशन',
    trafficCorridorCleared: 'ट्रैफिक ग्रीन कॉरिडोर: सिग्नल क्लियर',
    simulationNotice: 'लाइव डेमो / सिम्युलेटेड ट्रैफिक समन्वय',
    callDoctor: 'कॉल करें',
    getDirections: 'दिशा-निर्देश देखें',
  },

  ta: {
    appName: 'MediMitra',
    tagline: 'உங்கள் உடல்நலம். உங்கள் தோழன். உங்கள் பாதுகாப்பு.',
    howCanIHelp: 'இன்று நான் உங்களுக்கு எவ்வாறு உதவ முடியும்?',
    talkToMediMitra: 'பேசுங்கள்',
    tapToSpeak: 'பேச தட்டவும்',
    listening: 'உங்கள் குரலைக் கேட்கிறோம்...',
    speakNow: 'நீங்கள் எப்படி உணர்கிறீர்கள் என்பதைப் பேசுங்கள்...',
    speakAgain: 'மீண்டும் பேசுங்கள்',
    listen: 'கேளுங்கள்',
    stopListening: 'முடிக்கப்பட்டது',
    voiceInputDesc: 'அறிகுறிகளைக் கூறுங்கள், மருந்து நேரம் கேளுங்கள் அல்லது அவசர உதவி கோருங்கள்.',

    // Dynamic Language-Specific Buttons
    askMediMitra: 'மேடிமித்ராவிடம் கேளுங்கள்',
    speak: 'பேசுங்கள்',
    speakNaturallyDesc: 'இயல்பாகப் பேசுங்கள். மேடிமித்ரா கேட்டு பதிலளிக்கும்.',
    askPlaceholder: 'உங்கள் உடல்நலம் பற்றி கேளுங்கள்...',
    callEmergency: 'அவசர உதவிக்கு அழைக்கவும்',
    emergencyVoiceAnnouncement: 'அவசர உதவி செயல்படுத்தப்பட்டது. உங்கள் தற்போதைய இடத்தை கண்டறிகிறோம். அருகிலுள்ள மருத்துவமனையைத் தேடுகிறோம்.',
    emergencyVoiceTitle: '🚑 அவசர குரல் அறிவிப்பு',
    requestAmbulance: 'ஆம்புலன்ஸ் கோருங்கள்',
    notifyFamily: 'குடும்பத்திற்கு தெரிவிக்கவும்',
    emergencyActiveSOS: 'அவசர SOS இயக்கத்தில் உள்ளது',
    waterLoggedSuccess: '250 மி.லி தண்ணீர் பதிவு செய்யப்பட்டது. மிக நன்று!',
    talkIntro: 'மேடிமித்ராவிடம் பேசுங்கள். உங்கள் உடல்நலம் பற்றிக் கூறுங்கள்.',
    initialAssistantGreeting: 'வணக்கம்! நான் உங்கள் தனிப்பட்ட சுகாதார உதவியாளர் மேடிமித்ரா. உங்கள் கேள்வியைப் பேசுங்கள் அல்லது தட்டச்சு செய்யுங்கள்.',
    notFeelingWell: 'எனக்கு உடல்நலம் சரியில்லை',
    notFeelingWellQuery: 'எனக்கு உடல்நலம் சரியில்லை, லேசான தலைவலியும் சோர்வும் உள்ளது. என்ன செய்ய வேண்டும்?',
    medicineRoutineQuery: 'மருத்துவர் பரிந்துரைத்த மருந்துகளை சரியான நேரத்தில் எடுப்பது எப்படி?',
    doctorAdviceQuery: 'எந்த அறிகுறிகளுக்கு மருத்துவரை உடனடியாக அணுக வேண்டும்?',
    emergencyQuery: 'மார்பு வலி போன்ற அவசர நிலைகளில் என்ன செய்ய வேண்டும்?',
    emergencyStep1: 'அவசர நிலை கண்டறியப்பட்டது.',
    emergencyStep2: 'உங்கள் தற்போதைய இடத்தை கண்டறிகிறோம்.',
    emergencyStep3: 'அருகிலுள்ள மருத்துவமனையைத் தேடுகிறோம்.',
    emergencyStep4: 'ஆம்புலன்ஸ் பாதையைத் தயார் செய்கிறோம்.',
    listenToVoice: 'குரலைக் கேளுங்கள்',
    listenToInstructions: 'வழிமுறைகளைக் கேளுங்கள்',
    replay: 'மீண்டும் கேளுங்கள்',
    typeOrSpeak: 'தட்டச்சு செய்து அல்லது பேசி கேளுங்கள்',
    quickPrompts: 'விரைவு கேள்விகள்',
    conversationHistory: 'உரையாடல் வரலாறு',
    stop: 'நிறுத்துங்கள்',
    speaking: 'பேசுகிறது...',
    doseTaken: 'மருந்து உட்கொண்டது பதிவு செய்யப்பட்டது. நன்று.',
    easyModeEnabled: 'பெரிய பொத்தான்களுடன் எளிய முறை இயக்கப்பட்டது.',
    easyModeDisabled: 'வழக்கமான முறை இயக்கப்பட்டது.',

    myHealth: 'என் உடல்நலம்',
    myHealthSub: 'தண்ணீர், தூக்கம், நடை & நலவாழ்வு',
    findDoctor: 'மருத்துவரைத் தேடுங்கள்',
    findDoctorSub: 'அருகிலுள்ள கிளினிக்குகள் & நிபுணர்கள்',
    medicines: 'மருந்துகள்',
    medicinesSub: 'மருத்துவ சீட்டு & தினசரி நினைவூட்டல்கள்',
    nearbyHospital: 'அருகிலுள்ள மருத்துவமனை',
    nearbyHospitalSub: 'அவசர சிகிச்சை மையங்கள் & படுக்கைகள்',
    emergency: 'அவசரம்',
    emergencySub: 'உடனடி SOS & ஸ்மார்ட் ஆம்புலன்ஸ் பாதை',

    navHome: 'முகப்பு',
    navAssistant: 'உதவியாளர்',
    navHealth: 'உடல்நலம்',
    navDoctor: 'மருத்துவர்',
    navMedicines: 'மருந்துகள்',
    navEmergency: 'அவசரம்',

    easyMode: 'எளிய முறை',
    easyModeActive: 'எளிய முறை இயக்கத்தில் உள்ளது (பெரிய காட்சி)',
    languageSelect: 'மொழி',
    medicalDisclaimerNotice: 'மேடிமித்ரா பொதுவான சுகாதார தகவல்களை மட்டுமே வழங்குகிறது. இது மருத்துவருக்கு மாற்றாகாது.',

    symptomCheckerTitle: 'அறிகுறி வழிகாட்டி',
    symptomCheckerSub: 'நீங்கள் உணர்வதை தட்டவும் அல்லது பேசவும்.',
    tapSymptomsBelow: 'உங்கள் அறிகுறிகளைத் தேர்ந்தெடுக்கவும்:',
    headache: 'தலைவலி',
    fever: 'காய்ச்சல்',
    cough: 'இருமல்',
    stomachProblem: 'வயிற்று வலி',
    breathingProblem: 'சுவாசப் பிரச்சனை',
    bodyPain: 'உடல் வலி',
    tellByVoice: 'குரல் மூலம் சொல்லுங்கள்',
    otherProblem: 'வேறு அறிகுறி',
    symptomNextStep: 'பரிந்துரைக்கப்பட்ட அடுத்த படி',
    routineCare: 'வீட்டு பராமரிப்பு & நீர்ச்சத்து',
    promptDoctorVisit: 'மருத்துவரை அணுகவும்',
    immediateEmergency: 'உடனடி அவசர சிகிச்சை பெறவும்',

    water: 'தண்ணீர்',
    waterGoal: 'தினசரி இலக்கு',
    addWater250: '+ 250 மி.லி',
    sleep: 'தூக்கம்',
    sleepHours: 'இன்றைய மணிநேரம்',
    activity: 'நடவடிக்கை',
    steps: 'நடைகள்',
    activeMinutes: 'செயலில் உள்ள நிமிடங்கள்',
    mood: 'மனநிலை',
    moodGood: 'நன்றாக உள்ளது',
    moodOkay: 'பரவாயில்லை',
    moodNeutral: 'இயல்பு',
    moodLow: 'சோர்வு',
    moodStressed: 'மன அழுத்தம்',
    nutritionGuidance: 'ஊட்டச்சத்து வழிகாட்டி',
    wellnessInsight: 'நலவாழ்வு குறிப்பு',

    medicineReminders: 'மருந்து நினைவூட்டல்கள்',
    medicineTime: 'மருந்து நேரம்',
    taken: 'எடுத்துக்கொண்டேன்',
    remindLater: 'பிறகு நினைவூட்டு',
    morning: 'காலை',
    afternoon: 'மதியம்',
    night: 'இரவு',
    addPrescription: 'மருந்துச் சீட்டைச் சேர்க்கவும்',

    emergencyHelp: 'அவசர உதவி',
    emergencyActivated: 'அவசர முறை செயல்படுத்தப்பட்டது. அமைதியாக இருங்கள்.',
    stayCalm: 'அருகிலுள்ள மருத்துவமனைக்கு தகவல் அனுப்பப்பட்டுள்ளது.',
    callingAmbulance: 'ஆம்புலன்ஸ் அனுப்பப்பட்டது & போக்குவரத்து பாதை சரிசெய்யப்பட்டது',
    nearestHospital: 'அருகிலுள்ள அவசர மருத்துவமனை',
    eta: 'வருகை நேரம்',
    smartTrafficHero: 'ஸ்மார்ட் ஆம்புலன்ஸ் போக்குவரத்து மேலாண்மை',
    trafficCorridorCleared: 'போக்குவரத்து பசுமைப் பாதை இயக்கத்தில் உள்ளது',
    simulationNotice: 'செயல்முறை மாதிரி / போக்குவரத்து ஒருங்கிணைப்பு',
    callDoctor: 'இப்போதே அழைக்கவும்',
    getDirections: 'வழித்தடம் பார்க்கவும்',
  },

  kn: {
    appName: 'MediMitra',
    tagline: 'ನಿಮ್ಮ ಆರೋಗ್ಯ. ನಿಮ್ಮ ಒಡನಾಡಿ. ನಿಮ್ಮ ರಕ್ಷಣೆ.',
    howCanIHelp: 'ಇಂದು ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಲಿ?',
    talkToMediMitra: 'ಮಾತನಾಡಿ',
    tapToSpeak: 'ಮಾತನಾಡಲು ಸ್ಪರ್ಶಿಸಿ',
    listening: 'ನಿಮ್ಮ ಧ್ವನಿಯನ್ನು ಆಲಿಸುತ್ತಿದ್ದೇವೆ...',
    speakNow: 'ನಿಮ್ಮ ಸಮಸ್ಯೆಯನ್ನು ಮುಕ್ತವಾಗಿ ಮಾತನಾಡಿ...',
    speakAgain: 'ಮತ್ತೆ ಮಾತನಾಡಿ',
    listen: 'ಕೇಳಿ',
    stopListening: 'ಮುಕ್ತಾಯವಾಯಿತು',
    voiceInputDesc: 'ಲಕ್ಷಣಗಳನ್ನು ತಿಳಿಸಿ, ಔಷಧದ ಸಮಯ ಕೇಳಿ ಅಥವಾ ತುರ್ತು ಸಹಾಯ ಪಡೆಯಿರಿ.',

    // Dynamic Language-Specific Buttons
    askMediMitra: 'ಮೇಡಿಮಿತ್ರರನ್ನು ಕೇಳಿ',
    speak: 'ಮಾತನಾಡಿ',
    speakNaturallyDesc: 'ಸಹಜವಾಗಿ ಮಾತನಾಡಿ. ಮೇಡಿಮಿತ್ರ ಆಲಿಸಿ ಉತ್ತರಿಸುತ್ತದೆ.',
    askPlaceholder: 'ನಿಮ್ಮ ಆರೋಗ್ಯದ ಬಗ್ಗೆ ಕೇಳಿ...',
    callEmergency: 'ತುರ್ತು ಕರೆ ಮಾಡಿ',
    emergencyVoiceAnnouncement: 'ತುರ್ತು ನೆರವು ಸಕ್ರಿಯಗೊಂಡಿದೆ. ನಿಮ್ಮ ಪ್ರಸ್ತುತ ಸ್ಥಳವನ್ನು ಪತ್ತೆಮಾಡಲಾಗುತ್ತಿದೆ. ಹತ್ತಿರದ ಆಸ್ಪತ್ರೆಯನ್ನು ಹುಡುಕಲಾಗುತ್ತಿದೆ.',
    emergencyVoiceTitle: '🚑 ತುರ್ತು ಧ್ವನಿ ಪ್ರಕಟಣೆ',
    requestAmbulance: 'ಆಂಬ್ಯುಲೆನ್ಸ್ ಕೋರಿ',
    notifyFamily: 'ಕುಟುಂಬಕ್ಕೆ ತಿಳಿಸಿ',
    emergencyActiveSOS: 'ತುರ್ತು SOS ಸಕ್ರಿಯವಾಗಿದೆ',
    waterLoggedSuccess: '250 ಮಿ.ಲೀ ನೀರು ದಾಖಲಿಸಲಾಗಿದೆ. ಉತ್ತಮ ಅಭ್ಯಾಸ!',
    talkIntro: 'ಮೇಡಿಮಿತ್ರ ಜೊತೆ ಮಾತನಾಡಿ. ನಿಮ್ಮ ಆರೋಗ್ಯದ ಬಗ್ಗೆ ತಿಳಿಸಿ.',
    initialAssistantGreeting: 'ನಮಸ್ಕಾರ! ನಾನು ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಆರೋಗ್ಯ ಸಹಾಯಕ ಮೇಡಿಮಿತ್ರ. ಮಾತನಾಡಿ ಅಥವಾ ಟೈಪ್ ಮಾಡಿ ನಿಮ್ಮ ಪ್ರಶ್ನೆ ಕೇಳಿ.',
    notFeelingWell: 'ನನಗೆ ಹುಷಾರಿಲ್ಲ',
    notFeelingWellQuery: 'ನನಗೆ ಹುಷಾರಿಲ್ಲ, ತಲೆನೋವು ಮತ್ತು ಆಯಾಸವಿದೆ. ಏನು ಮಾಡಬೇಕು?',
    medicineRoutineQuery: 'ವೈದ್ಯರು ಸೂಚಿಸಿದ ಔಷಧಗಳನ್ನು ಸಮಯಕ್ಕೆ ಸರಿಯಾಗಿ ತೆಗೆದುಕೊಳ್ಳುವುದು ಹೇಗೆ?',
    doctorAdviceQuery: 'ಯಾವ ಲಕ್ಷಣಗಳಿಗೆ ವೈದ್ಯರನ್ನು ತಕ್ಷಣ ಸಂಪರ್ಕಿಸಬೇಕು?',
    emergencyQuery: 'ಎದೆನೋವಿನಂತಹ ತುರ್ತು ಪರಿಸ್ಥಿತಿಯಲ್ಲಿ ಏನು ಮಾಡಬೇಕು?',
    emergencyStep1: 'ತುರ್ತು ಪರಿಸ್ಥಿತಿ ಪತ್ತೆಯಾಗಿದೆ.',
    emergencyStep2: 'ನಿಮ್ಮ ಪ್ರಸ್ತುತ ಸ್ಥಳವನ್ನು ಪತ್ತೆಮಾಡಲಾಗುತ್ತಿದೆ.',
    emergencyStep3: 'ಹತ್ತಿರದ ಆಸ್ಪತ್ರೆಯನ್ನು ಹುಡುಕಲಾಗುತ್ತಿದೆ.',
    emergencyStep4: 'ಆಂಬ್ಯುಲೆನ್ಸ್ ಮಾರ್ಗವನ್ನು ಸಿದ್ಧಪಡಿಸಲಾಗುತ್ತಿದೆ.',
    listenToVoice: 'ಧ್ವನಿ ಕೇಳಿ',
    listenToInstructions: 'ಸೂಚನೆಗಳನ್ನು ಕೇಳಿ',
    replay: 'ಮತ್ತೆ ಕೇಳಿ',
    typeOrSpeak: 'ಟೈಪ್ ಮಾಡಿ ಅಥವಾ ಮಾತನಾಡಿ ಕೇಳಿ',
    quickPrompts: 'ತ್ವರಿತ ಪ್ರಶ್ನೆಗಳು',
    conversationHistory: 'ಸಂಭಾಷಣೆಯ ಇತಿಹಾಸ',
    stop: 'ನಿಲ್ಲಿಸಿ',
    speaking: 'ಮಾತನಾಡುತ್ತಿದೆ...',
    doseTaken: 'ಔಷಧಿ ತೆಗೆದುಕೊಂಡಿದ್ದನ್ನು ದಾಖಲಿಸಲಾಗಿದೆ. ಧನ್ಯವಾದಗಳು.',
    easyModeEnabled: 'ದೊಡ್ಡ ಬಟನ್‌ಗಳ ಸುಲಭ ವಿಧಾನ ಸಕ್ರಿಯಗೊಂಡಿದೆ.',
    easyModeDisabled: 'ಸಾಮಾನ್ಯ ವಿಧಾನ ಸಕ್ರಿಯಗೊಂಡಿದೆ.',

    myHealth: 'ನನ್ನ ಆರೋಗ್ಯ',
    myHealthSub: 'ನೀರು, ನಿದ್ರೆ, ನಡಿಗೆ ಮತ್ತು ಸ್ವಾಸ್ಥ್ಯ',
    findDoctor: 'ವೈದ್ಯರನ್ನು ಹುಡುಕಿ',
    findDoctorSub: 'ಹತ್ತಿರದ ಕ್ಲಿನಿಕ್‌ಗಳು ಮತ್ತು ತಜ್ಞರು',
    medicines: 'ಔಷಧಿಗಳು',
    medicinesSub: 'ವೈದ್ಯರ ಪ್ರಿಸ್ಕ್ರಿಪ್ಷನ್ ಮತ್ತು ಜ್ಞಾಪನೆಗಳು',
    nearbyHospital: 'ಹತ್ತಿರದ ಆಸ್ಪತ್ರೆ',
    nearbyHospitalSub: 'ತುರ್ತು ಚಿಕಿತ್ಸಾ ಕೇಂದ್ರಗಳು ಮತ್ತು ಹಾಸಿಗೆಗಳು',
    emergency: 'ತುರ್ತು ಪರಿಸ್ಥಿತಿ',
    emergencySub: 'ತ್ವರಿತ SOS ಮತ್ತು ಸ್ಮಾರ್ಟ್ ಆಂಬ್ಯುಲೆನ್ಸ್ ಮಾರ್ಗ',

    navHome: 'ಮುಖಪುಟ',
    navAssistant: 'ಸಹಾಯಕ',
    navHealth: 'ಆರೋಗ್ಯ',
    navDoctor: 'ವೈದ್ಯರು',
    navMedicines: 'ಔಷಧಿಗಳು',
    navEmergency: 'ತುರ್ತು',

    easyMode: 'ಸುಲಭ ವಿಧಾನ',
    easyModeActive: 'ಸುಲಭ ವಿಧಾನ ಸಕ್ರಿಯವಾಗಿದೆ (ದೊಡ್ಡ ಪರದೆ)',
    languageSelect: 'ಭಾಷೆ',
    medicalDisclaimerNotice: 'ಮೇಡಿಮಿತ್ರ ಸಾಮಾನ್ಯ ಆರೋಗ್ಯ ಮಾಹಿತಿಯನ್ನು ನೀಡುತ್ತದೆ. ಇದು ವೈದ್ಯರಿಗೆ ಪರ್ಯಾಯವಲ್ಲ.',

    symptomCheckerTitle: 'ಲಕ್ಷಣಗಳ ಪರಿಶೀಲನೆ',
    symptomCheckerSub: 'ನಿಮಗೆ ಅನುಭವವಾಗುತ್ತಿರುವುದನ್ನು ಸ್ಪರ್ಶಿಸಿ ಅಥವಾ ಮಾತನಾಡಿ.',
    tapSymptomsBelow: 'ನಿಮ್ಮ ಲಕ್ಷಣಗಳನ್ನು ಆಯ್ಕೆಮಾಡಿ:',
    headache: 'ತಲೆನೋವು',
    fever: 'ಜ್ವರ',
    cough: 'ಕೆಮ್ಮು',
    stomachProblem: 'ಹೊಟ್ಟೆ ನೋವು',
    breathingProblem: 'ಉಸಿರಾಟದ ತೊಂದರೆ',
    bodyPain: 'ಮೈಕೈ ನೋವು',
    tellByVoice: 'ಧ್ವನಿಯ ಮೂಲಕ ತಿಳಿಸಿ',
    otherProblem: 'ಇತರ ಲಕ್ಷಣ',
    symptomNextStep: 'ಶಿಫಾರಸು ಮಾಡಿದ ಮುಂದಿನ ಕ್ರಮ',
    routineCare: 'ಮನೆ ಆರೈಕೆ ಮತ್ತು ವಿಶ್ರಾಂತಿ',
    promptDoctorVisit: 'ವೈದ್ಯರನ್ನು ಭೇಟಿ ಮಾಡಿ',
    immediateEmergency: 'ತಕ್ಷಣವೇ ತುರ್ತು ಚಿಕಿತ್ಸೆ ಪಡೆಯಿರಿ',

    water: 'ನೀರು',
    waterGoal: 'ದೈನಂದಿನ ಗುರಿ',
    addWater250: '+ 250 ಮಿ.ಲೀ',
    sleep: 'ನಿದ್ರೆ',
    sleepHours: 'ಇಂದಿನ ಗಂಟೆಗಳು',
    activity: 'ಚಟುವಟಿಕೆ',
    steps: 'ಹೆಜ್ಜೆಗಳು',
    activeMinutes: 'ಸಕ್ರಿಯ ನಿಮಿಷಗಳು',
    mood: 'ಮನಸ್ಥಿತಿ',
    moodGood: 'ಉತ್ತಮ',
    moodOkay: 'ಪರವಾಗಿಲ್ಲ',
    moodNeutral: 'ಸಾಮಾನ್ಯ',
    moodLow: 'ಆಯಾಸ',
    moodStressed: 'ಒತ್ತಡ',
    nutritionGuidance: 'ಆಹಾರ ಪೋಷಣೆ ಮಾರ್ಗದರ್ಶಿ',
    wellnessInsight: 'ಆರೋಗ್ಯ ಒಳನೋಟ',

    medicineReminders: 'ಔಷಧ ಜ್ಞಾಪನೆಗಳು',
    medicineTime: 'ಔಷಧದ ಸಮಯ',
    taken: 'ತೆಗೆದುಕೊಂಡಿದ್ದೇನೆ',
    remindLater: 'ನಂತರ ನೆನಪಿಸು',
    morning: 'ಬೆಳಿಗ್ಗೆ',
    afternoon: 'ಮಧ್ಯಾಹ್ನ',
    night: 'ರಾತ್ರಿ',
    addPrescription: 'ಪ್ರಿಸ್ಕ್ರಿಪ್ಷನ್ ಸೇರಿಸಿ',

    emergencyHelp: 'ತುರ್ತು ಸಹಾಯ',
    emergencyActivated: 'ತುರ್ತು ವಿಧಾನ ಸಕ್ರಿಯಗೊಂಡಿದೆ. ಶಾಂತರಾಗಿರಿ.',
    stayCalm: 'ಹತ್ತಿರದ ಆಸ್ಪತ್ರೆಗೆ ಮಾಹಿತಿ ನೀಡಲಾಗಿದೆ.',
    callingAmbulance: 'ಆಂಬ್ಯುಲೆನ್ಸ್ ಕಳುಹಿಸಲಾಗಿದೆ ಮತ್ತು ಟ್ರಾಫಿಕ್ ಕಾರಿಡಾರ್ ಸಿದ್ಧವಾಗಿದೆ',
    nearestHospital: 'ಹತ್ತಿರದ ತುರ್ತು ಆಸ್ಪತ್ರೆ',
    eta: 'ಆಗಮನದ ಸಮಯ',
    smartTrafficHero: 'ಸ್ಮಾರ್ಟ್ ಆಂಬ್ಯುಲೆನ್ಸ್ ಟ್ರಾಫಿಕ್ ನಿರ್ವಹಣೆ',
    trafficCorridorCleared: 'ಟ್ರಾಫಿಕ್ ಗ್ರೀನ್ ಕಾರಿಡಾರ್ ಸಕ್ರಿಯವಾಗಿದೆ',
    simulationNotice: 'ಡೆಮೊ ಪ್ರದರ್ಶನ / ಟ್ರಾಫಿಕ್ ಸಂಯೋಜನೆ',
    callDoctor: 'ಈಗಲೇ ಕರೆ ಮಾಡಿ',
    getDirections: 'ಮಾರ್ಗ ನೋಡಿ',
  },
};

/**
 * High-Quality Voice Service with Native Female Synthesis
 * - Enforces dynamic native TTS locale (te-IN, hi-IN, en-IN, ta-IN, kn-IN)
 * - Prioritizes high-fidelity, natural female voices (Microsoft Natural, Google, Apple)
 * - NEVER uses an English voice as a fallback for Indian languages (Telugu, Hindi, Tamil, Kannada)
 * - Cleans emojis, markdown asterisks/headers/bullets, citations, URLs, and code
 * - Splits speech into logical sentences with natural 350-400 ms pauses between them
 * - Speech rate: slow-to-moderate (0.88), Pitch: natural female (1.08), Volume: maximum safe (1.0)
 */
export class SpeechService {
  private static synth: SpeechSynthesis | null =
    typeof window !== 'undefined' && 'speechSynthesis' in window ? window.speechSynthesis : null;
  private static currentUtterance: SpeechSynthesisUtterance | null = null;
  private static voiceCache: SpeechSynthesisVoice[] = [];
  private static sentenceQueue: string[] = [];
  private static queueIndex = 0;
  private static currentLang: Language = 'en';
  private static onStartCallback?: () => void;
  private static onEndCallback?: () => void;
  private static isSpeakingNow = false;
  private static pauseTimer: any = null;
  private static isCancelled = false;
  private static initialized = false;

  public static init(): void {
    if (typeof window === 'undefined' || !this.synth || this.initialized) return;
    this.initialized = true;

    this.refreshVoices();

    if ('onvoiceschanged' in this.synth) {
      this.synth.onvoiceschanged = () => {
        this.refreshVoices();
      };
    }
  }

  public static refreshVoices(): SpeechSynthesisVoice[] {
    if (!this.synth) return [];
    try {
      const voices = this.synth.getVoices();
      if (voices && voices.length > 0) {
        this.voiceCache = voices;
      }
      return this.voiceCache;
    } catch {
      return this.voiceCache;
    }
  }

  private static getVoices(): SpeechSynthesisVoice[] {
    if (!this.synth) return [];
    const fresh = this.synth.getVoices();
    if (fresh && fresh.length > 0) {
      this.voiceCache = fresh;
      return fresh;
    }
    return this.voiceCache;
  }

  /**
   * Sanitizes text for audio playback:
   * - Strips emojis and pictographs
   * - Strips markdown (asterisks, hashtags, underscores, strikethroughs, horizontal rules)
   * - Strips URLs, HTML tags, and code blocks
   * - Strips bullet points, citations [1], and list markers
   * - Normalizes spacing and punctuation
   */
  public static cleanTextForSpeech(rawText: string): string {
    if (!rawText) return '';

    let cleaned = rawText
      // 1. Remove markdown links [text](url) -> text
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      // 2. Remove URLs
      .replace(/https?:\/\/\S+/gi, '')
      // 3. Remove code blocks and inline code
      .replace(/```[\s\S]*?```/g, '')
      .replace(/`[^`]*`/g, '')
      // 4. Remove HTML tags
      .replace(/<[^>]+>/g, '')
      // 5. Remove all emojis and miscellaneous pictographs/symbols
      .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE00}-\u{FE0F}\u{1F900}-\u{1F9FF}\u{1F600}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{2300}-\u{23FF}\u{2B50}\u{200D}]/gu, '')
      // 6. Remove specific UI symbols
      .replace(/[•●▪►★✔✓⚠️🚨🚑💊🩺💧😴🚶❤️💙🧡💚🩺⏱️📍🧭📱🏥]/g, '')
      // 7. Remove markdown headers
      .replace(/^#{1,6}\s+/gm, '')
      // 8. Remove markdown styling symbols
      .replace(/[*_~#]/g, '')
      // 9. Remove horizontal rule lines
      .replace(/^[-*_]{3,}\s*$/gm, '')
      // 10. Remove bullet markers at beginning of lines
      .replace(/^\s*[-+*]\s+/gm, '')
      // 11. Remove numbered list prefixes like "1. " or "2) "
      .replace(/^\s*\d+[\.\)]\s+/gm, '')
      // 12. Remove bracketed citations like [1], [note]
      .replace(/\[\s*\d+\s*\]/g, '')
      // 13. Remove remaining raw brackets
      .replace(/[\[\]{}()]/g, '')
      // 14. Convert long dashes or double hyphens into a comma pause
      .replace(/--+/g, ', ')
      .replace(/\s+-\s+/g, ', ')
      // 15. Normalize punctuation duplicates
      .replace(/!{2,}/g, '!')
      .replace(/\?{2,}/g, '?')
      .replace(/\.{2,}/g, '.')
      // 16. Collapse excessive whitespace
      .replace(/\s+/g, ' ')
      .trim();

    return cleaned;
  }

  /**
   * Splits text into natural sentences for paced audio delivery with pauses
   */
  public static splitIntoSentences(text: string): string[] {
    if (!text) return [];

    // Split on sentence boundaries: period, exclamation, question mark, Devanagari danda, or newlines
    const matches = text.match(/[^.!?।\n]+(?:[.!?।]+|\s*$)/gu);
    if (!matches) return [text.trim()].filter(Boolean);

    return matches
      .map((s) => s.trim())
      .filter((s) => {
        // Only keep fragments that contain speakable characters
        return s.length > 0 && /[\p{L}\p{N}]/u.test(s);
      });
  }

  /**
   * Find the highest quality native female voice for the specified language.
   * Priority:
   * 1. Target locale exact match (e.g. te-IN, hi-IN, ta-IN, kn-IN, en-IN)
   * 2. Female voice keywords & Natural/Neural/Google high-fidelity keywords
   * 3. For English: strongly prioritizes Indian English (en-IN) female voices
   * 4. CRITICAL: For non-English Indian languages, NEVER return an English voice!
   */
  public static findNativeFemaleVoice(lang: Language): SpeechSynthesisVoice | null {
    this.init();
    const voices = this.getVoices();
    if (!voices || voices.length === 0) return null;

    const config = getLanguageConfig(lang);
    const targetLocale = config.ttsLocale.toLowerCase().replace('_', '-');
    const targetCode = config.code.toLowerCase();

    // Filter eligible voices strictly by target language
    const eligibleVoices = voices.filter((v) => {
      const vLang = v.lang.toLowerCase().replace('_', '-');
      const vName = v.name.toLowerCase();

      if (lang === 'en') {
        return vLang.startsWith('en') || vName.includes('english');
      }

      return (
        vLang === targetLocale ||
        vLang.startsWith(targetCode + '-') ||
        vLang === targetCode ||
        vName.includes(config.language.toLowerCase()) ||
        vName.includes(config.nativeName.toLowerCase())
      );
    });

    if (eligibleVoices.length === 0) {
      // Return null so the browser synthesizes with utterance.lang = targetLocale
      // This prevents pronouncing Indian text with an English accent
      return null;
    }

    const genericFemaleKeywords = [
      'female', 'woman', 'girl', 'she', 'lady', 'heera', 'neerja', 'veena',
      'swara', 'kalpana', 'shruti', 'chitra', 'geeta', 'sunita', 'priya',
      'ananya', 'sapna', 'vani', 'samantha', 'victoria', 'karen', 'zira', 'jenny', 'raveena'
    ];

    const searchFemaleKeywords = [
      ...config.preferredFemaleVoices.map((k) => k.toLowerCase()),
      ...genericFemaleKeywords,
    ];

    const maleKeywords = [
      'male', 'man', 'boy', 'guy', 'david', 'george', 'mark', 'ravi',
      'mohan', 'hemant', 'valluvar', 'pradeep', 'madhur'
    ];

    let bestVoice: SpeechSynthesisVoice | null = null;
    let bestScore = -Infinity;

    for (const voice of eligibleVoices) {
      const vLang = voice.lang.toLowerCase().replace('_', '-');
      const vName = voice.name.toLowerCase();
      let score = 0;

      // 1. Language and Locale matching
      if (vLang === targetLocale) {
        score += 60; // Exact locale match like te-IN, hi-IN, en-IN
      } else if (vLang.startsWith(targetCode)) {
        score += 40;
      } else {
        score += 20;
      }

      // For English: high priority for Indian English (en-IN / India)
      if (lang === 'en') {
        if (vLang.includes('en-in') || vName.includes('india') || vName.includes('indian')) {
          score += 70;
        }
      }

      // 2. Female name and keyword matching
      if (searchFemaleKeywords.some((kw) => vName.includes(kw))) {
        score += 40;
      }

      // 3. High quality natural/neural audio keywords
      if (vName.includes('natural') || vName.includes('online') || vName.includes('neural')) {
        score += 30;
      }

      // 4. Modern Google voices
      if (vName.includes('google')) {
        score += 20;
      }

      // 5. Penalize explicit male voices
      if (maleKeywords.some((kw) => vName.includes(kw))) {
        score -= 50;
      }

      if (score > bestScore) {
        bestScore = score;
        bestVoice = voice;
      }
    }

    return bestVoice;
  }

  /**
   * Plays the next sentence in the queue with a 380 ms natural pause between sentences.
   */
  private static playNextSentence(): void {
    if (this.isCancelled || !this.synth) return;

    if (this.queueIndex >= this.sentenceQueue.length) {
      this.isSpeakingNow = false;
      this.currentUtterance = null;
      if (this.onEndCallback) {
        this.onEndCallback();
      }
      return;
    }

    const sentence = this.sentenceQueue[this.queueIndex];
    const utterance = new SpeechSynthesisUtterance(sentence);
    const config = getLanguageConfig(this.currentLang);

    // 1. Enforce native TTS locale
    utterance.lang = config.ttsLocale;

    // 2. Voice settings:
    // - Speech rate: slightly slower than normal (0.88) - calm, not rushed, easy for elderly/low-literacy users
    // - Pitch: natural female voice (1.08) - warm, pleasant, calm
    // - Volume: maximum safe volume (1.0) - clearly audible, comfortable
    utterance.rate = 0.88;
    utterance.pitch = 1.08;
    utterance.volume = 1.0;

    // 3. Assign native female voice
    const nativeVoice = this.findNativeFemaleVoice(this.currentLang);
    if (nativeVoice) {
      utterance.voice = nativeVoice;
    }

    utterance.onstart = () => {
      if (this.queueIndex === 0 && this.onStartCallback) {
        this.onStartCallback();
      }
    };

    utterance.onend = () => {
      if (this.isCancelled) return;
      this.queueIndex++;

      if (this.queueIndex < this.sentenceQueue.length) {
        // Natural 380 ms pause between sentences (within 300–500 ms requirement)
        this.pauseTimer = window.setTimeout(() => {
          this.playNextSentence();
        }, 380);
      } else {
        this.isSpeakingNow = false;
        this.currentUtterance = null;
        if (this.onEndCallback) {
          this.onEndCallback();
        }
      }
    };

    utterance.onerror = (e) => {
      console.warn('SpeechSynthesis sentence error:', e);
      if (this.isCancelled) return;
      this.queueIndex++;

      if (this.queueIndex < this.sentenceQueue.length) {
        this.pauseTimer = window.setTimeout(() => {
          this.playNextSentence();
        }, 200);
      } else {
        this.isSpeakingNow = false;
        this.currentUtterance = null;
        if (this.onEndCallback) {
          this.onEndCallback();
        }
      }
    };

    this.currentUtterance = utterance;
    this.synth.speak(utterance);
  }

  /**
   * Speaks the response with high-quality native female synthesis:
   * - Cleans text of emojis, markdown, symbols, and UI code
   * - Splits into sentences
   * - Plays sequentially with a 380 ms pause between sentences
   */
  public static speak(
    text: string,
    lang: Language = 'en',
    onStart?: () => void,
    onEnd?: () => void
  ): void {
    this.init();

    if (!this.synth) {
      console.warn('Speech synthesis not supported in this browser.');
      if (onEnd) onEnd();
      return;
    }

    try {
      // Cancel previous speech and reset timers
      this.stop();

      const cleanText = this.cleanTextForSpeech(text);
      if (!cleanText) {
        if (onEnd) onEnd();
        return;
      }

      const sentences = this.splitIntoSentences(cleanText);
      if (sentences.length === 0) {
        if (onEnd) onEnd();
        return;
      }

      this.sentenceQueue = sentences;
      this.queueIndex = 0;
      this.currentLang = lang;
      this.onStartCallback = onStart;
      this.onEndCallback = onEnd;
      this.isCancelled = false;
      this.isSpeakingNow = true;

      this.playNextSentence();
    } catch (err) {
      console.warn('Unable to trigger speech:', err);
      this.isSpeakingNow = false;
      if (onEnd) onEnd();
    }
  }

  public static stop(): void {
    this.isCancelled = true;
    if (this.pauseTimer !== null) {
      clearTimeout(this.pauseTimer);
      this.pauseTimer = null;
    }
    this.sentenceQueue = [];
    this.queueIndex = 0;

    if (this.synth) {
      this.synth.cancel();
    }
    this.currentUtterance = null;

    if (this.isSpeakingNow) {
      this.isSpeakingNow = false;
      if (this.onEndCallback) {
        this.onEndCallback();
      }
    }
  }

  public static isSpeaking(): boolean {
    return this.isSpeakingNow || (this.synth ? this.synth.speaking : false);
  }
}
