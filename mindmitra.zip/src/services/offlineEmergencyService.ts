import { UserProfile, PrescribedMedicine, DoctorOrClinic } from '../types/index.ts';

export interface EmergencyHelpline {
  id: string;
  name: string;
  nameTe: string;
  nameHi: string;
  number: string;
  category: 'ambulance' | 'emergency' | 'police' | 'women' | 'mental_health' | 'health_info';
  description: string;
  isPrimary?: boolean;
}

export interface OfflineFirstAidGuide {
  id: string;
  title: string;
  titleTe: string;
  titleHi: string;
  emoji: string;
  summary: string;
  action: string;
  audioText: {
    en: string;
    te: string;
    hi: string;
    ta: string;
    kn: string;
  };
}

export const ESSENTIAL_OFFLINE_HELPLINES: EmergencyHelpline[] = [
  {
    id: 'sos_108',
    name: 'National Ambulance & Medical SOS',
    nameTe: 'జాతీయ అంబులెన్స్ సర్వీస్',
    nameHi: 'राष्ट्रीय एम्बुलेंस सेवा',
    number: '108',
    category: 'ambulance',
    description: 'Toll-free 24/7 medical emergency & immediate ambulance dispatch across India.',
    isPrimary: true,
  },
  {
    id: 'sos_112',
    name: 'National Unified Emergency Helpline',
    nameTe: 'జాతీయ అత్యవసర హెల్ప్‌లైన్',
    nameHi: 'राष्ट्रीय आपातकालीन हेल्पलाइन',
    number: '112',
    category: 'emergency',
    description: 'All-in-one emergency response service (Police, Fire, Ambulance, Disaster).',
    isPrimary: true,
  },
  {
    id: 'police_100',
    name: 'Police Control Room',
    nameTe: 'పోలీస్ కంట్రోల్ రూమ్',
    nameHi: 'पुलिस कंट्रोल रूम',
    number: '100',
    category: 'police',
    description: 'Immediate law enforcement and public security assistance.',
  },
  {
    id: 'fire_101',
    name: 'Fire & Rescue Service',
    nameTe: 'అగ్నిమాపక & రెస్క్యూ సేవలు',
    nameHi: 'दमकल और बचाव सेवा',
    number: '101',
    category: 'emergency',
    description: 'Fire breakouts, chemical hazards, and building rescue.',
  },
  {
    id: 'women_1091',
    name: 'Women Helpline (Domestic & Safety)',
    nameTe: 'మహిళా హెల్ప్‌లైన్',
    nameHi: 'महिला हेल्पलाइन',
    number: '1091',
    category: 'women',
    description: 'Immediate rescue, protection, and distress reporting for women.',
  },
  {
    id: 'mental_health_14416',
    name: 'Tele-MANAS Mental Health Support',
    nameTe: 'టెలి-మానస్ మానసిక ఆరోగ్య హెల్ప్‌లైన్',
    nameHi: 'टेली-मानस मानसिक स्वास्थ्य सेवा',
    number: '14416',
    category: 'mental_health',
    description: '24/7 free psychological counseling and emotional crisis intervention.',
  },
  {
    id: 'health_info_1075',
    name: 'National Health Mission Info Line',
    nameTe: 'జాతీయ ఆరోగ్య సమాచార హెల్ప్‌లైన్',
    nameHi: 'राष्ट्रीय स्वास्थ्य हेल्पलाइन',
    number: '1075',
    category: 'health_info',
    description: 'General health guidance, government hospital queries, and disease info.',
  },
];

export const OFFLINE_FIRST_AID_GUIDES: OfflineFirstAidGuide[] = [
  {
    id: 'heart_attack',
    title: 'Heart Attack Warning Signs',
    titleTe: 'గుండెపోటు హెచ్చరిక సంకేతాలు',
    titleHi: 'दिल के दौरे के संकेत',
    emoji: '🫀',
    summary: 'Chest tightness, pain spreading to left arm/jaw, shortness of breath, cold sweat.',
    action: 'Keep patient seated upright and calm. Loosen tight clothing. Call 108 immediately. Do not allow walking.',
    audioText: {
      en: 'Heart attack warning signs: Chest pressure, pain radiating to the left arm or jaw, shortness of breath, and cold sweat. Immediately call 108 or 112. Keep the person sitting upright, loosen tight collar, and remain calm.',
      te: 'గుండెపోటు సంకేతాలు: ఛాతీలో ఒత్తిడి, ఎడమ చేతికి నొప్పి వ్యాపించడం, శ్వాస ఆడకపోవడం. వెంటనే 108 లేదా 112 కి కాల్ చేయండి. రోగిని విశ్రాంతిగా కూర్చోబెట్టండి.',
      hi: 'दिल के दौरे के लक्षण: सीने में भारीपन, बाएं हाथ या जबड़े में दर्द, सांस फूलना। तुरंत 108 पर कॉल करें और मरीज को शांत सीधा बैठाएं।',
      ta: 'மாரடைப்பு அறிகுறிகள்: நெஞ்சு வலி, இடது கைக்கு வலி பரவுதல், மூச்சுத்திணறல். உடனடியாக 108 அல்லது 112 ஐ அழைக்கவும்.',
      kn: 'ಹೃದಯಾಘಾತದ ಲಕ್ಷಣಗಳು: ಎದೆಯಲ್ಲಿ ತೀವ್ರ ನೋವು, ಎಡ ತೋಳಿಗೆ ನೋವು ಹರಡುವುದು, ಉಸಿರಾಟದ ತೊಂದರೆ. ತಕ್ಷಣವೇ 108 ಗೆ ಕರೆ ಮಾಡಿ.',
    },
  },
  {
    id: 'choking',
    title: 'Choking & Blocked Airway',
    titleTe: 'గొంతులో ఆహారం ఇరుక్కుపోవడం',
    titleHi: 'दम घुटना (चोकिंग)',
    emoji: '🗣️',
    summary: 'Unable to speak or breathe, clutching neck, silent coughing or wheezing.',
    action: 'Give 5 firm back blows between shoulder blades. Follow with 5 abdominal thrusts (Heimlich). Repeat until clear.',
    audioText: {
      en: 'Choking first aid: Deliver 5 sharp back blows between the shoulder blades with the heel of your hand, followed by 5 upward abdominal thrusts (the Heimlich maneuver). Repeat until airway clears.',
      te: 'గొంతులో ఆహారం ఇరుక్కున్నప్పుడు: రోగి వీపుపై 5 సార్లు గట్టిగా కొట్టండి, ఆపై పొట్టపై ఒత్తిడి (హైమ్లిక్ పద్ధతి) చేయండి.',
      hi: 'चोकिंग की स्थिति में: मरीज की पीठ पर 5 बार थपथपाएं और फिर पेट के ऊपरी हिस्से पर अंदर और ऊपर दबाव दें।',
      ta: 'தொண்டை அடைப்பு ஏற்பட்டால்: முதுகு பகுதியில் 5 முறை தட்டவும், பின்னர் வயிற்றை அழுத்தி உதவி செய்யவும்.',
      kn: 'ಉಸಿರುಗಟ್ಟುವಿಕೆ: ಬೆನ್ನಿನ ಮಧ್ಯೆ 5 ಬಾರಿ ತಟ್ಟಿ, ನಂತರ ಹೊಟ್ಟೆಯ ಮೇಲ್ಭಾಗವನ್ನು ಹಿಂದಕ್ಕೆ ಮತ್ತು ಮೇಲಕ್ಕೆ ಒತ್ತಿ.',
    },
  },
  {
    id: 'bleeding',
    title: 'Severe Bleeding & Hemorrhage',
    titleTe: 'తీవ్రమైన రక్తస్రావం',
    titleHi: 'गंभीर रक्तस्राव',
    emoji: '🩸',
    summary: 'Heavy or spurting blood loss from lacerations, cuts, or trauma.',
    action: 'Apply direct, continuous firm pressure using a clean cloth or sterile pad. Elevate injured limb above heart level.',
    audioText: {
      en: 'Severe bleeding first aid: Apply direct continuous firm pressure with a clean cloth or bandage. Do not remove soaked cloths, place another on top. Elevate the wounded limb above heart level.',
      te: 'తీవ్రమైన రక్తస్రావం: శుభ్రమైన గుడ్డతో గాయంపై గట్టిగా నొక్కి పట్టుకోండి. సాధ్యమైతే గాయాన్ని గుండె కంటే ఎత్తులో ఉంచండి.',
      hi: 'गंभीर रक्तस్రాव: साफ कपड़े से घाव पर सीधा दबाव बनाएं। चोट लगे अंग को हृदय के स्तर से ऊपर रखें।',
      ta: 'கடுமையான இரத்தப்போக்கு: சுத்தமான துணியால் காயத்தின் மீது நேரடியாக அழுத்தம் கொடுக்கவும்.',
      kn: 'ತೀವ್ರ ರಕ್ತಸ್ರಾವ: ಸ್ವಚ್ಛವಾದ ಬಟ್ಟೆಯಿಂದ ಗಾಯದ ಮೇಲೆ ನೇರವಾಗಿ ಒತ್ತಡ ಹಾಕಿ ಹಿಡಿದುಕೊಳ್ಳಿ.',
    },
  },
  {
    id: 'burns',
    title: 'Burns & Scalds',
    titleTe: 'కాలిన గాయాలు',
    titleHi: 'जलने पर उपचार',
    emoji: '🔥',
    summary: 'Thermal, steam, or chemical burns on skin surface.',
    action: 'Cool under gentle running cold tap water for 10-20 minutes. Cover loosely with sterile plastic wrap. Never use ice or butter.',
    audioText: {
      en: 'Burn first aid: Cool the affected skin under gentle running cold tap water for at least 10 to 20 minutes. Do not apply ice, toothpaste, or oil. Cover with a clean non-stick dressing.',
      te: 'కాలిన గాయాలు: కనీసం 10 నుండి 20 నిమిషాలు చల్లని ప్రవహించే నీటి కింద ఉంచండి. మంచు, నూనె లేదా టూత్‌పేస్ట్ వేయవద్దు.',
      hi: 'जलने पर: कम से कम 10 से 20 मिनट तक बहते ठंडे पानी के नीचे रखें। बर्फ, तेल या टूथपेस्ट न लगाएं।',
      ta: 'தீக்காயங்கள்: குறைந்தது 10 முதல் 20 நிமிடங்கள் குளிர்ந்த ஓடும் நீரில் காட்டவும்.',
      kn: 'ಸುಟ್ಟ ಗಾಯಗಳು: ಕನಿಷ್ಠ 10 ರಿಂದ 20 ನಿಮಿಷಗಳ ಕಾಲ ತಣ್ಣನೆಯ ಹರಿಯುವ ನೀರಿನಲ್ಲಿ ಇರಿಸಿ. ಮಂಜುಗಡ್ಡೆ ಹಚ್ಚಬೇಡಿ.',
    },
  },
  {
    id: 'seizures',
    title: 'Seizures & Convulsions',
    titleTe: 'మూర్ఛ లేదా ఫిట్స్',
    titleHi: 'दौरे पड़ना (मिरगी)',
    emoji: '⚡',
    summary: 'Sudden tremors, rigid body posture, loss of conscious awareness.',
    action: 'Gently guide onto side into recovery position. Cushion head. Never put anything into mouth. Time the seizure.',
    audioText: {
      en: 'Seizure response: Gently ease the person onto their side into recovery position. Cushion their head. Clear hard objects away. Never put anything in their mouth and do not restrain them.',
      te: 'మూర్ఛ లేదా ఫిట్స్: రోగిని ఒక వైపుకు తిప్పి పడుకోబెట్టండి. తల కింద మెత్తటి గుడ్డ ఉంచండి. నోటిలో ఏమీ పెట్టవద్దు.',
      hi: 'दौरे के समय: मरीज को करवट दिलाकर लिटाएं। सिर के नीचे तकिया रखें। मुंह में कुछ न डालें और हाथ-पैर न पकड़ें।',
      ta: 'வலிப்பு ஏற்பட்டால்: நோயாளியை ஒரு பக்கமாக சாய்த்து படுக்க வைக்கவும். வாயில் எதையும் வைக்க வேண்டாம்.',
      kn: 'ಫಿಟ್ಸ್ ಅಥವಾ ಮೂರ್ಛೆ: ವ್ಯಕ್ತಿಯನ್ನು ಒಂದು ಬದಿಗೆ ಮಲಗಿಸಿ, ತಲೆಯ ಕೆಳಗೆ ಮೆತ್ತನೆಯ ಬಟ್ಟೆ ಇಡಿ. ಬಾಯಿಗೆ ಏನನ್ನೂ ಹಾಕಬೇಡಿ.',
    },
  },
];

export const DEFAULT_OFFLINE_EMERGENCY_FACILITIES: DoctorOrClinic[] = [
  {
    id: 'offline_emg_1',
    name: 'Apollo Trauma & Multi-Specialty Hospital',
    specialty: 'Trauma & Emergency Care',
    category: 'Emergency Care',
    address: 'Plot 23, Health City Boulevard, Near Ring Road',
    phone: '+91 40 2360 7777',
    rating: 4.9,
    distanceKm: 1.4,
    coords: { lat: 28.6295, lng: 77.3765 },
    open24x7: true,
    isEmergencyAvailable: true,
    languages: ['Telugu', 'Hindi', 'English'],
    estimatedWaitMins: 4,
  },
  {
    id: 'offline_emg_2',
    name: 'AIIMS Apex Trauma Center',
    specialty: 'Critical Care & Neurosurgery',
    category: 'Emergency Care',
    address: 'Ring Road, Near Safdarjung Campus',
    phone: '011 2659 8600',
    rating: 4.8,
    distanceKm: 2.8,
    coords: { lat: 28.5672, lng: 77.2100 },
    open24x7: true,
    isEmergencyAvailable: true,
    languages: ['Hindi', 'English'],
    estimatedWaitMins: 6,
  },
  {
    id: 'offline_emg_3',
    name: 'City Care Emergency Clinic & ICU',
    specialty: '24/7 Emergency & Ambulance Hub',
    category: 'Emergency Care',
    address: 'Sector 62 Main Road, Metro Pillar 44',
    phone: '108',
    rating: 4.7,
    distanceKm: 0.9,
    coords: { lat: 28.6280, lng: 77.3740 },
    open24x7: true,
    isEmergencyAvailable: true,
    languages: ['Telugu', 'Hindi', 'English', 'Tamil'],
    estimatedWaitMins: 2,
  },
];

const OFFLINE_STORAGE_KEYS = {
  PROFILE: 'medimitra_offline_profile',
  MEDICINES: 'medimitra_offline_medicines',
  FACILITIES: 'medimitra_offline_facilities',
  LAST_SYNCED: 'medimitra_offline_last_synced',
};

/**
 * Offline Emergency & Health Data Management Service
 * Ensures critical medical profile, emergency contacts, medicine schedule,
 * and first-aid instructions remain immediately accessible even when
 * connectivity is completely offline.
 */
export const OfflineEmergencyService = {
  saveProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(OFFLINE_STORAGE_KEYS.PROFILE, JSON.stringify(profile));
      localStorage.setItem(OFFLINE_STORAGE_KEYS.LAST_SYNCED, new Date().toISOString());
    } catch (e) {
      console.warn('Unable to cache profile offline:', e);
    }
  },

  getProfile(): UserProfile | null {
    try {
      const data = localStorage.getItem(OFFLINE_STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  saveMedicines(medicines: PrescribedMedicine[]): void {
    try {
      localStorage.setItem(OFFLINE_STORAGE_KEYS.MEDICINES, JSON.stringify(medicines));
      localStorage.setItem(OFFLINE_STORAGE_KEYS.LAST_SYNCED, new Date().toISOString());
    } catch (e) {
      console.warn('Unable to cache medicines offline:', e);
    }
  },

  getMedicines(): PrescribedMedicine[] {
    try {
      const data = localStorage.getItem(OFFLINE_STORAGE_KEYS.MEDICINES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveEmergencyFacilities(facilities: DoctorOrClinic[]): void {
    try {
      localStorage.setItem(OFFLINE_STORAGE_KEYS.FACILITIES, JSON.stringify(facilities));
    } catch (e) {
      console.warn('Unable to cache facilities offline:', e);
    }
  },

  getEmergencyFacilities(): DoctorOrClinic[] {
    try {
      const data = localStorage.getItem(OFFLINE_STORAGE_KEYS.FACILITIES);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return DEFAULT_OFFLINE_EMERGENCY_FACILITIES;
    } catch {
      return DEFAULT_OFFLINE_EMERGENCY_FACILITIES;
    }
  },

  getLastSyncTime(): string | null {
    return localStorage.getItem(OFFLINE_STORAGE_KEYS.LAST_SYNCED);
  },

  getEmergencyHelplines(): EmergencyHelpline[] {
    return ESSENTIAL_OFFLINE_HELPLINES;
  },

  getFirstAidGuides(): OfflineFirstAidGuide[] {
    return OFFLINE_FIRST_AID_GUIDES;
  },
};
