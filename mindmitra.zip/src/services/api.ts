import {
  UserProfile,
  AuthResponse,
  MoodEntry,
  PrescribedMedicine,
  WellnessData,
  DoctorOrClinic,
  AmbulanceDispatch,
  SymptomAnalysisResult,
  ChatResponse,
} from '../types/index.ts';
import { OfflineEmergencyService } from './offlineEmergencyService.ts';

const TOKEN_KEY = 'mindmitra_jwt_token';

export const authStorage = {
  getToken: () => localStorage.getItem(TOKEN_KEY),
  setToken: (token: string) => localStorage.setItem(TOKEN_KEY, token),
  clearToken: () => localStorage.removeItem(TOKEN_KEY),
};

async function apiRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = authStorage.getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  } else {
    // If no token, also send demo fallback header for seamless initial load
    headers['x-demo-user'] = 'true';
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || 'An unexpected error occurred. Please try again.');
  }

  return data as T;
}

export const api = {
  // Auth
  login: (credentials: { email: string; password: string }) =>
    apiRequest<AuthResponse>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),

  register: (payload: any) =>
    apiRequest<AuthResponse>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  demoLogin: () =>
    apiRequest<AuthResponse>('/api/auth/demo', {
      method: 'POST',
    }),

  getCurrentUser: async () => {
    try {
      const data = await apiRequest<{ user: UserProfile }>('/api/auth/me');
      if (data?.user) {
        OfflineEmergencyService.saveProfile(data.user);
      }
      return data;
    } catch (err) {
      // Offline fallback: load cached health profile
      const cachedProfile = OfflineEmergencyService.getProfile();
      if (cachedProfile) {
        return { user: cachedProfile };
      }
      throw err;
    }
  },

  updateProfile: async (profile: Partial<UserProfile>) => {
    const res = await apiRequest<{ message: string; user: UserProfile }>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(profile),
    });
    if (res?.user) {
      OfflineEmergencyService.saveProfile(res.user);
    }
    return res;
  },

  // AI Assistant & Symptom Checker
  chatAssistant: (message: string, language?: string) =>
    apiRequest<ChatResponse>('/api/ai/chat', {
      method: 'POST',
      body: JSON.stringify({ message, language }),
    }),

  checkSymptoms: (symptoms: string, duration?: string, language?: string) =>
    apiRequest<SymptomAnalysisResult>('/api/ai/symptom-check', {
      method: 'POST',
      body: JSON.stringify({ symptoms, duration, language }),
    }),

  // Mental Well-being
  getMoodHistory: () => apiRequest<{ logs: MoodEntry[] }>('/api/mood/history'),

  logMood: (data: Partial<MoodEntry>) =>
    apiRequest<{ message: string; log: MoodEntry }>('/api/mood/log', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  deleteMoodLog: (id: string) =>
    apiRequest<{ message: string }>(`/api/mood/${id}`, {
      method: 'DELETE',
    }),

  // Prescribed Medicines
  getMedicines: async () => {
    try {
      const data = await apiRequest<{ medicines: PrescribedMedicine[] }>('/api/medicines');
      if (data?.medicines) {
        OfflineEmergencyService.saveMedicines(data.medicines);
      }
      return data;
    } catch (err) {
      const cached = OfflineEmergencyService.getMedicines();
      if (cached && cached.length > 0) {
        return { medicines: cached };
      }
      throw err;
    }
  },

  addMedicine: (med: Partial<PrescribedMedicine>) =>
    apiRequest<{ message: string; medicine: PrescribedMedicine }>('/api/medicines', {
      method: 'POST',
      body: JSON.stringify(med),
    }),

  markDose: (id: string, timingSlot: string, status: 'taken' | 'skipped') =>
    apiRequest<{ message: string; medicine: PrescribedMedicine }>(`/api/medicines/${id}/take`, {
      method: 'POST',
      body: JSON.stringify({ timingSlot, status }),
    }),

  deleteMedicine: (id: string) =>
    apiRequest<{ message: string }>(`/api/medicines/${id}`, {
      method: 'DELETE',
    }),

  // Wellness Tracking
  getTodayWellness: () => apiRequest<{ wellness: WellnessData }>('/api/wellness/today'),

  getWellnessHistory: () => apiRequest<{ logs: WellnessData[] }>('/api/wellness/history'),

  logWellness: (data: Partial<WellnessData>) =>
    apiRequest<{ message: string; wellness: WellnessData }>('/api/wellness/log', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Doctors & Emergency Facilities
  getNearbyDoctors: (lat?: number, lng?: number, filter?: string) => {
    const params = new URLSearchParams();
    if (lat) params.append('lat', lat.toString());
    if (lng) params.append('lng', lng.toString());
    if (filter) params.append('filter', filter);
    return apiRequest<{ doctors: DoctorOrClinic[]; total: number; notice: string }>(
      `/api/doctors/nearby?${params.toString()}`
    );
  },

  getEmergencyFacilities: async () => {
    try {
      const data = await apiRequest<{ facilities: DoctorOrClinic[] }>('/api/doctors/emergency');
      if (data?.facilities) {
        OfflineEmergencyService.saveEmergencyFacilities(data.facilities);
      }
      return data;
    } catch (err) {
      const cached = OfflineEmergencyService.getEmergencyFacilities();
      return { facilities: cached };
    }
  },

  // Ambulance Coordination (Simulation)
  activateAmbulance: (payload: {
    patientName?: string;
    callerPhone?: string;
    originLat?: number;
    originLng?: number;
    originAddress?: string;
    hospitalId?: string;
  }) =>
    apiRequest<{ message: string; dispatch: AmbulanceDispatch; simulationNotice: string }>(
      '/api/ambulance/activate',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    ),

  getActiveAmbulances: () =>
    apiRequest<{ dispatches: AmbulanceDispatch[] }>('/api/ambulance/active'),

  getAmbulanceById: (id: string) =>
    apiRequest<{ dispatch: AmbulanceDispatch }>(`/api/ambulance/${id}`),

  ackAmbulanceAlert: (id: string) =>
    apiRequest<{ message: string; dispatch: AmbulanceDispatch }>(`/api/ambulance/${id}/ack-alert`, {
      method: 'POST',
    }),

  stepAmbulanceSimulation: (id: string) =>
    apiRequest<{ message: string; dispatch: AmbulanceDispatch }>(`/api/ambulance/${id}/step`, {
      method: 'POST',
    }),

  cancelAmbulance: (id: string) =>
    apiRequest<{ message: string; dispatch: AmbulanceDispatch }>(`/api/ambulance/${id}/cancel`, {
      method: 'POST',
    }),
};
