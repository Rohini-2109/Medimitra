import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Send,
  HeartPulse,
  Siren,
  Stethoscope,
  Pill,
  CheckCircle2,
  MessageSquare,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { useSettings } from '../context/SettingsContext.tsx';
import { HealthAssistantMessage } from '../types/index.ts';

interface Props {
  onNavigateToEmergency?: () => void;
  onNavigateToDoctors?: () => void;
  onNavigateToMedicines?: () => void;
}

export const HealthAssistantPage: React.FC<Props> = ({
  onNavigateToEmergency,
  onNavigateToDoctors,
  onNavigateToMedicines,
}) => {
  const { user } = useAuth();
  const { language, languageConfig, t, speak, stopSpeech, isSpeaking, isEasyMode } = useSettings();
  const [inputMessage, setInputMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [speechTranscript, setSpeechTranscript] = useState<string>('');
  const [recognition, setRecognition] = useState<any>(null);
  const [lastSpokenResponse, setLastSpokenResponse] = useState<string>('');

  const initialGreeting = t('initialAssistantGreeting');

  const [messages, setMessages] = useState<HealthAssistantMessage[]>([
    {
      id: 'msg_welcome',
      sender: 'assistant',
      text: initialGreeting,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  // Update initial welcome message whenever language changes if only welcome is shown
  useEffect(() => {
    setMessages((prev) => {
      if (prev.length <= 1 && prev[0]?.id === 'msg_welcome') {
        return [
          {
            id: 'msg_welcome',
            sender: 'assistant',
            text: initialGreeting,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ];
      }
      return prev;
    });
  }, [language, initialGreeting]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // 4 Suggested Visual Buttons with exact dynamic localization
  const visualSuggestedButtons = [
    {
      id: 'not_well',
      emoji: '🤒',
      label: t('notFeelingWell'),
      query: t('notFeelingWellQuery'),
      color: 'bg-amber-50 text-amber-950 border-amber-200 hover:bg-amber-100',
    },
    {
      id: 'my_medicine',
      emoji: '💊',
      label: t('medicines'),
      query: t('medicineRoutineQuery'),
      color: 'bg-emerald-50 text-emerald-950 border-emerald-200 hover:bg-emerald-100',
    },
    {
      id: 'need_doctor',
      emoji: '🩺',
      label: t('findDoctor'),
      query: t('doctorAdviceQuery'),
      color: 'bg-blue-50 text-blue-950 border-blue-200 hover:bg-blue-100',
    },
    {
      id: 'emergency',
      emoji: '🚑',
      label: t('emergency'),
      query: t('emergencyQuery'),
      color: 'bg-red-50 text-red-950 border-red-200 hover:bg-red-100 font-bold',
    },
  ];

  // Speech Recognition Setup
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const inst = new SpeechRecognition();
        inst.continuous = false;
        inst.interimResults = true;
        inst.lang = languageConfig?.locale || 'en-IN';

        inst.onresult = (e: any) => {
          let text = '';
          for (let i = 0; i < e.results.length; i++) {
            text += e.results[i][0].transcript;
          }
          setSpeechTranscript(text);
        };

        inst.onend = () => {
          setIsListening(false);
        };

        inst.onerror = () => {
          setIsListening(false);
        };

        setRecognition(inst);
      }
    }
  }, [language, languageConfig]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const toggleMic = () => {
    stopSpeech();
    if (isListening) {
      if (recognition) recognition.stop();
      setIsListening(false);
      if (speechTranscript.trim()) {
        handleSendMessage(speechTranscript.trim());
      }
    } else {
      setSpeechTranscript('');
      setIsListening(true);
      try {
        if (recognition) {
          recognition.start();
        } else {
          // Simulation fallback for browser without SpeechRecognition
          setTimeout(() => {
            const fallbackText =
              language === 'te'
                ? 'నాకు ఉదయం నుండి తలనొప్పిగా ఉంది.'
                : language === 'hi'
                ? 'मुझे सुबह से सिरदर्द है।'
                : 'I have had a mild headache since morning.';
            setSpeechTranscript(fallbackText);
            setIsListening(false);
            handleSendMessage(fallbackText);
          }, 2800);
        }
      } catch {
        setIsListening(false);
      }
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isLoading) return;

    const userMsg: HealthAssistantMessage = {
      id: 'user_' + Date.now(),
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setSpeechTranscript('');
    setIsLoading(true);

    try {
      const response = await api.chatAssistant(text, language);

      const botMsg: HealthAssistantMessage = {
        id: 'bot_' + Date.now(),
        sender: 'assistant',
        text: response.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        urgencyBadge: response.urgencyLevel,
      };

      setMessages((prev) => [...prev, botMsg]);
      setLastSpokenResponse(response.reply);

      // Section 1: When the AI generates a response: TEXT RESPONSE -> FEMALE VOICE READS THE SAME RESPONSE
      speak(response.reply);
    } catch {
      const fallbackReply =
        language === 'te'
          ? 'దయచేసి పుష్కలంగా నీరు తాగి విశ్రాంతి తీసుకోండి. తీవ్రమైన లక్షణాలు ఉంటే తప్పనిసరిగా డాక్టర్ను సంప్రదించండి.'
          : language === 'hi'
          ? 'कृपया पर्याप्त पानी पिएं और आराम करें। यदि समस्या अधिक लगे तो डॉक्टर से परामर्श लें।'
          : 'Please rest comfortably and stay hydrated. If you experience severe or sudden symptoms, consult a qualified physician immediately.';

      const errAssistantMsg: HealthAssistantMessage = {
        id: 'err_' + Date.now(),
        sender: 'assistant',
        text: fallbackReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errAssistantMsg]);
      setLastSpokenResponse(fallbackReply);
      speak(fallbackReply);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    stopSpeech();
    setLastSpokenResponse('');
    setMessages([
      {
        id: 'msg_welcome_' + Date.now(),
        sender: 'assistant',
        text: initialGreeting,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  // Find latest AI response to highlight in the hero area
  const latestAssistantMessage = [...messages].reverse().find((m) => m.sender === 'assistant');

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 pb-20 animate-in fade-in duration-300">
      {/* 1. Header with Medical Guarantee */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20 shrink-0">
              <HeartPulse className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {language === 'te' ? 'మేడిమిత్ర ఆరోగ్య సహాయకుడు' : language === 'hi' ? 'मेडीमित्र स्वास्थ्य सहायक' : 'AI Health Assistant'}
              </h1>
              <p className="text-xs sm:text-sm font-semibold text-slate-500">
                {language === 'te'
                  ? 'సహజ వాయిస్ సహచరుడు • మహిళా స్వరం • తెలుగు / हिंदी / English'
                  : language === 'hi'
                  ? 'सहज वॉइस साथी • महिला आवाज़ • हिंदी / తెలుగు / English'
                  : 'Natural Voice Companion • Female Voice • English / తెలుగు / हिंदी'}
              </p>
            </div>
          </div>

          <button
            onClick={clearChat}
            className="self-start sm:self-auto flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition border border-slate-200"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{language === 'te' ? 'రీసెట్' : language === 'hi' ? 'रीसेट' : 'Reset'}</span>
          </button>
        </div>

        {/* Clinical Safety Guarantee */}
        <div className="bg-blue-50/80 border border-blue-200/80 rounded-2xl p-3.5 text-xs text-blue-950 flex items-start gap-3">
          <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>{language === 'te' ? 'భద్రతా హామీ:' : language === 'hi' ? 'सुरक्षा गारंटी:' : 'Clinical Safety Guarantee:'}</strong>{' '}
            {t('medicalDisclaimerNotice')}
          </p>
        </div>
      </div>

      {/* 2. REQUIREMENT 5: LARGE VOICE-FIRST ASSISTANT HERO AREA */}
      <div className="bg-gradient-to-b from-white via-blue-50/30 to-white rounded-3xl p-6 sm:p-10 border border-slate-200/90 shadow-sm text-center space-y-6">
        <div className="flex flex-col items-center justify-center space-y-4">
          {/* Main Large Visual Microphone Button */}
          <div className="relative">
            {isListening && (
              <>
                <div className="absolute -inset-3 rounded-full bg-red-500/20 animate-ping" />
                <div className="absolute -inset-6 rounded-full bg-red-500/10 animate-pulse" />
              </>
            )}
            <button
              id="hero-talk-mic-button"
              type="button"
              onClick={toggleMic}
              className={`relative rounded-full flex items-center justify-center transition-all duration-300 shadow-xl ${
                isEasyMode
                  ? 'w-32 h-32 sm:w-40 sm:h-40'
                  : 'w-24 h-24 sm:w-32 sm:h-32'
              } ${
                isListening
                  ? 'bg-red-600 text-white ring-8 ring-red-200 scale-105 shadow-red-500/40'
                  : 'bg-blue-600 hover:bg-blue-700 text-white hover:scale-105 active:scale-95 shadow-blue-500/30'
              }`}
              title={isListening ? t('stopListening') : t('tapToSpeak')}
            >
              {isListening ? (
                <MicOff className={`${isEasyMode ? 'w-14 h-14' : 'w-10 h-10 sm:w-12 sm:h-12'} animate-pulse`} />
              ) : (
                <Mic className={isEasyMode ? 'w-14 h-14' : 'w-10 h-10 sm:w-12 sm:h-12'} />
              )}
            </button>
          </div>

          {/* [ TALK TO MEDIMITRA ] Label Button */}
          <div>
            <button
              onClick={toggleMic}
              className={`px-6 py-3 rounded-2xl font-black text-sm sm:text-base tracking-wide transition shadow-sm ${
                isListening
                  ? 'bg-red-600 text-white ring-2 ring-red-300'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {isListening ? (
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                  {t('listening')}
                </span>
              ) : (
                t('talkToMediMitra')
              )}
            </button>
          </div>

          {/* Prompt under microphone: "Speak naturally. MediMitra will listen and respond." */}
          <p className="text-sm sm:text-base font-bold text-slate-600 max-w-md mx-auto">
            {t('speakNaturallyDesc')}
          </p>

          {/* Subtle Voice Waveform while listening */}
          {isListening && (
            <div className="flex flex-col items-center gap-2 pt-2">
              <div className="flex items-center justify-center gap-1.5 py-2 px-6 bg-red-50 border border-red-200 rounded-full">
                <div className="w-1.5 h-6 bg-red-500 rounded-full animate-bounce [animation-duration:0.6s]" />
                <div className="w-1.5 h-10 bg-red-600 rounded-full animate-bounce [animation-duration:0.8s] [animation-delay:0.1s]" />
                <div className="w-1.5 h-14 bg-red-600 rounded-full animate-bounce [animation-duration:0.7s] [animation-delay:0.25s]" />
                <div className="w-1.5 h-8 bg-red-500 rounded-full animate-bounce [animation-duration:0.9s] [animation-delay:0.15s]" />
                <div className="w-1.5 h-12 bg-red-600 rounded-full animate-bounce [animation-duration:0.75s] [animation-delay:0.3s]" />
                <div className="w-1.5 h-6 bg-red-500 rounded-full animate-bounce [animation-duration:0.65s] [animation-delay:0.2s]" />
                <span className="text-xs font-black text-red-600 ml-3">
                  {t('listening')}
                </span>
              </div>

              {speechTranscript && (
                <div className="max-w-lg p-3 bg-white rounded-2xl border border-blue-200 text-xs sm:text-sm font-semibold text-blue-900 shadow-xs">
                  <span className="text-blue-500 mr-2 uppercase text-[10px] font-bold">Heard:</span>
                  "{speechTranscript}"
                </div>
              )}
            </div>
          )}
        </div>

        {/* Processing State */}
        {isLoading && (
          <div className="max-w-md mx-auto p-4 bg-blue-50 border border-blue-200 rounded-2xl flex items-center justify-center gap-3 text-xs sm:text-sm font-bold text-blue-800 animate-pulse">
            <Sparkles className="w-5 h-5 text-blue-600 animate-spin" />
            <span>
              {language === 'te'
                ? 'మేడిమిత్ర సమాధానాన్ని సిద్ధం చేస్తోంది...'
                : language === 'hi'
                ? 'मेडीमित्र उत्तर तैयार कर रही है...'
                : 'MediMitra is organizing safe guidance...'}
            </span>
          </div>
        )}

        {/* LATEST AI RESPONSE HIGHLIGHT (After processing) */}
        {latestAssistantMessage && !isLoading && (
          <div className="max-w-2xl mx-auto bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm text-left space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <HeartPulse className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-slate-900 uppercase tracking-wider">
                    {language === 'te' ? 'మేడిమిత్ర సమాధానం' : language === 'hi' ? 'मेडीमित्र का उत्तर' : 'MediMitra Health Response'}
                  </span>
                  <span className="block text-[11px] text-slate-400">
                    {latestAssistantMessage.timestamp}
                  </span>
                </div>
              </div>

              {/* Female Voice Indicator Badge */}
              <div className="flex items-center gap-1 text-[11px] font-bold text-pink-700 bg-pink-50 border border-pink-200 px-2.5 py-1 rounded-full">
                <span>🔊 Female Voice ({language.toUpperCase()})</span>
              </div>
            </div>

            {/* Response Text */}
            <p className="text-sm sm:text-base text-slate-800 leading-relaxed font-medium whitespace-pre-wrap">
              {latestAssistantMessage.text}
            </p>

            {/* Action Bar: Listen / Replay / Speak Again */}
            <div className="flex flex-wrap items-center gap-2 pt-2">
              {/* Female voice playback button */}
              <button
                id="voice-read-aloud-btn"
                onClick={() => speak(latestAssistantMessage.text)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition shadow-xs ${
                  isSpeaking
                    ? 'bg-pink-600 text-white ring-2 ring-pink-300 animate-pulse'
                    : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200'
                }`}
              >
                <Volume2 className="w-4 h-4" />
                <span>{isSpeaking ? t('speaking') : t('listen')}</span>
              </button>

              {/* Stop Audio Button if currently speaking */}
              {isSpeaking && (
                <button
                  onClick={stopSpeech}
                  className="flex items-center gap-1.5 px-3 py-2.5 rounded-2xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200"
                >
                  <VolumeX className="w-4 h-4 text-slate-500" />
                  <span>{t('stop')}</span>
                </button>
              )}

              {/* Replay voice button */}
              <button
                onClick={() => {
                  stopSpeech();
                  speak(latestAssistantMessage.text);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-2xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition border border-slate-200"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t('replay')}</span>
              </button>

              {/* Speak Again button */}
              <button
                id="speak-again-btn"
                onClick={toggleMic}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold bg-blue-600 hover:bg-blue-700 text-white transition shadow-xs ml-auto"
              >
                <Mic className="w-4 h-4" />
                <span>{t('speakAgain')}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. REQUIREMENT 2: DYNAMIC LANGUAGE-SPECIFIC ASK SECTION & INPUT */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs space-y-4">
        <h2 className="text-xs sm:text-sm font-black text-slate-700 uppercase tracking-wider">
          {t('typeOrSpeak')}
        </h2>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3">
          {/* Microphone Button with dynamic language text: "Speak" / "మాట్లాడండి" / "बोलें" */}
          <button
            id="mic-speak-action-btn"
            type="button"
            onClick={toggleMic}
            className={`flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl font-bold text-xs sm:text-sm transition shrink-0 ${
              isListening
                ? 'bg-red-600 text-white ring-4 ring-red-200 scale-105 animate-pulse'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300'
            }`}
            title={isListening ? t('stopListening') : t('speak')}
          >
            {isListening ? <MicOff className="w-5 h-5 text-white" /> : <Mic className="w-5 h-5 text-blue-600" />}
            <span className="font-extrabold">{t('speak')}</span>
          </button>

          {/* Text Input with dynamic placeholder: "Ask me about your health..." / "మీ ఆరోగ్యం గురించి అడగండి..." / "अपने स्वास्थ्य के बारे में पूछें..." */}
          <div className="flex-1 relative">
            <input
              id="assistant-page-text-input"
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSendMessage();
              }}
              placeholder={t('askPlaceholder')}
              className="w-full text-xs sm:text-sm py-3.5 pl-4 pr-10 rounded-2xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-blue-600 text-slate-800 font-medium"
            />
          </div>

          {/* Dynamic "Ask MediMitra" Button: "Ask MediMitra" / "మేడిమిత్రను అడగండి" / "मेडीमित्र से पूछें" */}
          <button
            id="ask-medimitra-submit-btn"
            type="button"
            onClick={() => handleSendMessage()}
            disabled={!inputMessage.trim() || isLoading}
            className="flex items-center justify-center gap-2 px-6 py-3.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white font-black text-xs sm:text-sm rounded-2xl shadow-md shadow-blue-500/20 transition shrink-0 cursor-pointer"
          >
            <span>{t('askMediMitra')}</span>
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 4. 4 QUICK VISUAL HEALTH PROMPTS */}
      <div className="space-y-2">
        <h3 className="text-xs font-black text-slate-500 uppercase tracking-wider px-1">
          {t('quickPrompts')}
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {visualSuggestedButtons.map((btn) => (
            <button
              key={btn.id}
              id={`suggested-btn-${btn.id}`}
              onClick={() => handleSendMessage(btn.query)}
              className={`p-3.5 sm:p-4 rounded-2xl border text-left flex items-center gap-3 transition shadow-2xs active:scale-95 cursor-pointer ${btn.color}`}
            >
              <span className="text-2xl sm:text-3xl shrink-0">{btn.emoji}</span>
              <span className="text-xs sm:text-sm font-black leading-tight">
                {btn.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* 5. COMPLETE CONVERSATION LOG */}
      {messages.length > 1 && (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-slate-700">
              <MessageSquare className="w-4 h-4 text-blue-600" />
              <span>{t('conversationHistory')}</span>
            </div>
            <span className="text-xs text-slate-400 font-semibold">{messages.length} messages</span>
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
            {messages.map((msg) => {
              const isAst = msg.sender === 'assistant';
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${isAst ? 'justify-start' : 'justify-end'}`}
                >
                  {isAst && (
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                      <HeartPulse className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] rounded-2xl p-3.5 sm:p-4 shadow-2xs space-y-2 ${
                      isAst
                        ? 'bg-slate-50 text-slate-800 border border-slate-200'
                        : 'bg-blue-600 text-white font-medium ml-auto'
                    }`}
                  >
                    <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap">
                      {msg.text}
                    </p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-200/50">
                      <span>{msg.timestamp}</span>
                      {isAst && (
                        <button
                          onClick={() => speak(msg.text)}
                          className="flex items-center gap-1 text-blue-600 hover:text-blue-800 font-bold ml-2"
                        >
                          <Volume2 className="w-3 h-3" />
                          <span>{t('listen')}</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>
        </div>
      )}
    </div>
  );
};
