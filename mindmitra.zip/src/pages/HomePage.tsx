import React, { useState, useEffect } from 'react';
import {
  Mic,
  Heart,
  Stethoscope,
  Pill,
  MapPin,
  Siren,
  Droplets,
  Moon,
  Footprints,
  Sparkles,
  Volume2,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldAlert,
  Plus,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { useSettings } from '../context/SettingsContext.tsx';
import { NavTab } from '../components/Navbar.tsx';
import { api } from '../services/api.ts';
import { WellnessData, PrescribedMedicine } from '../types/index.ts';

interface Props {
  onNavigate: (tab: NavTab) => void;
  onOpenVoiceModal: (initialPrompt?: string) => void;
}

export const HomePage: React.FC<Props> = ({ onNavigate, onOpenVoiceModal }) => {
  const { user } = useAuth();
  const { t, language, setLanguage, speak, isEasyMode, triggerDemoReminder } = useSettings();
  const [wellness, setWellness] = useState<WellnessData | null>(null);
  const [medicines, setMedicines] = useState<PrescribedMedicine[]>([]);
  const [waterLoggedToday, setWaterLoggedToday] = useState<number>(1250);
  const [justLoggedWater, setJustLoggedWater] = useState<boolean>(false);

  useEffect(() => {
    // Fetch today's wellness and medicine list
    const fetchData = async () => {
      try {
        const [wRes, mRes] = await Promise.all([
          api.getTodayWellness().catch(() => null),
          api.getMedicines().catch(() => null),
        ]);
        if (wRes && wRes.wellness) {
          setWellness(wRes.wellness);
          if (wRes.wellness.waterIntakeMl) {
            setWaterLoggedToday(wRes.wellness.waterIntakeMl);
          }
        }
        if (mRes && mRes.medicines) {
          setMedicines(mRes.medicines);
        }
      } catch (err) {
        console.warn('Home fetch error:', err);
      }
    };
    fetchData();
  }, []);

  const handleQuickAddWater = async () => {
    const newAmount = waterLoggedToday + 250;
    setWaterLoggedToday(newAmount);
    setJustLoggedWater(true);
    setTimeout(() => setJustLoggedWater(false), 1500);

    const confirmation =
      language === 'te'
        ? '250 మిల్లీలీటర్ల నీరు తాగినట్లు నమోదు చేయబడింది. చాలా మంచిది!'
        : language === 'hi'
        ? '250 मिलीलीटर पानी दर्ज किया गया। बहुत बढ़िया!'
        : '250 ml of water logged. Good job staying hydrated!';
    speak(confirmation);

    try {
      await api.logWellness({ waterIntakeMl: newAmount });
    } catch {}
  };

  const handleVoiceTap = () => {
    const intro =
      language === 'te'
        ? 'మెడిమిత్రతో మాట్లాడండి. మీ సమస్యను చెప్పండి.'
        : language === 'hi'
        ? 'मेडि मित्र से बात करें। अपनी परेशानी बताएं।'
        : 'Talk to MediMitra. Speak naturally about how you feel.';
    speak(intro);
    onOpenVoiceModal();
  };

  // 5 Major Action Buttons as specified in User Request Section 6
  const primaryActions = [
    {
      id: 'health' as NavTab,
      label: t('myHealth'),
      subLabel: t('myHealthSub'),
      icon: Heart,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 hover:border-emerald-300',
      iconBg: 'bg-emerald-600 text-white',
      badgeColor: 'bg-emerald-100 text-emerald-800',
      speech: language === 'te' ? 'నా ఆరోగ్యం మరియు వెల్నెస్' : language === 'hi' ? 'मेरा स्वास्थ्य और फिटनेस' : 'My Health tracking',
    },
    {
      id: 'doctors' as NavTab,
      label: t('findDoctor'),
      subLabel: t('findDoctorSub'),
      icon: Stethoscope,
      color: 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100 hover:border-blue-300',
      iconBg: 'bg-blue-600 text-white',
      badgeColor: 'bg-blue-100 text-blue-800',
      speech: language === 'te' ? 'డాక్టర్ను కనుగొనండి' : language === 'hi' ? 'नजदीकी डॉक्टर खोजें' : 'Find nearby doctors',
    },
    {
      id: 'medicines' as NavTab,
      label: t('medicines'),
      subLabel: t('medicinesSub'),
      icon: Pill,
      color: 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:bg-indigo-100 hover:border-indigo-300',
      iconBg: 'bg-indigo-600 text-white',
      badgeColor: 'bg-indigo-100 text-indigo-800',
      speech: language === 'te' ? 'మందులు మరియు రిమైండర్లు' : language === 'hi' ? 'दवाइयां और रिमाइंडर' : 'Doctor prescribed medicines',
    },
    {
      id: 'doctors' as NavTab,
      label: t('nearbyHospital'),
      subLabel: t('nearbyHospitalSub'),
      icon: MapPin,
      color: 'bg-teal-50 text-teal-800 border-teal-200 hover:bg-teal-100 hover:border-teal-300',
      iconBg: 'bg-teal-600 text-white',
      badgeColor: 'bg-teal-100 text-teal-800',
      speech: language === 'te' ? 'దగ్గరి ఆసుపత్రి మరియు చికిత్స కేంద్రం' : language === 'hi' ? 'नजदीकी अस्पताल' : 'Nearby hospitals and emergency facilities',
    },
    {
      id: 'emergency' as NavTab,
      label: t('emergency'),
      subLabel: t('emergencySub'),
      icon: Siren,
      color: 'bg-red-50 text-red-800 border-red-300 hover:bg-red-100 hover:border-red-400 ring-2 ring-red-200',
      iconBg: 'bg-red-600 text-white',
      badgeColor: 'bg-red-100 text-red-900',
      isHeroEmergency: true,
      speech: language === 'te' ? 'అత్యవసర సహాయం మరియు అంబులెన్స్' : language === 'hi' ? 'आपातकालीन सहायता और एम्बुलेंस' : 'Emergency help and smart ambulance',
    },
  ];

  // Visual Quick Symptoms
  const visualSymptoms = [
    { emoji: '🤕', label: t('headache'), query: 'I have headache since morning' },
    { emoji: '🌡️', label: t('fever'), query: 'I have fever and shivering' },
    { emoji: '🤧', label: t('cough'), query: 'I have continuous cough and sore throat' },
    { emoji: '🤢', label: t('stomachProblem'), query: 'I have stomach ache and nausea' },
    { emoji: '🫁', label: t('breathingProblem'), query: 'I have shortness of breath' },
    { emoji: '😣', label: t('bodyPain'), query: 'I feel body ache and fatigue' },
  ];

  return (
    <div className="space-y-6 sm:space-y-8 pb-16 animate-in fade-in duration-300">
      {/* 1. Welcoming Consumer Health Hero Header */}
      <section className="text-center space-y-3 pt-2 sm:pt-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-800 text-xs font-bold tracking-wide">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>{t('tagline')}</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
          Medi<span className="text-blue-600">Mitra</span>
        </h1>

        <p className="text-base sm:text-xl font-bold text-slate-600 max-w-xl mx-auto">
          {t('howCanIHelp')}
        </p>
      </section>

      {/* Accessible Language Switcher Bar */}
      <section className="max-w-xl mx-auto px-2">
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-black text-slate-700 pl-1">
            <span className="text-base">🌐</span>
            <span>
              {language === 'te'
                ? 'భాష / Language'
                : language === 'hi'
                ? 'भाषा / Language'
                : 'Language'}
            </span>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              id="home-lang-en-btn"
              onClick={() => setLanguage('en')}
              className={`px-3 py-1.5 text-xs font-black rounded-xl transition ${
                language === 'en'
                  ? 'bg-blue-600 text-white shadow-sm ring-2 ring-blue-300'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              English
            </button>
            <button
              id="home-lang-te-btn"
              onClick={() => setLanguage('te')}
              className={`px-3 py-1.5 text-xs font-black rounded-xl transition ${
                language === 'te'
                  ? 'bg-blue-600 text-white shadow-sm ring-2 ring-blue-300'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              తెలుగు (Telugu)
            </button>
            <button
              id="home-lang-hi-btn"
              onClick={() => setLanguage('hi')}
              className={`px-3 py-1.5 text-xs font-black rounded-xl transition ${
                language === 'hi'
                  ? 'bg-blue-600 text-white shadow-sm ring-2 ring-blue-300'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              हिन्दी (Hindi)
            </button>
          </div>
        </div>
      </section>

      {/* 2. THE MAIN CENTRAL HERO BUTTON: 🎤 TALK TO MEDIMITRA (TAP TO SPEAK) */}
      <section className="max-w-xl mx-auto px-2">
        <div className="relative group">
          {/* Animated Glow Halo */}
          <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 via-indigo-500 to-sky-500 rounded-3xl blur-md opacity-40 group-hover:opacity-75 transition duration-500 animate-pulse" />

          <button
            id="home-talk-hero-btn"
            onClick={handleVoiceTap}
            className={`relative w-full ${
              isEasyMode ? 'py-8 sm:py-10' : 'py-6 sm:py-8'
            } px-6 bg-gradient-to-br from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 active:scale-[0.99] text-white rounded-3xl shadow-xl shadow-blue-500/30 flex flex-col items-center justify-center gap-3 transition-all duration-200 border-2 border-white/20`}
          >
            {/* Big Mic with Pulse Rings */}
            <div className="relative">
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-white text-blue-600 flex items-center justify-center shadow-lg shadow-black/10 group-hover:scale-105 transition">
                <Mic className="w-10 h-10 sm:w-12 sm:h-12" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500" />
              </span>
            </div>

            <div className="text-center space-y-1">
              <span className="text-xl sm:text-2xl font-black tracking-wide block uppercase">
                {t('talkToMediMitra')}
              </span>
              <span className="text-xs sm:text-sm font-semibold text-blue-100 flex items-center justify-center gap-1.5">
                <span>{t('tapToSpeak')}</span>
                <span>•</span>
                <span className="underline">{t('voiceInputDesc').split('.')[0]}</span>
              </span>
            </div>
          </button>
        </div>
      </section>

      {/* 3. ONLY FIVE MAJOR ACTIONS (Large buttons for elderly / low literacy) */}
      <section className="max-w-4xl mx-auto space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm sm:text-base font-extrabold text-slate-800 uppercase tracking-wider">
            Key Health Actions
          </h2>
          <span className="text-xs text-slate-400 font-semibold">
            {isEasyMode ? '♿ Large Display Active' : 'Tap any card below'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
          {primaryActions.map((action, idx) => {
            const Icon = action.icon;
            return (
              <button
                key={idx}
                id={`action-${action.id}-${idx}`}
                onClick={() => {
                  speak(action.speech);
                  onNavigate(action.id);
                }}
                className={`w-full p-5 sm:p-6 rounded-3xl border-2 text-left transition-all duration-200 flex items-center gap-4 shadow-xs hover:shadow-md active:scale-[0.98] ${
                  action.color
                } ${action.isHeroEmergency ? 'sm:col-span-2 lg:col-span-1' : ''}`}
              >
                <div
                  className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center shrink-0 shadow-md ${
                    action.iconBg
                  } ${action.isHeroEmergency ? 'animate-pulse ring-4 ring-red-200' : ''}`}
                >
                  <Icon className="w-7 h-7 sm:w-8 sm:h-8" />
                </div>

                <div className="space-y-1 min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-base sm:text-lg font-black tracking-tight block truncate">
                      {action.label}
                    </span>
                    <ArrowRight className="w-4 h-4 opacity-40 shrink-0" />
                  </div>
                  <p className="text-xs text-slate-600 font-medium line-clamp-2 leading-relaxed">
                    {action.subLabel}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 4. VISUAL QUICK SYMPTOM GUIDANCE (No typing medical jargon!) */}
      <section className="max-w-4xl mx-auto bg-white rounded-3xl p-5 sm:p-7 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <span>🩺</span>
              <span>{t('symptomCheckerTitle')}</span>
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              {t('symptomCheckerSub')}
            </p>
          </div>

          <button
            onClick={() => onNavigate('symptoms')}
            className="text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Full Symptom Triage</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {visualSymptoms.map((sym, index) => (
            <button
              key={index}
              id={`quick-sym-${index}`}
              onClick={() => {
                speak(sym.label);
                onOpenVoiceModal(sym.query);
              }}
              className="p-3.5 sm:p-4 rounded-2xl bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 transition text-center flex flex-col items-center justify-center gap-2 active:scale-95 group shadow-2xs"
            >
              <span className="text-3xl sm:text-4xl group-hover:scale-110 transition duration-200">
                {sym.emoji}
              </span>
              <span className="text-xs font-bold text-slate-800 group-hover:text-blue-700 leading-tight">
                {sym.label}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* 5. TODAY'S QUICK WELLNESS & MEDICINE SCHEDULE */}
      <section className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Quick Water Tracker with One-Tap +250ml */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-sky-500 text-white flex items-center justify-center shadow-xs">
                <Droplets className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm sm:text-base">{t('water')}</h4>
                <p className="text-xs text-slate-500">
                  {waterLoggedToday} / 2000 ml {t('waterGoal')}
                </p>
              </div>
            </div>

            <button
              id="home-add-water-btn"
              onClick={handleQuickAddWater}
              className={`py-2 px-3.5 sm:px-4 bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 ${
                justLoggedWater ? 'scale-105 ring-4 ring-sky-200' : ''
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>{t('addWater250')}</span>
            </button>
          </div>

          {/* Water Bar Fill */}
          <div className="space-y-1.5">
            <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
              <div
                className="bg-sky-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, Math.round((waterLoggedToday / 2000) * 100))}%` }}
              />
            </div>
            <div className="flex justify-between text-[11px] font-semibold text-slate-500">
              <span>{Math.round((waterLoggedToday / 2000) * 100)}% Hydration Goal</span>
              <button
                onClick={() => onNavigate('health')}
                className="text-sky-700 hover:underline font-bold"
              >
                Health Dashboard →
              </button>
            </div>
          </div>
        </div>

        {/* Doctor Prescribed Medicine Snapshot */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                <Pill className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm sm:text-base">
                  {t('medicineReminders')}
                </h4>
                <p className="text-xs text-slate-500">
                  Doctor prescribed • Scheduled doses
                </p>
              </div>
            </div>

            <button
              id="test-reminder-pop-btn"
              onClick={triggerDemoReminder}
              className="py-1.5 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 font-bold text-[11px] rounded-xl transition"
              title="Test Pill Reminder Alert"
            >
              Test Alert
            </button>
          </div>

          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
            <div className="space-y-0.5">
              <span className="font-bold text-slate-800 block">
                {medicines.length > 0 ? medicines[0].medicineName : 'Amlodipine 5mg'}
              </span>
              <span className="text-slate-500 text-[11px]">
                {medicines.length > 0
                  ? `${medicines[0].dosage} • ${medicines[0].instruction}`
                  : '1 Tablet • After Breakfast with water'}
              </span>
            </div>

            <button
              onClick={() => onNavigate('medicines')}
              className="text-indigo-600 hover:text-indigo-800 font-bold hover:underline shrink-0"
            >
              View Schedule →
            </button>
          </div>
        </div>
      </section>

      {/* 6. Medical Boundary Reassurance Strip */}
      <section className="max-w-4xl mx-auto">
        <div className="bg-slate-100/80 rounded-2xl p-4 text-xs text-slate-600 border border-slate-200 flex items-start gap-3">
          <ShieldAlert className="w-4 h-4 text-slate-500 mt-0.5 shrink-0" />
          <p className="leading-relaxed">
            <strong>Safety Protocol:</strong> MediMitra provides general health information, wellness tracking, and simulated emergency coordination. It does not independently diagnose diseases or prescribe medications. In life-threatening emergencies, dial your national emergency number (112 / 108 / 911).
          </p>
        </div>
      </section>
    </div>
  );
};
