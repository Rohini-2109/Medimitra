import React, { useState, useEffect } from 'react';
import {
  Smile,
  Frown,
  Meh,
  Heart,
  Calendar,
  Sparkles,
  Phone,
  ShieldAlert,
  Trash2,
  CheckCircle2,
  Compass,
  Flame,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { MoodEntry } from '../types/index.ts';
import { BreathingExercise } from '../components/BreathingExercise.tsx';

export const MentalWellbeingPage: React.FC = () => {
  const [logs, setLogs] = useState<MoodEntry[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedMood, setSelectedMood] = useState<
    'great' | 'good' | 'neutral' | 'anxious' | 'sad' | 'stressed'
  >('good');
  const [stressLevel, setStressLevel] = useState<number>(3);
  const [selectedEmotions, setSelectedEmotions] = useState<string[]>([]);
  const [journalNote, setJournalNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const availableEmotions = [
    'Calm',
    'Grateful',
    'Energetic',
    'Productive',
    'Restless',
    'Tense',
    'Exhausted',
    'Overwhelmed',
    'Hopeful',
    'Lonely',
    'Peaceful',
  ];

  const loadHistory = async () => {
    try {
      const res = await api.getMoodHistory();
      setLogs(res.logs || []);
    } catch (err) {
      console.error('Failed to load mood history:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);

  const handleToggleEmotion = (emotion: string) => {
    setSelectedEmotions((prev) =>
      prev.includes(emotion) ? prev.filter((e) => e !== emotion) : [...prev, emotion]
    );
  };

  const handleSaveCheckIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSuccessMsg(null);

    const scoreMap = {
      great: 5,
      good: 4,
      neutral: 3,
      anxious: 2,
      sad: 2,
      stressed: 1,
    };

    try {
      await api.logMood({
        mood: selectedMood,
        score: scoreMap[selectedMood],
        stressLevel,
        emotions: selectedEmotions,
        journalNote,
        date: new Date().toISOString().split('T')[0],
      });
      setSuccessMsg('Mental well-being check-in saved!');
      setJournalNote('');
      loadHistory();
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err) {
      console.error('Failed to save mood log:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteLog = async (id: string) => {
    try {
      await api.deleteMoodLog(id);
      setLogs((prev) => prev.filter((l) => l.id !== id));
    } catch (err) {
      console.error('Failed to delete mood entry:', err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-2">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
            <Smile className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              Mental Well-being & Mindfulness Sanctuary
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Daily mood tracking, somatic stress de-escalation, and professional support access.
            </p>
          </div>
        </div>
      </div>

      {/* Immediate Crisis Support Helpline Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-950 text-white rounded-3xl p-5 sm:p-6 shadow-sm border border-blue-700/50 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-blue-300 shrink-0" />
            <span className="font-bold text-sm text-blue-100">
              Need to Talk to Someone? Confidential Professional Support
            </span>
          </div>
          <span className="text-[11px] bg-blue-900 border border-blue-600 px-2.5 py-0.5 rounded-full font-bold">
            24/7 Free & Available
          </span>
        </div>

        <p className="text-xs text-blue-200 leading-relaxed max-w-2xl">
          If you or someone you know is experiencing overwhelming emotional distress, anxiety, or crisis, compassionate professional listeners are ready right now.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
          <a
            href="tel:14416"
            className="flex items-center justify-between bg-white/10 hover:bg-white/20 border border-blue-500/30 p-2.5 rounded-xl text-xs transition font-semibold"
          >
            <span>India: Tele-MANAS</span>
            <span className="font-extrabold text-blue-300">14416 / 1800-891-4416</span>
          </a>

          <a
            href="tel:988"
            className="flex items-center justify-between bg-white/10 hover:bg-white/20 border border-blue-500/30 p-2.5 rounded-xl text-xs transition font-semibold"
          >
            <span>US & Canada Lifeline</span>
            <span className="font-extrabold text-blue-300">988</span>
          </a>

          <a
            href="tel:111"
            className="flex items-center justify-between bg-white/10 hover:bg-white/20 border border-blue-500/30 p-2.5 rounded-xl text-xs transition font-semibold"
          >
            <span>UK Mental Health</span>
            <span className="font-extrabold text-blue-300">111</span>
          </a>
        </div>
      </div>

      {/* Two Column Section: Check-In Form & Guided Breathing */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Mood Check-in Form */}
        <form
          onSubmit={handleSaveCheckIn}
          className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-4"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>Log Today's Mood Check-in</span>
            </h3>
            <span className="text-xs text-slate-400">
              {new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
            </span>
          </div>

          {/* Mood Emojis */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 block">Overall State:</label>
            <div className="grid grid-cols-6 gap-1.5">
              {[
                { val: 'great', label: 'Great', emoji: '😄' },
                { val: 'good', label: 'Good', emoji: '🙂' },
                { val: 'neutral', label: 'Neutral', emoji: '😐' },
                { val: 'anxious', label: 'Anxious', emoji: '😰' },
                { val: 'sad', label: 'Low', emoji: '😔' },
                { val: 'stressed', label: 'Stressed', emoji: '😫' },
              ].map((item) => (
                <button
                  type="button"
                  key={item.val}
                  onClick={() => setSelectedMood(item.val as any)}
                  className={`p-2 rounded-xl flex flex-col items-center border transition ${
                    selectedMood === item.val
                      ? 'border-blue-600 bg-blue-50/80 text-blue-900 shadow-2xs scale-105'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className="text-xl">{item.emoji}</span>
                  <span className="text-[10px] font-semibold mt-1">{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Stress Level Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <label className="font-bold text-slate-700">Perceived Stress Level:</label>
              <span className="font-extrabold text-blue-800">{stressLevel} / 10</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={stressLevel}
              onChange={(e) => setStressLevel(Number(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-medium">
              <span>1 (Very Calm)</span>
              <span>5 (Moderate)</span>
              <span>10 (Severe Stress)</span>
            </div>
          </div>

          {/* Emotion Tags */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 block">Emotion Tags:</label>
            <div className="flex flex-wrap gap-1.5">
              {availableEmotions.map((em) => {
                const active = selectedEmotions.includes(em);
                return (
                  <button
                    type="button"
                    key={em}
                    onClick={() => handleToggleEmotion(em)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition ${
                      active
                        ? 'border-blue-600 bg-blue-100 text-blue-900'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {em}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Journal Note */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 block">
              Reflective Note / Trigger Observations (Optional):
            </label>
            <textarea
              value={journalNote}
              onChange={(e) => setJournalNote(e.target.value)}
              placeholder="What factors influenced your energy today? (e.g. good morning run, work meeting deadline, restful night)"
              rows={2}
              className="w-full text-xs p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-blue-600 resize-none text-slate-800"
            />
          </div>

          {successMsg && (
            <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl p-2.5 text-xs font-semibold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <button
            id="save-mood-checkin-btn"
            type="submit"
            disabled={isSubmitting}
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition shadow-xs"
          >
            {isSubmitting ? 'Recording...' : 'Save Daily Check-in'}
          </button>
        </form>

        {/* Right: Guided Box Breathing Pacer */}
        <BreathingExercise />
      </div>

      {/* 5-4-3-2-1 Somatic Grounding Technique */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 text-blue-800">
          <Compass className="w-5 h-5 text-blue-600" />
          <h3 className="text-base font-bold text-slate-900">
            5-4-3-2-1 Sensory Grounding Technique
          </h3>
        </div>
        <p className="text-xs text-slate-600 max-w-2xl">
          When anxiety or panic sets in, anchor yourself back to the present moment by engaging your physical senses one by one:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 pt-1">
          <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl text-center space-y-1">
            <span className="text-xl font-black text-blue-600">5</span>
            <span className="text-xs font-bold text-slate-800 block">THINGS YOU SEE</span>
            <p className="text-[11px] text-slate-500">Notice colors, shadows, or textures in your room</p>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl text-center space-y-1">
            <span className="text-xl font-black text-sky-600">4</span>
            <span className="text-xs font-bold text-slate-800 block">THINGS YOU FEEL</span>
            <p className="text-[11px] text-slate-500">Feet on the floor, clothing, chair surface</p>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl text-center space-y-1">
            <span className="text-xl font-black text-indigo-600">3</span>
            <span className="text-xs font-bold text-slate-800 block">THINGS YOU HEAR</span>
            <p className="text-[11px] text-slate-500">Distant traffic, hum of a fan, birds outside</p>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl text-center space-y-1">
            <span className="text-xl font-black text-amber-600">2</span>
            <span className="text-xs font-bold text-slate-800 block">THINGS YOU SMELL</span>
            <p className="text-[11px] text-slate-500">Clean air, tea, coffee, fresh breeze</p>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl text-center space-y-1">
            <span className="text-xl font-black text-rose-600">1</span>
            <span className="text-xs font-bold text-slate-800 block">THING YOU TASTE</span>
            <p className="text-[11px] text-slate-500">Sip of cool water or mint</p>
          </div>
        </div>
      </div>

      {/* Mood History & Trend Log */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-600" />
            <span>Mood & Stress Log History</span>
          </h3>
          <span className="text-xs text-slate-500 font-semibold">{logs.length} entries recorded</span>
        </div>

        {logs.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-xs">
            No mood entries yet. Record your first check-in above.
          </div>
        ) : (
          <div className="space-y-3">
            {logs.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-2xl bg-slate-50/70 border border-slate-200/80 flex items-start justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-900 capitalize">
                      {item.mood}
                    </span>
                    <span className="text-xs bg-white border border-slate-200 text-slate-600 px-2 py-0.5 rounded-full font-semibold">
                      Stress: {item.stressLevel}/10
                    </span>
                    <span className="text-xs text-slate-400 font-medium">
                      {item.date}
                    </span>
                  </div>

                  {item.emotions && item.emotions.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-0.5">
                      {item.emotions.map((e, idx) => (
                        <span
                          key={idx}
                          className="text-[10px] bg-blue-50 text-blue-800 border border-blue-200 px-2 py-0.5 rounded-full font-medium"
                        >
                          {e}
                        </span>
                      ))}
                    </div>
                  )}

                  {item.journalNote && (
                    <p className="text-xs text-slate-600 italic pt-1">
                      "{item.journalNote}"
                    </p>
                  )}
                </div>

                <button
                  onClick={() => handleDeleteLog(item.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                  title="Delete Entry"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
