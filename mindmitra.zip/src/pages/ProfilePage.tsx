import React, { useState } from 'react';
import {
  User,
  ShieldCheck,
  MapPin,
  Phone,
  Heart,
  Mail,
  Lock,
  LogOut,
  Save,
  CheckCircle2,
  AlertCircle,
  Plus,
  X,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';

export const ProfilePage: React.FC = () => {
  const {
    user,
    isAuthenticated,
    login,
    register,
    demoLogin,
    logout,
    updateProfile,
    locationPermission,
    userCoords,
    requestLocationPermission,
    isLoading,
    error,
    clearError,
  } = useAuth();

  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [age, setAge] = useState<number | ''>('');
  const [gender, setGender] = useState<string>('');
  const [bloodGroup, setBloodGroup] = useState<string>('');
  const [emergencyName, setEmergencyName] = useState<string>('');
  const [emergencyPhone, setEmergencyPhone] = useState<string>('');
  const [emergencyRel, setEmergencyRel] = useState<string>('');

  // Edit profile in-place
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editName, setEditName] = useState<string>(user?.name || '');
  const [editAge, setEditAge] = useState<number | ''>(user?.age || '');
  const [editGender, setEditGender] = useState<string>(user?.gender || '');
  const [editBlood, setEditBlood] = useState<string>(user?.bloodGroup || '');
  const [editAddress, setEditAddress] = useState<string>(user?.address || '');
  const [editEmergencyName, setEditEmergencyName] = useState<string>(user?.emergencyContact?.name || '');
  const [editEmergencyPhone, setEditEmergencyPhone] = useState<string>(user?.emergencyContact?.phone || '');
  const [editEmergencyRel, setEditEmergencyRel] = useState<string>(user?.emergencyContact?.relationship || '');
  const [editAllergies, setEditAllergies] = useState<string[]>(user?.allergies || []);
  const [newAllergy, setNewAllergy] = useState<string>('');
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    try {
      if (authMode === 'login') {
        await login({ email, password });
      } else {
        await register({
          email,
          password,
          name,
          age: age ? Number(age) : 0,
          gender: gender || '',
          bloodGroup: bloodGroup || '',
          emergencyContact: emergencyName || emergencyPhone ? {
            name: emergencyName,
            phone: emergencyPhone,
            relationship: emergencyRel,
          } : undefined,
        });
      }
    } catch (err) {
      console.error('Auth error:', err);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateProfile({
        name: editName,
        age: editAge ? Number(editAge) : 0,
        gender: editGender,
        bloodGroup: editBlood,
        address: editAddress,
        allergies: editAllergies,
        emergencyContact: (editEmergencyName || editEmergencyPhone) ? {
          name: editEmergencyName,
          phone: editEmergencyPhone,
          relationship: editEmergencyRel || 'Contact',
        } : undefined,
      });
      setIsEditing(false);
      setSaveMessage('Profile information successfully saved!');
      setTimeout(() => setSaveMessage(null), 3500);
    } catch (err) {
      console.error('Failed to update profile:', err);
    }
  };

  const handleAddAllergy = () => {
    if (newAllergy.trim() && !editAllergies.includes(newAllergy.trim())) {
      setEditAllergies([...editAllergies, newAllergy.trim()]);
      setNewAllergy('');
    }
  };

  const handleRemoveAllergy = (allergy: string) => {
    setEditAllergies(editAllergies.filter((a) => a !== allergy));
  };

  if (!user) {
    return (
      <div className="max-w-md mx-auto py-8 px-4 animate-in fade-in duration-300">
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xl space-y-6">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-xs">
              <User className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-extrabold text-slate-900">
              {authMode === 'login' ? 'Sign In to MediMitra' : 'Create Personal Health Profile'}
            </h2>
            <p className="text-xs text-slate-500">
              Your confidential health, wellness & emergency data hub
            </p>
          </div>

          {/* Quick Demo One-Click Login */}
          <button
            id="quick-demo-login-btn"
            onClick={() => demoLogin()}
            className="w-full py-2.5 px-4 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-blue-600" />
            <span>Instant Demo Account Login</span>
          </button>

          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-200" />
            <span className="shrink mx-3 text-slate-400 text-[11px] uppercase font-bold">
              Or Use Email
            </span>
            <div className="flex-grow border-t border-slate-200" />
          </div>

          <form onSubmit={handleAuthSubmit} className="space-y-4 text-xs sm:text-sm">
            {authMode === 'register' && (
              <>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Full Name:</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Rohini"
                    className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900 text-xs"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Age:</label>
                    <input
                      type="number"
                      value={age}
                      onChange={(e) => setAge(Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900 text-xs"
                      required
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Blood Group:</label>
                    <select
                      value={bloodGroup}
                      onChange={(e) => setBloodGroup(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900 text-xs font-semibold"
                    >
                      {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((b) => (
                        <option key={b} value={b}>
                          {b}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <span className="font-bold text-[11px] text-slate-700 block uppercase tracking-wider">
                    Emergency Contact:
                  </span>
                  <input
                    type="text"
                    value={emergencyName}
                    onChange={(e) => setEmergencyName(e.target.value)}
                    placeholder="Contact Name (e.g. Rohit Sharma)"
                    className="w-full p-2 rounded-lg border border-slate-200 bg-white text-xs text-slate-900"
                    required
                  />
                  <input
                    type="tel"
                    value={emergencyPhone}
                    onChange={(e) => setEmergencyPhone(e.target.value)}
                    placeholder="Emergency Phone (+91 98765 43210)"
                    className="w-full p-2 rounded-lg border border-slate-200 bg-white text-xs text-slate-900"
                    required
                  />
                </div>
              </>
            )}

            <div>
              <label className="font-bold text-slate-700 block mb-1">Email Address:</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900 text-xs"
                  required
                />
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Password:</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900 text-xs"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="bg-rose-50 text-rose-800 border border-rose-200 p-2.5 rounded-xl text-xs flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              id="auth-submit-btn"
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm rounded-xl transition shadow-xs"
            >
              {isLoading
                ? 'Processing...'
                : authMode === 'login'
                ? 'Sign In to Account'
                : 'Create Account'}
            </button>
          </form>

          <div className="text-center pt-2 border-t border-slate-100">
            <button
              onClick={() => {
                setAuthMode(authMode === 'login' ? 'register' : 'login');
                clearError();
              }}
              className="text-xs text-blue-600 font-bold hover:underline"
            >
              {authMode === 'login'
                ? "Don't have an account? Sign up"
                : 'Already have an account? Sign in'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header Profile Badge */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-3xl bg-blue-600 text-white font-extrabold text-2xl flex items-center justify-center shadow-md">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">{user.name}</h1>
                <span className="text-[10px] uppercase font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
                  Verified User
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500">{user.email}</p>
              <p className="text-xs text-slate-600 mt-1">
                {user.age ? `${user.age} Years Old • ` : ''}
                {user.gender ? `Gender: ${user.gender} • ` : ''}
                {user.bloodGroup ? (
                  <span>Blood Group: <strong>{user.bloodGroup}</strong></span>
                ) : (
                  <span className="italic text-slate-400">Blood group not set</span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setIsEditing(!isEditing);
                setEditName(user.name || '');
                setEditAge(user.age || '');
                setEditGender(user.gender || '');
                setEditBlood(user.bloodGroup || '');
                setEditAddress(user.address || '');
                setEditEmergencyName(user.emergencyContact?.name || '');
                setEditEmergencyPhone(user.emergencyContact?.phone || '');
                setEditEmergencyRel(user.emergencyContact?.relationship || '');
                setEditAllergies(user.allergies || []);
              }}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition"
            >
              {isEditing ? 'Cancel Edit' : 'Edit Profile'}
            </button>

            <button
              id="logout-btn"
              onClick={logout}
              className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        {saveMessage && (
          <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 p-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{saveMessage}</span>
          </div>
        )}
      </div>

      {/* Edit Form OR Information View */}
      {isEditing ? (
        <form
          onSubmit={handleSaveProfile}
          className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4 text-xs sm:text-sm"
        >
          <h3 className="font-bold text-sm text-slate-900 border-b pb-2">
            Update Personal & Health Details
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Full Name:</label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="Your Name"
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900"
                required
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Age (Years):</label>
              <input
                type="number"
                value={editAge}
                onChange={(e) => setEditAge(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="e.g. 25"
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Gender:</label>
              <select
                value={editGender}
                onChange={(e) => setEditGender(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900 font-semibold"
              >
                <option value="">Select Gender</option>
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Other">Other</option>
                <option value="Prefer not to say">Prefer not to say</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Blood Group:</label>
              <select
                value={editBlood}
                onChange={(e) => setEditBlood(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900 font-semibold"
              >
                <option value="">Select Blood Group</option>
                {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="font-bold text-slate-700 block mb-1">Address / Residence:</label>
              <input
                type="text"
                value={editAddress}
                onChange={(e) => setEditAddress(e.target.value)}
                placeholder="City, State, Country"
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900"
              />
            </div>
          </div>

          {/* Emergency Contact Edit Section */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-blue-600" />
              <span>Emergency Contact Details (Optional)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Contact Name</label>
                <input
                  type="text"
                  value={editEmergencyName}
                  onChange={(e) => setEditEmergencyName(e.target.value)}
                  placeholder="e.g. Family member / Friend"
                  className="w-full p-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-900"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={editEmergencyPhone}
                  onChange={(e) => setEditEmergencyPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full p-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-900"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Relationship</label>
                <input
                  type="text"
                  value={editEmergencyRel}
                  onChange={(e) => setEditEmergencyRel(e.target.value)}
                  placeholder="e.g. Sibling / Parent / Spouse"
                  className="w-full p-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-900"
                />
              </div>
            </div>
          </div>

          {/* Allergies editor */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">
              Known Medical & Drug Allergies:
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {editAllergies.length > 0 ? (
                editAllergies.map((a) => (
                  <span
                    key={a}
                    className="px-2.5 py-1 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold flex items-center gap-1"
                  >
                    {a}
                    <button
                      type="button"
                      onClick={() => handleRemoveAllergy(a)}
                      className="hover:text-rose-950"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))
              ) : (
                <span className="text-xs text-slate-400 italic">No allergies added yet.</span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newAllergy}
                onChange={(e) => setNewAllergy(e.target.value)}
                placeholder="Add allergy (e.g. Aspirin, Peanuts, Sulfa)"
                className="p-2 text-xs rounded-xl border border-slate-200 bg-slate-50 w-64"
              />
              <button
                type="button"
                onClick={handleAddAllergy}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-bold"
              >
                Add
              </button>
            </div>
          </div>

          <div className="pt-2 border-t flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Medical Information */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Heart className="w-4 h-4 text-rose-600" />
              <span>Clinical & Emergency Profile</span>
            </h3>

            <div className="space-y-2.5 text-xs text-slate-700">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Blood Group:</span>
                <span className="font-extrabold text-slate-900">
                  {user.bloodGroup || <span className="text-slate-400 font-normal italic">Not specified</span>}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Age / Gender:</span>
                <span className="font-semibold text-slate-900">
                  {user.age ? `${user.age} yrs` : 'Age not set'} {user.gender ? `• ${user.gender}` : ''}
                </span>
              </div>
              <div className="py-1.5 border-b border-slate-100 space-y-1">
                <span className="text-slate-500 block">Recorded Allergies:</span>
                <div className="flex flex-wrap gap-1">
                  {user.allergies && user.allergies.length > 0 ? (
                    user.allergies.map((a, i) => (
                      <span
                        key={i}
                        className="bg-rose-50 text-rose-800 border border-rose-200 px-2 py-0.5 rounded-md font-semibold text-[11px]"
                      >
                        {a}
                      </span>
                    ))
                  ) : (
                    <span className="text-slate-400 italic">None reported</span>
                  )}
                </div>
              </div>
              <div className="py-1.5 space-y-1">
                <span className="text-slate-500 block">Chronic Health Factors:</span>
                <div className="flex flex-wrap gap-1">
                  {user.chronicConditions && user.chronicConditions.length > 0 ? (
                    user.chronicConditions.map((c, i) => (
                      <span
                        key={i}
                        className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded-md font-semibold text-[11px]"
                      >
                        {c}
                      </span>
                    ))
                  ) : (
                    <span className="text-slate-400 italic">None reported</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Emergency Contact & Location Permission */}
          <div className="space-y-6">
            {/* Emergency Contact */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-3">
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Phone className="w-4 h-4 text-blue-600" />
                <span>Primary Emergency Contact</span>
              </h3>

              {user.emergencyContact?.phone || user.emergencyContact?.name ? (
                <div className="p-3.5 bg-blue-50/60 rounded-2xl border border-blue-100 space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-sm text-slate-900">
                      {user.emergencyContact.name || 'Emergency Contact'}
                    </span>
                    {user.emergencyContact.relationship && (
                      <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full font-semibold text-[10px]">
                        {user.emergencyContact.relationship}
                      </span>
                    )}
                  </div>
                  {user.emergencyContact.phone && (
                    <p className="text-slate-600 font-medium">
                      Phone: <strong className="text-slate-900">{user.emergencyContact.phone}</strong>
                    </p>
                  )}
                  {user.emergencyContact.phone && (
                    <a
                      href={`tel:${user.emergencyContact.phone.replace(/[^0-9+]/g, '')}`}
                      className="inline-flex items-center gap-1 mt-2 text-blue-600 font-bold hover:underline"
                    >
                      <Phone className="w-3 h-3" /> Test Emergency Call
                    </a>
                  )}
                </div>
              ) : (
                <div className="p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-center text-xs text-slate-500 space-y-2">
                  <p>No emergency contact configured yet.</p>
                  <button
                    onClick={() => {
                      setIsEditing(true);
                      setEditName(user.name || '');
                      setEditAge(user.age || '');
                      setEditGender(user.gender || '');
                      setEditBlood(user.bloodGroup || '');
                      setEditAddress(user.address || '');
                    }}
                    className="text-xs font-bold text-blue-600 hover:text-blue-700 hover:underline inline-flex items-center gap-1"
                  >
                    + Add Emergency Contact in Edit Profile
                  </button>
                </div>
              )}
            </div>

            {/* Location Permission Status */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-3">
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-blue-600" />
                <span>Geolocation Permission & Privacy</span>
              </h3>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600">Browser GPS Consent:</span>
                <span
                  className={`px-2.5 py-0.5 rounded-full font-bold ${
                    locationPermission
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {locationPermission ? 'Granted' : 'Not Enabled'}
                </span>
              </div>

              <p className="text-[11px] text-slate-500 leading-tight">
                Location coordinates are used exclusively to calculate distances to nearby clinics and simulate ambulance dispatch routing. MediMitra does not sell your location.
              </p>

              <button
                onClick={() => requestLocationPermission()}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
              >
                <MapPin className="w-3.5 h-3.5 text-blue-600" />
                <span>{locationPermission ? 'Refresh Current Coordinates' : 'Grant Location Permission'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
