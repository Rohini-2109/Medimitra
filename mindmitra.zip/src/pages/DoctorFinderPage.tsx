import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Phone,
  Navigation,
  Clock,
  Building2,
  Stethoscope,
  Search,
  Mic,
  Volume2,
  Siren,
  Sparkles,
  CheckCircle2,
  ShieldCheck,
  Compass,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { DoctorOrClinic } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { useSettings } from '../context/SettingsContext.tsx';
import { NavTab } from '../components/Navbar.tsx';

interface Props {
  onNavigate: (tab: NavTab) => void;
  onSelectHospitalForAmbulance?: (hospitalId: string) => void;
}

export const DoctorFinderPage: React.FC<Props> = ({
  onNavigate,
  onSelectHospitalForAmbulance,
}) => {
  const { locationPermission, userCoords, requestLocationPermission } = useAuth();
  const { language, t, speak } = useSettings();
  const [doctors, setDoctors] = useState<DoctorOrClinic[]>([]);
  const [filterCategory, setFilterCategory] = useState<'all' | 'doctor' | 'hospital'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedFacility, setSelectedFacility] = useState<DoctorOrClinic | null>(null);
  const [isListeningVoice, setIsListeningVoice] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Current Location label
  const currentLocationName = 'Indiranagar / Sector 62 (GPS Lat: 28.6289, Lng: 77.3758)';

  const fetchDoctors = async () => {
    setIsLoading(true);
    try {
      const lat = userCoords?.lat || 28.6289;
      const lng = userCoords?.lng || 77.3758;
      const res = await api.getNearbyDoctors(lat, lng);
      setDoctors(res.doctors || []);
      if (res.doctors && res.doctors.length > 0) {
        setSelectedFacility(res.doctors[0]);
      }
    } catch (err) {
      console.error('Failed to load doctors:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors();
  }, [userCoords]);

  // Voice Search for "Find the nearest doctor"
  const handleVoiceDoctorSearch = () => {
    setIsListeningVoice(true);
    const queryVoice =
      language === 'te'
        ? 'దగ్గరి వైద్యుడిని వెతుకుతున్నాము...'
        : language === 'hi'
        ? 'नजदीकी डॉक्टर को खोजा जा रहा है...'
        : 'Searching for the nearest verified doctor...';
    speak(queryVoice);

    setTimeout(() => {
      setIsListeningVoice(false);
      // Auto filter to doctors and select closest
      setFilterCategory('doctor');
      setSearchQuery('');
      const firstDoc = doctors.find((d) => d.type === 'Doctor') || doctors[0];
      if (firstDoc) {
        setSelectedFacility(firstDoc);
        const foundMsg =
          language === 'te'
            ? `దగ్గరి వైద్యుడు దొరికారు: ${firstDoc.name}. దూరం: ${firstDoc.distanceKm || '1'} కిలోమీటర్లు.`
            : language === 'hi'
            ? `नजदीकी डॉक्टर मिले: ${firstDoc.name}। दूरी: ${firstDoc.distanceKm || '1'} किमी।`
            : `Found nearest doctor: ${firstDoc.name}. Distance: ${firstDoc.distanceKm || '1'} kilometers.`;
        speak(foundMsg);
      }
    }, 1200);
  };

  const filtered = doctors.filter((doc) => {
    const matchesFilter =
      filterCategory === 'all'
        ? true
        : filterCategory === 'doctor'
        ? doc.type === 'Doctor' || doc.type === 'Clinic'
        : doc.type === 'Hospital' || doc.isEmergencyFacility;

    const matchesSearch =
      !searchQuery.trim() ||
      doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.specialization.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.address.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  const handleDispatchAmbulance = (hospitalId: string) => {
    if (onSelectHospitalForAmbulance) {
      onSelectHospitalForAmbulance(hospitalId);
    }
    onNavigate('emergency');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-16 animate-in fade-in duration-300">
      {/* 1. Header with Current Location & Voice Search Button */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
              <Stethoscope className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {t('findDoctor')}
              </h1>
              <p className="text-xs sm:text-sm font-semibold text-slate-500">
                {t('findDoctorSub')}
              </p>
            </div>
          </div>

          {/* 🎤 VOICE SEARCH: "Find the nearest doctor" */}
          <button
            id="voice-doctor-search-btn"
            onClick={handleVoiceDoctorSearch}
            className={`py-3 px-5 rounded-2xl text-xs sm:text-sm font-black transition shadow-md flex items-center gap-2.5 shrink-0 ${
              isListeningVoice
                ? 'bg-red-600 text-white animate-pulse ring-4 ring-red-200'
                : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/25 active:scale-95'
            }`}
          >
            <Mic className="w-5 h-5" />
            <span>
              {isListeningVoice
                ? t('listening')
                : language === 'te'
                ? '🎤 దగ్గరి డాక్టర్ను కనుగొనండి'
                : language === 'hi'
                ? '🎤 नजदीकी डॉक्टर खोजें'
                : '🎤 Find Nearest Doctor'}
            </span>
          </button>
        </div>

        {/* 📍 Current Location Banner */}
        <div className="p-3.5 bg-blue-50/70 border border-blue-200/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-blue-950 font-semibold">
            <MapPin className="w-4 h-4 text-blue-600 shrink-0" />
            <span>
              <strong>Current GPS Location:</strong> {currentLocationName}
            </span>
          </div>

          <button
            onClick={() => requestLocationPermission()}
            className="text-xs font-bold text-blue-700 hover:text-blue-900 underline self-start sm:self-auto"
          >
            {locationPermission ? '✓ GPS Active' : 'Refresh Location'}
          </button>
        </div>
      </div>

      {/* 2. MAP-BASED VISUAL EXPLORATION */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm sm:text-base font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-2">
            <Compass className="w-4 h-4 text-blue-600" />
            <span>Interactive Health Map</span>
          </h2>
          <span className="text-xs text-slate-400 font-semibold">
            Tap markers to view clinic details
          </span>
        </div>

        {/* Simplified Graphical Map Canvas (No external API key failure, 100% reliable) */}
        <div className="relative w-full h-64 sm:h-80 bg-gradient-to-br from-slate-100 via-blue-50/40 to-slate-200 rounded-3xl border border-slate-200 overflow-hidden shadow-inner flex items-center justify-center p-4">
          {/* Street Grid pattern */}
          <div className="absolute inset-0 opacity-15 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:32px_32px]" />

          {/* User Location Marker */}
          <div className="absolute top-[48%] left-[45%] -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white ring-4 ring-blue-300 ring-opacity-60 animate-ping absolute" />
            <div className="w-9 h-9 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg relative z-10">
              <MapPin className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-black bg-slate-900 text-white px-2 py-0.5 rounded-full mt-1 shadow-xs">
              You Are Here
            </span>
          </div>

          {/* Hospital / Doctor pins on map */}
          {doctors.map((doc, idx) => {
            const isDoc = doc.type === 'Doctor' || doc.type === 'Clinic';
            const isSelected = selectedFacility?.id === doc.id;
            // Spread positions deterministically across the map
            const positions = [
              { top: '25%', left: '72%' },
              { top: '35%', left: '22%' },
              { top: '68%', left: '75%' },
              { top: '75%', left: '30%' },
              { top: '20%', left: '42%' },
            ];
            const pos = positions[idx % positions.length];

            return (
              <button
                key={doc.id}
                onClick={() => setSelectedFacility(doc)}
                style={pos}
                className={`absolute z-10 flex flex-col items-center group transition duration-200 ${
                  isSelected ? 'scale-110' : 'hover:scale-105'
                }`}
              >
                <div
                  className={`w-8 h-8 sm:w-9 sm:h-9 rounded-2xl flex items-center justify-center shadow-md transition ${
                    isDoc
                      ? 'bg-blue-600 text-white'
                      : 'bg-red-600 text-white'
                  } ${isSelected ? 'ring-4 ring-amber-400' : ''}`}
                >
                  {isDoc ? (
                    <Stethoscope className="w-4 h-4" />
                  ) : (
                    <Building2 className="w-4 h-4" />
                  )}
                </div>
                <span
                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded mt-0.5 shadow-xs whitespace-nowrap max-w-[100px] truncate ${
                    isSelected
                      ? 'bg-amber-400 text-slate-950 font-black'
                      : 'bg-white/90 text-slate-800'
                  }`}
                >
                  {doc.name}
                </span>
              </button>
            );
          })}

          {/* Map Legend */}
          <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-xs p-2.5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3 text-[11px] font-bold text-slate-700">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-blue-600" />
              <span>You</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-lg bg-blue-600" />
              <span>Doctor</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-lg bg-red-600" />
              <span>Hospital</span>
            </span>
          </div>
        </div>
      </div>

      {/* 3. CATEGORY TOGGLES & SEARCH */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Category Pills */}
        <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 shrink-0">
          <button
            onClick={() => setFilterCategory('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              filterCategory === 'all'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All ({doctors.length})
          </button>
          <button
            onClick={() => setFilterCategory('doctor')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              filterCategory === 'doctor'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            🩺 Doctors
          </button>
          <button
            onClick={() => setFilterCategory('hospital')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              filterCategory === 'hospital'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            🏥 Hospitals
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by specialty, name, or street..."
            className="w-full text-xs pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 bg-white focus:outline-blue-600 text-slate-800"
          />
        </div>
      </div>

      {/* 4. DOCTORS & HOSPITALS RESULT LIST */}
      <div className="space-y-3.5">
        {filtered.map((doc) => {
          const isDoc = doc.type === 'Doctor' || doc.type === 'Clinic';
          const isSelected = selectedFacility?.id === doc.id;

          return (
            <div
              key={doc.id}
              className={`bg-white rounded-3xl p-5 sm:p-6 border-2 transition-all duration-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                isSelected
                  ? 'border-blue-500 ring-2 ring-blue-100'
                  : 'border-slate-200/90 hover:border-slate-300'
              }`}
            >
              {/* Info Column */}
              <div className="flex items-start gap-4 flex-1">
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-md ${
                    isDoc ? 'bg-blue-600' : 'bg-red-600'
                  }`}
                >
                  {isDoc ? (
                    <Stethoscope className="w-7 h-7" />
                  ) : (
                    <Building2 className="w-7 h-7" />
                  )}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base sm:text-lg font-black text-slate-900">
                      {doc.name}
                    </h3>
                    <span
                      className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                        isDoc
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-red-100 text-red-900'
                      }`}
                    >
                      {doc.type}
                    </span>
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                      📍 {doc.distanceKm || '1.2'} km away
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 font-semibold">
                    {doc.specialization}
                  </p>

                  <p className="text-[11px] text-slate-400">
                    {doc.address}, {doc.city} • <Clock className="w-3 h-3 inline mr-0.5" />
                    {doc.timings}
                  </p>
                </div>
              </div>

              {/* Action Buttons Column */}
              <div className="flex items-center flex-wrap gap-2 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                {/* Voice read aloud */}
                <button
                  onClick={() => {
                    const speechText = `${doc.name}. Specialization: ${doc.specialization}. Address: ${doc.address}. Phone: ${doc.phone}.`;
                    speak(speechText);
                  }}
                  className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:text-blue-600 hover:bg-blue-50 transition"
                  title="Read aloud"
                >
                  <Volume2 className="w-4 h-4" />
                </button>

                {/* Call Button */}
                <a
                  href={`tel:${doc.phone}`}
                  className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{t('callDoctor')}</span>
                </a>

                {/* Directions Button */}
                <button
                  onClick={() => {
                    alert(`Directions to ${doc.name}:\n${doc.address}\nDistance: ${doc.distanceKm || 1.2} km (Approx 6 mins drive)`);
                  }}
                  className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>{t('getDirections')}</span>
                </button>

                {/* If Hospital, dispatch ambulance option */}
                {!isDoc && (
                  <button
                    onClick={() => handleDispatchAmbulance(doc.id)}
                    className="py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black flex items-center gap-1.5 shadow-xs transition"
                  >
                    <Siren className="w-3.5 h-3.5" />
                    <span>Ambulance Route</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}

        {filtered.length === 0 && (
          <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 space-y-2">
            <p className="text-sm font-bold text-slate-700">No matching doctors found.</p>
            <p className="text-xs text-slate-500">Try changing your search terms or filters.</p>
          </div>
        )}
      </div>
    </div>
  );
};
