import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  HeartPulse,
  Mail,
  Lock,
  User,
  ShieldCheck,
  Sparkles,
  AlertCircle,
  Eye,
  EyeOff,
  ChevronDown,
  ChevronUp,
  Phone,
  Droplet,
  Calendar,
} from 'lucide-react';

export const AuthPage: React.FC = () => {
  const { login, register, demoLogin, isLoading, error, clearError } = useAuth();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Minimal form fields
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');

  // Optional expandable extra details
  const [showExtraFields, setShowExtraFields] = useState<boolean>(false);
  const [age, setAge] = useState<number | ''>('');
  const [bloodGroup, setBloodGroup] = useState<string>('');
  const [emergencyPhone, setEmergencyPhone] = useState<string>('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    clearError();

    if (!email.trim() || !password.trim()) {
      setFormError('Please enter both email and password.');
      return;
    }

    try {
      if (mode === 'login') {
        await login({ email: email.trim(), password: password.trim() });
      } else {
        if (!name.trim()) {
          setFormError('Please enter your name.');
          return;
        }
        if (password.trim().length < 6) {
          setFormError('Password must be at least 6 characters.');
          return;
        }

        await register({
          name: name.trim(),
          email: email.trim(),
          password: password.trim(),
          age: age ? Number(age) : 0,
          gender: '',
          bloodGroup: bloodGroup || '',
          allergies: [],
          existingConditions: [],
          emergencyContact: emergencyPhone.trim()
            ? {
                name: '',
                phone: emergencyPhone.trim(),
                relationship: '',
              }
            : undefined,
          locationConsent: true,
          preferredRegion: 'IN',
        });
      }
    } catch (err: any) {
      setFormError(err.message || 'Authentication failed. Please check your credentials.');
    }
  };

  const handleDemoClick = async () => {
    setFormError(null);
    clearError();
    try {
      await demoLogin();
    } catch (err: any) {
      setFormError(err.message || 'Demo sign-in failed.');
    }
  };

  const displayedError = formError || error;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50/70 via-slate-50 to-white flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8 font-sans selection:bg-blue-200 selection:text-blue-900">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        {/* Brand Header */}
        <div className="text-center space-y-2.5 mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-500/20 mb-1">
            <HeartPulse className="w-8 h-8" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Medi<span className="text-blue-600">Mitra</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">
            AI-Powered Personal Health, Wellness & Emergency Assistance Platform
          </p>
        </div>

        {/* Auth Card */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden p-6 sm:p-8 space-y-5">
          {/* Mode Switch Tabs */}
          <div className="grid grid-cols-2 p-1 bg-slate-100/90 rounded-2xl">
            <button
              id="tab-login"
              type="button"
              onClick={() => {
                setMode('login');
                setFormError(null);
                clearError();
              }}
              className={`py-2.5 text-xs sm:text-sm font-bold rounded-xl transition ${
                mode === 'login'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Sign In (Login)
            </button>
            <button
              id="tab-register"
              type="button"
              onClick={() => {
                setMode('register');
                setFormError(null);
                clearError();
              }}
              className={`py-2.5 text-xs sm:text-sm font-bold rounded-xl transition ${
                mode === 'register'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Sign Up (Register)
            </button>
          </div>

          {/* Quick Demo Option */}
          <div className="p-3 bg-blue-50/80 rounded-2xl border border-blue-100 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 text-left">
              <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-blue-950 leading-tight">Quick Demo Preview</p>
                <p className="text-[11px] text-blue-700">Explore full app directly in 1-click</p>
              </div>
            </div>
            <button
              id="auth-demo-btn"
              type="button"
              onClick={handleDemoClick}
              disabled={isLoading}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs shrink-0 disabled:opacity-50"
            >
              Try Demo
            </button>
          </div>

          <div className="relative flex items-center">
            <div className="flex-grow border-t border-slate-200" />
            <span className="shrink-0 mx-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {mode === 'login' ? 'Or login with email' : 'Simple Registration'}
            </span>
            <div className="flex-grow border-t border-slate-200" />
          </div>

          {/* Error Alert */}
          {displayedError && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3 rounded-2xl text-xs flex items-start gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <span className="font-medium leading-relaxed">{displayedError}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Registration: Name only */}
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="register-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your name"
                    required
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900 text-xs transition outline-none"
                  />
                </div>
              </div>
            )}

            {/* Email Field */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Email Address <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="auth-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@example.com"
                  required
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900 text-xs transition outline-none"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-slate-700">
                  Password <span className="text-rose-500">*</span>
                </label>
                {mode === 'register' && (
                  <span className="text-[10px] text-slate-400">Min. 6 characters</span>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="auth-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  minLength={6}
                  className="w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900 text-xs transition outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Optional Collapsible Details Note */}
            {mode === 'register' && (
              <div className="pt-1">
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600">
                  <p className="font-semibold text-slate-800 mb-0.5">
                    💡 Quick & Easy Registration
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Medical details, blood group, allergies, and emergency contacts are not needed now — you can comfortably add or edit them anytime in your <strong>Profile</strong>!
                  </p>

                  <button
                    type="button"
                    onClick={() => setShowExtraFields(!showExtraFields)}
                    className="mt-2 text-[11px] font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
                  >
                    {showExtraFields ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    <span>{showExtraFields ? 'Hide optional details' : '+ Add optional health info now (Optional)'}</span>
                  </button>

                  {showExtraFields && (
                    <div className="mt-3 pt-3 border-t border-slate-200 space-y-2.5 animate-in fade-in">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-1">
                            Age
                          </label>
                          <div className="relative">
                            <Calendar className="w-3 h-3 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                            <input
                              type="number"
                              min="1"
                              max="120"
                              value={age}
                              onChange={(e) => setAge(e.target.value === '' ? '' : Number(e.target.value))}
                              placeholder="25"
                              className="w-full pl-7 pr-2 py-1.5 rounded-lg border border-slate-200 bg-white text-xs outline-none focus:border-blue-600"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-1">
                            Blood Group
                          </label>
                          <div className="relative">
                            <Droplet className="w-3 h-3 text-rose-500 absolute left-2 top-1/2 -translate-y-1/2" />
                            <select
                              value={bloodGroup}
                              onChange={(e) => setBloodGroup(e.target.value)}
                              className="w-full pl-6 pr-1 py-1.5 rounded-lg border border-slate-200 bg-white text-xs outline-none focus:border-blue-600 font-medium"
                            >
                              <option value="">Select (Optional)</option>
                              {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                                <option key={bg} value={bg}>
                                  {bg}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-1">
                          Emergency Contact Phone
                        </label>
                        <div className="relative">
                          <Phone className="w-3 h-3 text-rose-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                          <input
                            type="tel"
                            value={emergencyPhone}
                            onChange={(e) => setEmergencyPhone(e.target.value)}
                            placeholder="+91 98765 43210 (Optional)"
                            className="w-full pl-7 pr-2 py-1.5 rounded-lg border border-slate-200 bg-white text-xs outline-none focus:border-blue-600"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              id="auth-submit-btn"
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-xl text-xs sm:text-sm font-bold transition shadow-sm flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isLoading ? (
                <span>Processing...</span>
              ) : mode === 'login' ? (
                <span>Sign In to MediMitra</span>
              ) : (
                <span>Create Account & Start</span>
              )}
            </button>
          </form>

          {/* Toggle footer */}
          <div className="pt-2 border-t border-slate-100 text-center">
            <button
              type="button"
              onClick={() => {
                setMode(mode === 'login' ? 'register' : 'login');
                setFormError(null);
                clearError();
              }}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 hover:underline"
            >
              {mode === 'login'
                ? "Don't have an account? Click here to Register"
                : 'Already have an account? Click here to Sign In'}
            </button>
          </div>
        </div>

        {/* Security / Privacy Footnote */}
        <div className="mt-6 flex items-center justify-center gap-2 text-xs text-slate-500 text-center">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Private & Secure • Update your health profile anytime</span>
        </div>
      </div>
    </div>
  );
};
