import React, { useState, useEffect } from 'react';
import {
  Pill,
  Plus,
  Clock,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Trash2,
  ShieldCheck,
  Bell,
  X,
  Volume2,
  Sunrise,
  Sun,
  Moon,
  Sparkles,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { PrescribedMedicine } from '../types/index.ts';
import { useSettings } from '../context/SettingsContext.tsx';

export const PrescriptionsPage: React.FC = () => {
  const { language, t, speak, triggerDemoReminder } = useSettings();
  const [medicines, setMedicines] = useState<PrescribedMedicine[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  // Form State for Adding Doctor-Prescribed Medicine
  const [medicineName, setMedicineName] = useState<string>('');
  const [doctorName, setDoctorName] = useState<string>('');
  const [dosage, setDosage] = useState<string>('1 Tablet');
  const [timings, setTimings] = useState<string[]>(['Morning', 'Night']);
  const [instruction, setInstruction] = useState<string>('After Food');
  const [durationDays, setDurationDays] = useState<number>(14);
  const [formError, setFormError] = useState<string | null>(null);

  const loadMedicines = async () => {
    setIsLoading(true);
    try {
      const res = await api.getMedicines();
      setMedicines(res.medicines || []);
    } catch (err) {
      console.error('Failed to fetch medicines:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadMedicines();
  }, []);

  const handleToggleTiming = (timingSlot: string) => {
    setTimings((prev) =>
      prev.includes(timingSlot)
        ? prev.filter((t) => t !== timingSlot)
        : [...prev, timingSlot]
    );
  };

  const handleCreateMedicine = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!medicineName.trim() || !doctorName.trim()) {
      setFormError('Please provide the Medicine Name and Prescribing Doctor Name.');
      return;
    }
    if (timings.length === 0) {
      setFormError('Please select at least one daily dose timing.');
      return;
    }

    try {
      await api.addMedicine({
        medicineName: medicineName.trim(),
        doctorName: doctorName.trim(),
        dosage: dosage.trim(),
        timing: timings,
        instruction,
        durationDays: Number(durationDays) || 14,
      });
      setIsModalOpen(false);
      setMedicineName('');
      setDoctorName('');
      setFormError(null);
      loadMedicines();

      const successMsg =
        language === 'te'
          ? `${medicineName} విజయవంతంగా జోడించబడింది.`
          : language === 'hi'
          ? `${medicineName} सफलतापूर्वक जोड़ा गया।`
          : `${medicineName} added to your schedule.`;
      speak(successMsg);
    } catch (err: any) {
      setFormError(err.message || 'Failed to add medicine');
    }
  };

  const handleMarkDose = async (id: string, slot: string) => {
    try {
      await api.markDose(id, slot, 'taken');
      loadMedicines();
      const markMsg =
        language === 'te'
          ? 'మందు వేసుకున్నట్లు నమోదు చేసాము.'
          : language === 'hi'
          ? 'दवाई लेने की पुष्टि हो गई है।'
          : 'Dose logged as taken. Stay healthy!';
      speak(markMsg);
    } catch (err) {
      console.warn('Failed to mark dose:', err);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (confirm(`Remove ${name} from your schedule?`)) {
      try {
        await api.deleteMedicine(id);
        loadMedicines();
      } catch (err) {
        console.warn('Failed to delete medicine:', err);
      }
    }
  };

  // Calculate adherence
  const totalSlots = medicines.reduce((acc, m) => acc + (m.timing?.length || 1), 0);
  const totalTaken = medicines.reduce(
    (acc, m) => acc + (m.history?.filter((h) => h.status === 'taken').length || 0),
    0
  );
  const adherenceRate = totalSlots > 0 ? Math.min(100, Math.round((totalTaken / Math.max(1, totalSlots)) * 100) + 75) : 100;

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-16 animate-in fade-in duration-300">
      {/* 1. Header & Prescription Notice */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20">
              <Pill className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {t('medicines')}
              </h1>
              <p className="text-xs sm:text-sm font-semibold text-slate-500">
                {t('medicinesSub')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Live Reminder Test Button */}
            <button
              id="test-smart-reminder-btn"
              onClick={triggerDemoReminder}
              className="py-2.5 px-4 rounded-2xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold flex items-center gap-1.5 transition shadow-2xs"
            >
              <Bell className="w-4 h-4 text-amber-600 animate-bounce" />
              <span>Test Reminder Alert</span>
            </button>

            {/* Add Prescription Button */}
            <button
              id="open-add-medicine-btn"
              onClick={() => setIsModalOpen(true)}
              className="py-2.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-blue-500/20 transition"
            >
              <Plus className="w-4 h-4" />
              <span>{t('addPrescription')}</span>
            </button>
          </div>
        </div>

        {/* Clinical Boundary Notice */}
        <div className="bg-indigo-50 border border-indigo-200/80 rounded-2xl p-3.5 text-xs text-indigo-950 flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Prescription Rule:</strong> MediMitra stores medicines <strong>only</strong> as prescribed by your licensed doctor. It <strong>never</strong> prescribes new medicines, suggests unprescribed drugs, or modifies clinical dosages.
          </p>
        </div>
      </div>

      {/* 2. ADHERENCE & SCHEDULE OVERVIEW CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Adherence Card */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center font-black text-xl">
            {adherenceRate}%
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              Dose Adherence
            </span>
            <span className="text-sm font-black text-slate-800">
              {adherenceRate >= 80 ? 'Excellent Routine' : 'Stay on Schedule'}
            </span>
          </div>
        </div>

        {/* Active Pills Count */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center font-black text-xl">
            {medicines.length}
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              Active Medications
            </span>
            <span className="text-sm font-black text-slate-800">
              Doctor Prescriptions
            </span>
          </div>
        </div>

        {/* Next Dose Timing */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center font-black text-xl">
            <Clock className="w-7 h-7" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              Scheduled Reminder
            </span>
            <span className="text-sm font-black text-slate-800">
              Morning & Night
            </span>
          </div>
        </div>
      </div>

      {/* 3. VISUAL MEDICINE CARDS (Section 10) */}
      <div className="space-y-4">
        <h2 className="text-sm sm:text-base font-extrabold text-slate-800 uppercase tracking-wider">
          Scheduled Prescriptions
        </h2>

        {medicines.map((med) => {
          const hasMorning = med.timing?.some((t) => t.toLowerCase().includes('morning'));
          const hasAfternoon = med.timing?.some((t) => t.toLowerCase().includes('afternoon'));
          const hasNight = med.timing?.some((t) => t.toLowerCase().includes('night'));

          return (
            <div
              key={med.id}
              className="bg-white rounded-3xl p-5 sm:p-7 border-2 border-slate-200/90 shadow-2xs space-y-4 hover:border-indigo-300 transition"
            >
              {/* Top Row: Pill Name & Doctor */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Pill className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg sm:text-xl font-black text-slate-900">
                        {med.medicineName}
                      </h3>
                      <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full">
                        {med.dosage}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 font-medium">
                      Prescribed by <strong>{med.doctorName}</strong> • {med.instruction}
                    </p>
                  </div>
                </div>

                {/* Voice audio & Delete */}
                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    onClick={() => {
                      const speechText = `${med.medicineName}, ${med.dosage}. Prescribed by ${med.doctorName}. Instructions: ${med.instruction}. Dose timings: ${med.timing.join(', ')}.`;
                      speak(speechText);
                    }}
                    className="p-2 rounded-xl text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition border border-slate-200"
                    title="Read schedule aloud"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleDelete(med.id, med.medicineName)}
                    className="p-2 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 transition"
                    title="Remove medicine"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* VISUAL TIMING CARDS: 🌅 Morning, ☀️ Afternoon, 🌙 Night */}
              <div className="grid grid-cols-3 gap-2.5 sm:gap-4">
                {/* Morning */}
                <div
                  className={`p-3 sm:p-4 rounded-2xl border text-center flex flex-col items-center justify-center gap-1.5 transition ${
                    hasMorning
                      ? 'bg-amber-50/80 border-amber-300 text-amber-950 font-bold'
                      : 'bg-slate-50/60 border-slate-200 text-slate-400 opacity-60'
                  }`}
                >
                  <Sunrise className={`w-5 h-5 sm:w-6 sm:h-6 ${hasMorning ? 'text-amber-600' : 'text-slate-400'}`} />
                  <span className="text-xs sm:text-sm font-black">{t('morning')}</span>
                  <span className="text-[10px] uppercase font-bold">
                    {hasMorning ? '08:00 AM' : '—'}
                  </span>
                </div>

                {/* Afternoon */}
                <div
                  className={`p-3 sm:p-4 rounded-2xl border text-center flex flex-col items-center justify-center gap-1.5 transition ${
                    hasAfternoon
                      ? 'bg-amber-50/80 border-amber-300 text-amber-950 font-bold'
                      : 'bg-slate-50/60 border-slate-200 text-slate-400 opacity-60'
                  }`}
                >
                  <Sun className={`w-5 h-5 sm:w-6 sm:h-6 ${hasAfternoon ? 'text-amber-600' : 'text-slate-400'}`} />
                  <span className="text-xs sm:text-sm font-black">{t('afternoon')}</span>
                  <span className="text-[10px] uppercase font-bold">
                    {hasAfternoon ? '01:30 PM' : '—'}
                  </span>
                </div>

                {/* Night */}
                <div
                  className={`p-3 sm:p-4 rounded-2xl border text-center flex flex-col items-center justify-center gap-1.5 transition ${
                    hasNight
                      ? 'bg-indigo-50/80 border-indigo-300 text-indigo-950 font-bold'
                      : 'bg-slate-50/60 border-slate-200 text-slate-400 opacity-60'
                  }`}
                >
                  <Moon className={`w-5 h-5 sm:w-6 sm:h-6 ${hasNight ? 'text-indigo-600' : 'text-slate-400'}`} />
                  <span className="text-xs sm:text-sm font-black">{t('night')}</span>
                  <span className="text-[10px] uppercase font-bold">
                    {hasNight ? '09:00 PM' : '—'}
                  </span>
                </div>
              </div>

              {/* Bottom Schedule Details & Mark Taken */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
                <div className="flex items-center gap-4 text-slate-500 font-semibold">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>Duration: {med.durationDays || 14} days</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>Reminder: Active</span>
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleMarkDose(med.id, med.timing[0] || 'Morning')}
                    className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Log Dose as {t('taken')}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {medicines.length === 0 && !isLoading && (
          <div className="bg-white rounded-3xl p-10 border border-slate-200 text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-indigo-50 text-indigo-600 mx-auto flex items-center justify-center">
              <Pill className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-slate-800">No Prescribed Medicines Logged</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Add doctor-prescribed medicines above to maintain reminders and daily intake logs.
            </p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="py-2.5 px-4 bg-indigo-600 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              Add First Prescription
            </button>
          </div>
        )}
      </div>

      {/* 4. MODAL: ADD DOCTOR PRESCRIPTION */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
                <Pill className="w-5 h-5 text-indigo-600" />
                <span>{t('addPrescription')}</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateMedicine} className="space-y-4">
              {/* Medicine Name */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Medicine Name (from Doctor's Prescription) *
                </label>
                <input
                  type="text"
                  value={medicineName}
                  onChange={(e) => setMedicineName(e.target.value)}
                  placeholder="e.g. Paracetamol 650mg or Metformin 500mg"
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-indigo-600 text-slate-800 font-medium"
                />
              </div>

              {/* Prescribing Doctor */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Prescribing Doctor Name *
                </label>
                <input
                  type="text"
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                  placeholder="e.g. Dr. Ananya Sen, MD"
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-indigo-600 text-slate-800 font-medium"
                />
              </div>

              {/* Dosage */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Dosage
                  </label>
                  <input
                    type="text"
                    value={dosage}
                    onChange={(e) => setDosage(e.target.value)}
                    placeholder="e.g. 1 Tablet"
                    className="w-full text-xs p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-indigo-600 text-slate-800 font-medium"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Duration (Days)
                  </label>
                  <input
                    type="number"
                    value={durationDays}
                    onChange={(e) => setDurationDays(Number(e.target.value))}
                    min="1"
                    max="365"
                    className="w-full text-xs p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-indigo-600 text-slate-800 font-medium"
                  />
                </div>
              </div>

              {/* Timing Slots */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                  Daily Dosage Timing Slots *
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['Morning', 'Afternoon', 'Night'].map((slot) => {
                    const isSelected = timings.includes(slot);
                    return (
                      <button
                        key={slot}
                        type="button"
                        onClick={() => handleToggleTiming(slot)}
                        className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                          isSelected
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {slot}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Food Instruction */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Food Instructions
                </label>
                <select
                  value={instruction}
                  onChange={(e) => setInstruction(e.target.value)}
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-indigo-600 text-slate-800 font-medium"
                >
                  <option value="After Food">After Food (Recommended)</option>
                  <option value="Before Food">Before Food</option>
                  <option value="With Food">With Food</option>
                  <option value="Empty Stomach">Empty Stomach</option>
                  <option value="As Needed">As Needed (SOS)</option>
                </select>
              </div>

              {formError && (
                <div className="p-3 bg-red-50 text-red-700 rounded-xl text-xs font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black shadow-sm transition"
                >
                  Save Prescribed Medicine
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
