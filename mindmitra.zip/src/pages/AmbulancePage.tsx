import React, { useState, useEffect } from 'react';
import {
  Siren,
  Phone,
  MapPin,
  Clock,
  Radio,
  Building2,
  AlertTriangle,
  CheckCircle2,
  Navigation,
  ShieldAlert,
  Copy,
  Check,
  ChevronRight,
  RefreshCw,
  XCircle,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { AmbulanceDispatch, DoctorOrClinic } from '../types/index.ts';
import { NavTab } from '../components/Navbar.tsx';

interface Props {
  onNavigate: (tab: NavTab) => void;
  selectedHospitalId?: string;
}

export const AmbulancePage: React.FC<Props> = ({ onNavigate, selectedHospitalId }) => {
  const { user, userCoords, locationPermission, requestLocationPermission } = useAuth();
  const [hospitals, setHospitals] = useState<DoctorOrClinic[]>([]);
  const [selectedHospital, setSelectedHospital] = useState<string>('');
  const [patientCondition, setPatientCondition] = useState<string>('Acute chest pain & respiratory distress');
  const [activeDispatch, setActiveDispatch] = useState<AmbulanceDispatch | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedCoords, setCopiedCoords] = useState<boolean>(false);
  const [simulationRunning, setSimulationRunning] = useState<boolean>(false);

  useEffect(() => {
    // Load emergency hospitals & check if an active dispatch already exists
    const loadInitial = async () => {
      try {
        const docRes = await api.getEmergencyFacilities();
        setHospitals(docRes.facilities || []);
        if (docRes.facilities && docRes.facilities.length > 0) {
          setSelectedHospital(selectedHospitalId || docRes.facilities[0].id);
        }

        const activeRes = await api.getActiveAmbulances();
        if (activeRes.dispatches && activeRes.dispatches.length > 0) {
          setActiveDispatch(activeRes.dispatches[0]);
        }
      } catch (err) {
        console.error('Failed to initialize emergency dispatch:', err);
      }
    };
    loadInitial();
  }, [selectedHospitalId]);

  // Auto progression loop if active
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (activeDispatch && activeDispatch.status !== 'arrived' && activeDispatch.status !== 'cancelled') {
      interval = setInterval(async () => {
        try {
          const res = await api.stepAmbulanceSimulation(activeDispatch.id);
          setActiveDispatch(res.dispatch);
        } catch (err) {
          console.warn('Simulation tick error:', err);
        }
      }, 12000); // Progress every 12 seconds
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeDispatch?.id, activeDispatch?.status, activeDispatch?.currentJunctionIndex]);

  const handleActivateAmbulance = async () => {
    setIsLoading(true);
    try {
      const res = await api.activateAmbulance({
        patientName: user?.name || 'Emergency Caller',
        callerPhone: user?.emergencyContact?.phone || '+91 98765 01234',
        originLat: userCoords?.lat || 28.6215,
        originLng: userCoords?.lng || 77.362,
        originAddress: user?.address || 'User Geolocation (Sector 58, Green Enclave)',
        hospitalId: selectedHospital,
      });
      setActiveDispatch(res.dispatch);
    } catch (err: any) {
      alert(err.message || 'Failed to dispatch ambulance simulation');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStepSimulation = async () => {
    if (!activeDispatch) return;
    try {
      const res = await api.stepAmbulanceSimulation(activeDispatch.id);
      setActiveDispatch(res.dispatch);
    } catch (err) {
      console.error('Failed to step simulation:', err);
    }
  };

  const handleCancelDispatch = async () => {
    if (!activeDispatch) return;
    if (confirm('Cancel active ambulance dispatch simulation?')) {
      try {
        const res = await api.cancelAmbulance(activeDispatch.id);
        setActiveDispatch(res.dispatch);
      } catch (err) {
        console.error('Failed to cancel ambulance:', err);
      }
    }
  };

  const handleCopyLocation = () => {
    const lat = userCoords?.lat || 28.6289;
    const lng = userCoords?.lng || 77.3758;
    const locString = `Coordinates: ${lat.toFixed(5)}, ${lng.toFixed(5)} | Address: ${user?.address || 'Sector 58, Noida'}`;
    navigator.clipboard.writeText(locString);
    setCopiedCoords(true);
    setTimeout(() => setCopiedCoords(false), 3000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Simulation Notice Disclaimer */}
      <div className="bg-amber-50 border-2 border-amber-300 rounded-3xl p-5 shadow-xs space-y-2">
        <div className="flex items-center gap-2 text-amber-900 font-extrabold text-sm">
          <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0" />
          <span>PROTOTYPE SIMULATION NOTICE (TRAFFIC COORDINATION RESEARCH)</span>
        </div>
        <p className="text-xs text-amber-950 font-medium leading-relaxed">
          The Smart Ambulance Traffic Coordination system below is a simulated prototype demonstrating automated route preemption and traffic dashboard communication. <strong>It does NOT dispatch real municipal emergency services or traffic police.</strong> In a true life-threatening crisis, dial <strong>112 (India) / 911 (US) / 999 (UK)</strong> immediately on your telephone.
        </p>
      </div>

      {/* Emergency Quick Numbers Direct Helplines */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-xs">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">National Emergency Helplines</h2>
              <p className="text-xs text-slate-500">Tap to place an instant call from your device</p>
            </div>
          </div>
          <span className="text-[11px] font-bold bg-rose-100 text-rose-800 px-2.5 py-1 rounded-full">
            Toll-Free 24/7
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <a
            href="tel:112"
            className="flex items-center justify-between p-3.5 rounded-2xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-950 transition group"
          >
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 block">
                Universal Emergency
              </span>
              <span className="text-xl font-black text-rose-800 group-hover:scale-105 transition">112</span>
            </div>
            <Phone className="w-5 h-5 text-rose-600" />
          </a>

          <a
            href="tel:102"
            className="flex items-center justify-between p-3.5 rounded-2xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-950 transition group"
          >
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-sky-700 block">
                Ambulance Helpline
              </span>
              <span className="text-xl font-black text-sky-800 group-hover:scale-105 transition">102 / 108</span>
            </div>
            <Siren className="w-5 h-5 text-sky-600" />
          </a>

          <a
            href="tel:100"
            className="flex items-center justify-between p-3.5 rounded-2xl bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-950 transition group"
          >
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 block">
                Police Assistance
              </span>
              <span className="text-xl font-black text-blue-800 group-hover:scale-105 transition">100</span>
            </div>
            <Phone className="w-5 h-5 text-blue-600" />
          </a>

          <a
            href="tel:14416"
            className="flex items-center justify-between p-3.5 rounded-2xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-950 transition group"
          >
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700 block">
                Tele-MANAS Mental Health
              </span>
              <span className="text-xl font-black text-purple-800 group-hover:scale-105 transition">14416</span>
            </div>
            <Phone className="w-5 h-5 text-purple-600" />
          </a>
        </div>
      </div>

      {/* User's GPS Location & Emergency Contact Card */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-slate-800">
            <MapPin className="w-5 h-5 text-blue-600 shrink-0" />
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                Your Exact Geolocation & Address (To Share with Responders)
              </span>
              <p className="text-sm font-extrabold text-slate-900 mt-0.5">
                {userCoords
                  ? `Lat: ${userCoords.lat.toFixed(5)}, Long: ${userCoords.lng.toFixed(5)}`
                  : 'Coordinates: 28.62890, 77.37580'}
              </p>
              <p className="text-xs text-slate-600 mt-0.5">
                {user?.address || '14 Green Enclave, Sector 58, National Capital Region'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!locationPermission && (
              <button
                onClick={() => requestLocationPermission()}
                className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 text-xs font-semibold rounded-xl border border-blue-200"
              >
                Refresh GPS
              </button>
            )}
            <button
              id="copy-emergency-location-btn"
              onClick={handleCopyLocation}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition flex items-center gap-1.5"
            >
              {copiedCoords ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Coordinates</span>
                </>
              )}
            </button>
          </div>
        </div>

        {user?.emergencyContact && (
          <div className="pt-2 border-t border-slate-100 text-xs text-slate-600 flex flex-wrap items-center gap-4">
            <span>
              Registered Emergency Contact: <strong className="text-slate-800">{user.emergencyContact.name}</strong> ({user.emergencyContact.relationship})
            </span>
            <a
              href={`tel:${user.emergencyContact.phone.replace(/[^0-9+]/g, '')}`}
              className="font-bold text-blue-600 hover:underline flex items-center gap-1"
            >
              <Phone className="w-3 h-3" /> {user.emergencyContact.phone}
            </a>
          </div>
        )}
      </div>

      {/* Dispatch Activation OR Active Tracking Screen */}
      {!activeDispatch || activeDispatch.status === 'cancelled' || activeDispatch.status === 'arrived' ? (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-xs">
              <Siren className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-slate-900">
                Activate Smart Ambulance Dispatch (Simulation)
              </h3>
              <p className="text-xs text-slate-500">
                Configures route, automated junction alerts, and coordinates with the Traffic Control Dashboard.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-800 block mb-1">
                Select Destination Emergency Hospital:
              </label>
              <select
                value={selectedHospital}
                onChange={(e) => setSelectedHospital(e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900 text-xs sm:text-sm font-semibold"
              >
                {hospitals.map((h) => (
                  <option key={h.id} value={h.id}>
                    {h.name} ({h.specialization}) - {h.address}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-800 block mb-1">
                Patient Emergency Condition Summary:
              </label>
              <input
                type="text"
                value={patientCondition}
                onChange={(e) => setPatientCondition(e.target.value)}
                placeholder="e.g. Suspected stroke, acute trauma, severe respiratory distress"
                className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-slate-900 text-xs sm:text-sm"
              />
            </div>

            <div className="pt-2">
              <button
                id="activate-ambulance-sos-btn"
                onClick={handleActivateAmbulance}
                disabled={isLoading}
                className="w-full py-4 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-extrabold text-sm sm:text-base rounded-2xl transition shadow-md hover:shadow-lg flex items-center justify-center gap-2"
              >
                <Siren className="w-5 h-5 animate-bounce" />
                <span>{isLoading ? 'Activating Emergency Dispatch...' : 'DISPATCH SMART AMBULANCE NOW (SIMULATED)'}</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Active Ambulance Live Coordination View */
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-rose-300 shadow-md space-y-6">
          {/* Top Status Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center animate-pulse">
                <Siren className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-extrabold text-slate-900">
                    Ambulance Unit {activeDispatch.id.toUpperCase()}
                  </span>
                  <span className="text-[10px] uppercase font-black bg-rose-600 text-white px-2 py-0.5 rounded-full animate-pulse">
                    EN ROUTE
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  Destination: <strong className="text-slate-800">{activeDispatch.destinationHospital.name}</strong>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-xs text-slate-400 block font-semibold">Estimated Arrival</span>
                <span className="text-2xl font-black text-rose-600">
                  {activeDispatch.etaMinutes} MINS
                </span>
              </div>

              <button
                onClick={handleCancelDispatch}
                className="p-2 text-slate-400 hover:text-rose-600 rounded-xl hover:bg-slate-100 transition"
                title="Cancel Dispatch"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Simulated Alert Notification Broadcast */}
          <div className="bg-slate-900 text-white rounded-2xl p-4 space-y-2 border border-slate-800 shadow-inner">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 animate-spin" />
                Live Broadcast to Traffic Control Dashboard
              </span>
              <span
                className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                  activeDispatch.alertAcknowledgedByControl
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}
              >
                {activeDispatch.alertAcknowledgedByControl
                  ? 'ACKNOWLEDGED • GREEN CORRIDOR ACTIVE'
                  : 'AWAITING TRAFFIC ACKNOWLEDGEMENT'}
              </span>
            </div>

            <p className="font-mono text-xs sm:text-sm text-emerald-400 font-bold bg-black/40 p-3 rounded-xl border border-slate-800 leading-relaxed">
              "{activeDispatch.alertMessage}"
            </p>
          </div>

          {/* Visual Route Canvas / SVG Map Simulation */}
          <div className="bg-slate-950 rounded-2xl p-4 sm:p-6 text-white space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-bold flex items-center gap-1.5">
                <Navigation className="w-3.5 h-3.5 text-blue-400" />
                Simulated Route Map & Waypoint Geodesic
              </span>
              <span className="text-emerald-400 font-semibold">
                Traffic Status: {activeDispatch.trafficCondition.toUpperCase()}
              </span>
            </div>

            {/* SVG Interactive Track */}
            <div className="relative h-28 w-full bg-slate-900/80 rounded-xl overflow-hidden flex items-center px-4 sm:px-12 border border-slate-800">
              {/* Route Connecting Line */}
              <div className="absolute left-8 right-8 h-1.5 bg-slate-700 rounded-full">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-blue-400 rounded-full transition-all duration-700"
                  style={{
                    width: `${Math.min(
                      100,
                      ((activeDispatch.currentJunctionIndex + 1) / activeDispatch.junctions.length) * 100
                    )}%`,
                  }}
                />
              </div>

              {/* Waypoint Junction Circles */}
              <div className="relative z-10 w-full flex items-center justify-between">
                {/* Origin */}
                <div className="flex flex-col items-center">
                  <div className="w-5 h-5 rounded-full bg-blue-500 ring-4 ring-blue-900 flex items-center justify-center text-[9px] font-bold">
                    O
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 font-semibold">Origin</span>
                </div>

                {/* Junctions */}
                {activeDispatch.junctions.map((junc, idx) => {
                  const isCurrent = idx === activeDispatch.currentJunctionIndex;
                  const isPast = idx < activeDispatch.currentJunctionIndex;

                  return (
                    <div key={junc.id} className="flex flex-col items-center">
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold transition-all ${
                          isCurrent
                            ? 'bg-rose-600 ring-4 ring-rose-900 scale-125 animate-pulse'
                            : isPast
                            ? 'bg-emerald-500 ring-2 ring-emerald-900'
                            : 'bg-slate-700 ring-2 ring-slate-800'
                        }`}
                      >
                        {isPast ? '✓' : idx + 1}
                      </div>
                      <span className="text-[9px] text-slate-400 mt-1 font-medium max-w-[70px] truncate text-center">
                        {junc.name.split(' ')[0]}
                      </span>
                    </div>
                  );
                })}

                {/* Hospital Destination */}
                <div className="flex flex-col items-center">
                  <div className="w-6 h-6 rounded-full bg-rose-600 ring-4 ring-rose-950 flex items-center justify-center text-[10px] font-bold">
                    H
                  </div>
                  <span className="text-[10px] text-rose-400 mt-1 font-bold">Hospital</span>
                </div>
              </div>
            </div>
          </div>

          {/* Upcoming Junctions Real-Time Status Table */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600" />
              <span>Junction Preemption & Corridor Status</span>
            </h4>

            <div className="space-y-2">
              {activeDispatch.junctions.map((junc, idx) => {
                const isCurrent = idx === activeDispatch.currentJunctionIndex;
                const isPast = idx < activeDispatch.currentJunctionIndex;

                return (
                  <div
                    key={junc.id}
                    className={`p-3 rounded-2xl border flex items-center justify-between text-xs transition ${
                      isCurrent
                        ? 'bg-rose-50 border-rose-300 text-rose-950 font-bold'
                        : isPast
                        ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                        : 'bg-slate-50 border-slate-200 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                          isCurrent
                            ? 'bg-rose-600 animate-ping'
                            : isPast
                            ? 'bg-emerald-600'
                            : 'bg-slate-400'
                        }`}
                      />
                      <span>
                        Junction {idx + 1}: <strong>{junc.name}</strong>
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-slate-500 font-medium">
                        {junc.distanceMeters}m away
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          isCurrent
                            ? 'bg-rose-200 text-rose-900'
                            : isPast
                            ? 'bg-emerald-200 text-emerald-900'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {isCurrent ? 'Approaching' : isPast ? 'Cleared' : 'Queued'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Simulation Step Actions & Traffic Control Jump */}
          <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              id="step-simulation-btn"
              onClick={handleStepSimulation}
              className="w-full sm:w-auto px-4 py-2.5 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-xs"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Simulate Next Junction Step</span>
            </button>

            <button
              id="switch-traffic-dashboard-btn"
              onClick={() => onNavigate('traffic')}
              className="w-full sm:w-auto px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-xs"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Open Traffic Control Dashboard</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
