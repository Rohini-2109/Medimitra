import React, { useState, useEffect } from 'react';
import {
  Siren,
  Phone,
  Radio,
  MapPin,
  Share2,
  Users,
  Clock,
  Building2,
  AlertTriangle,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  CheckCircle2,
  ShieldAlert,
  ChevronRight,
  Heart,
  Flame,
  Activity,
  Zap,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { useSettings } from '../context/SettingsContext.tsx';
import { AmbulanceDispatch, DoctorOrClinic } from '../types/index.ts';
import { NavTab } from '../components/Navbar.tsx';

interface Props {
  onNavigate: (tab: NavTab) => void;
  selectedHospitalId?: string;
}

export const EmergencyHubPage: React.FC<Props> = ({ onNavigate, selectedHospitalId }) => {
  const { user, userCoords } = useAuth();
  const { language, t, speak } = useSettings();

  // Emergency Mode Action states
  const [copiedCoords, setCopiedCoords] = useState<boolean>(false);
  const [familyNotified, setFamilyNotified] = useState<boolean>(false);

  // HERO SIMULATION STATE (Section 13)
  const [simRunning, setSimRunning] = useState<boolean>(false);
  const [simProgress, setSimProgress] = useState<number>(35); // 0 to 100%
  const [timeSavedMins, setTimeSavedMins] = useState<number>(8);
  const [activeHospitalName, setActiveHospitalName] = useState<string>('City Care Super-Specialty Hospital');
  const [activeSignalIndex, setActiveSignalIndex] = useState<number>(1);

  // Selected First Aid guide for playback
  const [activeAidIndex, setActiveAidIndex] = useState<number | null>(null);

  // Requirement 8: When Emergency Hub is opened, announce using female voice in selected language
  useEffect(() => {
    speak(t('emergencyVoiceAnnouncement'));
  }, [language]);

  // 1. First Aid Audio Guides (User Request Section 15)
  const firstAidGuides = [
    {
      id: 'heart_attack',
      title: 'Heart Attack Signs',
      titleTe: 'గుండెపోటు సంకేతాలు',
      titleHi: 'दिल के दौरे के लक्षण',
      emoji: '🫀',
      summary: 'Chest tightness, pain spreading to left arm or jaw, shortness of breath, cold sweat.',
      audioText:
        language === 'te'
          ? 'గుండెపోటు సంకేతాలు: ఛాతీలో ఒత్తిడి, ఎడమ చేతికి నొప్పి వ్యాపించడం, శ్వాస ఆడకపోవడం. వెంటనే 108 కి కాల్ చేయండి. రోగిని విశ్రాంతిగా కూర్చోబెట్టండి.'
          : language === 'hi'
          ? 'दिल के दौरे के लक्षण: सीने में भारीपन, बाएं हाथ या जबड़े में दर्द, सांस फूलना। तुरंत 108 पर कॉल करें और मरीज को शांत बैठाएं।'
          : 'Heart attack warning signs: Chest pressure, pain radiating to the left arm or jaw, shortness of breath, and cold sweat. Immediately call 108 or 112. Keep the person sitting upright and calm.',
      action: 'Keep patient seated upright. Loosen tight clothing. Call 108 immediately.',
    },
    {
      id: 'choking',
      title: 'Choking First Aid',
      titleTe: 'గొంతులో ఆహారం ఇరుక్కుపోవడం',
      titleHi: 'दम घुटना (चोकिंग)',
      emoji: '🗣️',
      summary: 'Unable to speak, clutching throat, wheezing or coughing weakly.',
      audioText:
        language === 'te'
          ? 'గొంతులో ఆహారం ఇరుక్కున్నప్పుడు: రోగి వీపుపై 5 సార్లు గట్టిగా కొట్టండి, ఆపై పొట్టపై ఒత్తిడి (హైమ్లిక్ పద్ధతి) చేయండి.'
          : language === 'hi'
          ? 'चोकिंग की स्थिति में: मरीज की पीठ पर 5 बार थपथपाएं और फिर पेट के ऊपरी हिस्से पर दबाव दें।'
          : 'Choking first aid: Deliver 5 sharp back blows between the shoulder blades, followed by 5 quick abdominal thrusts (Heimlich maneuver). Repeat until airway clears.',
      action: '5 firm back blows followed by upward abdominal thrusts (Heimlich maneuver).',
    },
    {
      id: 'bleeding',
      title: 'Severe Bleeding',
      titleTe: 'తీవ్రమైన రక్తస్రావం',
      titleHi: 'गंभीर रक्तस्राव',
      emoji: '🩸',
      summary: 'Rapid blood loss from deep cuts or trauma.',
      audioText:
        language === 'te'
          ? 'తీవ్రమైన రక్తస్రావం: శుభ్రమైన గుడ్డతో గాయంపై గట్టిగా నొక్కి పట్టుకోండి. సాధ్యమైతే గాయాన్ని గుండె కంటే ఎత్తులో ఉంచండి.'
          : language === 'hi'
          ? 'गंभीर रक्तस्राव: साफ कपड़े से घाव पर सीधा दबाव बनाएं और चोट लगे अंग को थोड़ा ऊपर रखें।'
          : 'Severe bleeding: Apply direct continuous firm pressure with a clean cloth or bandage. Elevate the wounded limb above heart level if possible.',
      action: 'Apply firm direct pressure with clean cloth. Elevate injured limb above heart level.',
    },
    {
      id: 'burns',
      title: 'Burns & Scalds',
      titleTe: 'కాలిన గాయాలు',
      titleHi: 'जलने पर प्राथमिक उपचार',
      emoji: '🔥',
      summary: 'Thermal or hot liquid burns on skin.',
      audioText:
        language === 'te'
          ? 'కాలిన గాయాలు: కనీసం 10 నుండి 20 నిమిషాలు చల్లని ప్రవహించే నీటి కింద ఉంచండి. మంచు లేదా నూనె వేయవద్దు.'
          : language === 'hi'
          ? 'जलने पर: कम से कम 10 से 20 मिनट तक बहते ठंडे पानी के नीचे रखें। बर्फ या तेल न लगाएं।'
          : 'Burns: Cool immediately under cold running tap water for at least 10 to 20 minutes. Do not apply ice, butter, or paste.',
      action: 'Cool under gentle running cold tap water for 10-20 minutes. Do not apply ice or oils.',
    },
    {
      id: 'seizures',
      title: 'Seizures & Fits',
      titleTe: 'మూర్ఛ (ఫిట్స్)',
      titleHi: 'दौरे पड़ना (मिरगी)',
      emoji: '⚡',
      summary: 'Sudden convulsions, jerking limbs, loss of responsiveness.',
      audioText:
        language === 'te'
          ? 'మూర్ఛ లేదా ఫిట్స్: రోగిని ఒక వైపుకు తిప్పి పడుకోబెట్టండి. నోటిలో ఏమీ పెట్టవద్దు, గట్టిగా పట్టుకోవద్దు.'
          : language === 'hi'
          ? 'दौरे के समय: मरीज को करवट दिलाकर लिटाएं। मुंह में कुछ न डालें और जबरदस्ती न रोकें।'
          : 'Seizures: Ease the person onto their side into recovery position. Clear hard objects away. Never put anything in their mouth or hold them down.',
      action: 'Ease onto their side into recovery position. Protect head. Do not restrain or insert mouth objects.',
    },
  ];

  // Simulation Timer loop
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (simRunning) {
      interval = setInterval(() => {
        setSimProgress((prev) => {
          if (prev >= 95) {
            setSimRunning(false);
            const arrivedMsg =
              language === 'te'
                ? 'అంబులెన్స్ ఆసుపత్రికి చేరుకుంది! గ్రీన్ కారిడార్ ద్వారా 8 నిమిషాలు ఆదా అయ్యాయి.'
                : language === 'hi'
                ? 'एम्बुलेंस अस्पताल पहुंच गई है! ग्रीन कॉरिडोर से 8 मिनट की बचत हुई।'
                : 'Ambulance safely reached hospital! Green corridor saved 8 critical minutes.';
            speak(arrivedMsg);
            return 100;
          }
          const next = prev + 15;
          if (next > 70) setActiveSignalIndex(3);
          else if (next > 40) setActiveSignalIndex(2);
          else setActiveSignalIndex(1);
          return next;
        });
      }, 2500);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [simRunning]);

  const handleStartSimulation = () => {
    setSimProgress(15);
    setActiveSignalIndex(1);
    setSimRunning(true);
    const introMsg =
      language === 'te'
        ? 'స్మార్ట్ అంబులెన్స్ ట్రాఫిక్ సిమ్యులేషన్ ప్రారంభమైంది. రాబోయే సిగ్నల్స్ స్వయంచాలకంగా ఆకుపచ్చగా మారుతాయి.'
        : language === 'hi'
        ? 'स्मार्ट एम्बुलेंस ट्रैफिक सिमुलेशन शुरू हुआ। आने वाले सिग्नल अपने आप हरे हो रहे हैं।'
        : 'Smart Ambulance Traffic Simulation started. Green corridor signals are preempting traffic.';
    speak(introMsg);
  };

  const handleResetSimulation = () => {
    setSimRunning(false);
    setSimProgress(10);
    setActiveSignalIndex(1);
  };

  const handleNotifyFamily = () => {
    setFamilyNotified(true);
    const familyMsg =
      language === 'te'
        ? 'కుటుంబ సభ్యులకు మీ స్థానం మరియు అత్యవసర హెచ్చరిక పంపబడింది.'
        : language === 'hi'
        ? 'परिवार के सदस्यों को आपातकालीन संदेश और लोकेशन भेज दी गई है।'
        : 'Emergency contact notified with your live GPS location.';
    speak(familyMsg);
  };

  const handleCopyLocation = () => {
    const lat = userCoords?.lat || 28.6289;
    const lng = userCoords?.lng || 77.3758;
    navigator.clipboard?.writeText(`Emergency Location: https://maps.google.com/?q=${lat},${lng}`);
    setCopiedCoords(true);
    setTimeout(() => setCopiedCoords(false), 2000);
    speak('GPS coordinates copied to clipboard');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20 animate-in fade-in duration-300">
      {/* 1. EMERGENCY MODE ESSENTIALS: High contrast, large buttons (Section 14) */}
      <section className="bg-red-600 text-white rounded-3xl p-6 sm:p-8 shadow-xl shadow-red-600/30 space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white text-red-600 flex items-center justify-center font-black shadow-md">
              <Siren className="w-7 h-7 animate-bounce" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
                {t('emergency')} Help Mode
              </h1>
              <p className="text-xs sm:text-sm font-semibold text-red-100">
                Immediate assistance • National SOS • Live Traffic Corridor
              </p>
            </div>
          </div>

          <span className="text-[11px] font-black uppercase bg-red-800 text-white px-3 py-1 rounded-full border border-red-400">
            Emergency Ready
          </span>
        </div>

        {/* Live Emergency Spoken Announcement (Requirement 8) */}
        <div className="bg-red-700/80 rounded-2xl p-4 sm:p-5 border border-red-400/60 shadow-inner space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
              <span>{t('emergencyVoiceTitle')}</span>
            </h2>
            <button
              id="emergency-listen-voice-btn"
              onClick={() => {
                speak(t('emergencyVoiceAnnouncement'));
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white text-red-700 hover:bg-red-50 text-xs font-black rounded-xl shadow-sm transition cursor-pointer"
            >
              <Volume2 className="w-4 h-4 text-red-600" />
              <span>{t('listenToVoice')}</span>
            </button>
          </div>

          {/* Spoken text quote */}
          <div className="bg-red-800/80 rounded-xl p-3 border border-red-500/50 text-xs sm:text-sm font-bold text-red-50 leading-relaxed">
            "{t('emergencyVoiceAnnouncement')}"
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm font-bold text-red-50">
            <div className="flex items-center gap-2 bg-red-800/60 px-3 py-2 rounded-xl border border-red-500/40">
              <span className="w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center text-xs font-black shrink-0">1</span>
              <span>{t('emergencyStep1')}</span>
            </div>
            <div className="flex items-center gap-2 bg-red-800/60 px-3 py-2 rounded-xl border border-red-500/40">
              <span className="w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center text-xs font-black shrink-0">2</span>
              <span>{t('emergencyStep2')}</span>
            </div>
            <div className="flex items-center gap-2 bg-red-800/60 px-3 py-2 rounded-xl border border-red-500/40">
              <span className="w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center text-xs font-black shrink-0">3</span>
              <span>{t('emergencyStep3')}</span>
            </div>
            <div className="flex items-center gap-2 bg-red-800/60 px-3 py-2 rounded-xl border border-red-500/40">
              <span className="w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center text-xs font-black shrink-0">4</span>
              <span>{t('emergencyStep4')}</span>
            </div>
          </div>
        </div>

        {/* Nearest Emergency Hospital with Prominent Directions (Requirement 8) */}
        <div className="bg-white text-slate-900 rounded-2xl p-5 border border-red-200 shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base text-slate-900">Apollo Trauma & Emergency Center</span>
                <span className="text-[10px] font-black uppercase bg-red-100 text-red-700 px-2 py-0.5 rounded-full">Open 24/7</span>
              </div>
              <p className="text-xs text-slate-500 font-semibold">1.4 km away • Estimated 4 mins arrival with Green Corridor</p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <a
              id="emergency-directions-btn"
              href="https://maps.google.com/?q=Apollo+Hospital"
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs sm:text-sm shadow-md transition"
            >
              <MapPin className="w-4 h-4" />
              <span>{t('getDirections')}</span>
            </a>
            <a
              id="emergency-call-hospital-btn"
              href="tel:108"
              className="inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-black text-xs sm:text-sm transition"
            >
              <Phone className="w-4 h-4 text-red-600" />
              <span>108</span>
            </a>
          </div>
        </div>

        {/* 5 Essential Buttons (Section 14 & Requirement 8) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 pt-2">
          {/* 📞 Call Emergency (108 / 112) - Prominent */}
          <a
            id="emergency-call-108-btn"
            href="tel:108"
            className="p-5 rounded-2xl bg-white text-red-700 hover:bg-red-50 font-black flex items-center gap-3 shadow-lg active:scale-95 transition"
          >
            <div className="w-12 h-12 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-md">
              <Phone className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="text-base sm:text-lg block leading-tight">
                {t('callEmergency')}
              </span>
              <span className="text-[11px] font-bold text-red-500">
                National Ambulance Line • 108 / 112
              </span>
            </div>
          </a>

          {/* 🚑 Request Ambulance */}
          <button
            onClick={handleStartSimulation}
            className="p-5 rounded-2xl bg-red-700 hover:bg-red-800 border-2 border-red-400 text-white font-black flex items-center gap-3 shadow-lg active:scale-95 transition text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-white text-red-700 flex items-center justify-center shrink-0 shadow-md">
              <Siren className="w-6 h-6" />
            </div>
            <div>
              <span className="text-base sm:text-lg block leading-tight">
                {t('requestAmbulance')}
              </span>
              <span className="text-[11px] font-bold text-red-200">
                Dispatch with Green Light
              </span>
            </div>
          </button>

          {/* 👨‍👩‍👧 Notify Family */}
          <button
            onClick={handleNotifyFamily}
            className={`p-5 rounded-2xl border-2 text-left font-black flex items-center gap-3 shadow-lg active:scale-95 transition ${
              familyNotified
                ? 'bg-emerald-600 text-white border-emerald-400'
                : 'bg-red-700 hover:bg-red-800 border-red-400 text-white'
            }`}
          >
            <div className="w-12 h-12 rounded-xl bg-white text-red-700 flex items-center justify-center shrink-0 shadow-md">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <span className="text-base sm:text-lg block leading-tight">
                {familyNotified ? '✓ Family Notified' : t('notifyFamily')}
              </span>
              <span className="text-[11px] font-bold text-red-200">
                {user?.emergencyContact?.name || 'Emergency Contact'}
              </span>
            </div>
          </button>

          {/* 📍 Send Location */}
          <button
            onClick={handleCopyLocation}
            className="p-5 rounded-2xl bg-red-700 hover:bg-red-800 border-2 border-red-400 text-white font-black flex items-center gap-3 shadow-lg active:scale-95 transition text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-white text-red-700 flex items-center justify-center shrink-0 shadow-md">
              <MapPin className="w-6 h-6" />
            </div>
            <div>
              <span className="text-base sm:text-lg block leading-tight">
                {copiedCoords ? '✓ Link Copied!' : t('sendLocation')}
              </span>
              <span className="text-[11px] font-bold text-red-200">
                GPS Lat: 28.62, Lng: 77.37
              </span>
            </div>
          </button>
        </div>
      </section>

      {/* 2. EMERGENCY HERO FEATURE: SMART AMBULANCE TRAFFIC COORDINATION (SIMULATED) (Section 13) */}
      <section className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-2xl space-y-6">
        {/* Simulation Hero Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black tracking-tight">
                  {t('smartTrafficDemo')}
                </h2>
                <span className="text-[9px] uppercase font-black bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full">
                  SIMULATION / DEMO
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Dynamic Green Corridor creates clear transit for emergency vehicles
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!simRunning ? (
              <button
                id="start-traffic-sim-btn"
                onClick={handleStartSimulation}
                className="py-2.5 px-5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 shadow-md shadow-emerald-500/20 active:scale-95 transition"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>{t('startSimulation')}</span>
              </button>
            ) : (
              <button
                onClick={() => setSimRunning(false)}
                className="py-2.5 px-4 bg-amber-400 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 active:scale-95 transition"
              >
                <Pause className="w-4 h-4 fill-slate-950" />
                <span>Pause</span>
              </button>
            )}

            <button
              onClick={handleResetSimulation}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition"
              title="Reset Simulation"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* METRICS STRIP: Time Saved & Destination */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-0.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              ⏱️ Time Saved by Green Corridor
            </span>
            <span className="text-2xl font-black text-emerald-400">
              {timeSavedMins} Minutes Saved
            </span>
          </div>

          <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-0.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              🏥 Hospital Destination
            </span>
            <span className="text-base font-black text-white truncate block">
              {activeHospitalName}
            </span>
          </div>

          <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-0.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              👨‍👩‍👧 Emergency Alert Status
            </span>
            <span className="text-sm font-bold text-sky-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-sky-400" />
              <span>SMS Dispatched with Live ETA</span>
            </span>
          </div>
        </div>

        {/* 🗺️ VISUAL ROUTE MAP & MOVING AMBULANCE (Section 13) */}
        <div className="bg-slate-950 rounded-3xl p-5 sm:p-6 border border-slate-800 space-y-6">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <span>🗺️ LIVE CORRIDOR PROGRESS</span>
            <span>{simProgress}% En Route ({Math.max(1, Math.round((100 - simProgress) / 10))} mins remaining)</span>
          </div>

          {/* Progress Track with Moving Ambulance Icon */}
          <div className="relative pt-6 pb-2">
            {/* The Road Track */}
            <div className="h-4 bg-slate-800 rounded-full w-full relative overflow-hidden border border-slate-700">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 via-sky-500 to-blue-500 transition-all duration-700 rounded-full"
                style={{ width: `${simProgress}%` }}
              />
            </div>

            {/* Moving Ambulance Pin */}
            <div
              className="absolute top-0 -translate-x-1/2 transition-all duration-700 flex flex-col items-center"
              style={{ left: `${Math.max(5, Math.min(95, simProgress))}%` }}
            >
              <div className="w-10 h-10 rounded-2xl bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-500/50 border-2 border-white animate-pulse">
                <Siren className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-black bg-red-600 text-white px-1.5 py-0.2 rounded mt-1 shadow-xs uppercase">
                Ambulance #108
              </span>
            </div>
          </div>

          {/* 🚦 THREE TRAFFIC SIGNALS ALONG ROUTE (Section 13) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            {/* Signal 1 */}
            <div
              className={`p-4 rounded-2xl border transition-all ${
                activeSignalIndex >= 1
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                  : 'bg-slate-900 border-slate-800 text-slate-500'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-black">🚦 Signal 1 (MG Road)</span>
                <span className="w-3 h-3 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400 animate-ping" />
              </div>
              <p className="text-[11px] font-bold">
                {activeSignalIndex >= 1
                  ? 'GREEN (Ambulance Approaching — Corridored)'
                  : 'RED (Waiting)'}
              </p>
            </div>

            {/* Signal 2 */}
            <div
              className={`p-4 rounded-2xl border transition-all ${
                activeSignalIndex >= 2
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                  : 'bg-slate-900 border-slate-800 text-slate-500'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-black">🚦 Signal 2 (Central Ring)</span>
                <span
                  className={`w-3 h-3 rounded-full ${
                    activeSignalIndex >= 2
                      ? 'bg-emerald-400 shadow-sm shadow-emerald-400'
                      : 'bg-red-500'
                  }`}
                />
              </div>
              <p className="text-[11px] font-bold">
                {activeSignalIndex >= 2
                  ? 'GREEN (Signal Turned Green)'
                  : 'RED (Preempting in 10s)'}
              </p>
            </div>

            {/* Signal 3 */}
            <div
              className={`p-4 rounded-2xl border transition-all ${
                activeSignalIndex >= 3
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                  : 'bg-slate-900 border-slate-800 text-slate-500'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-black">🚦 Signal 3 (Hospital Gate)</span>
                <span
                  className={`w-3 h-3 rounded-full ${
                    activeSignalIndex >= 3
                      ? 'bg-emerald-400 shadow-sm shadow-emerald-400'
                      : 'bg-red-500'
                  }`}
                />
              </div>
              <p className="text-[11px] font-bold">
                {activeSignalIndex >= 3 ? 'GREEN (Gate Clear)' : 'RED (Waiting)'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FIRST AID AUDIO GUIDES (Section 15) */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900">
              {t('firstAidAudioGuides')}
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Listen to step-by-step spoken guidance while help is on the way
            </p>
          </div>
          <span className="text-xs font-bold text-blue-600">🔊 Tap to Listen</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {firstAidGuides.map((aid, idx) => (
            <div
              key={aid.id}
              className="p-5 rounded-2xl border border-slate-200 bg-slate-50 hover:bg-blue-50/50 hover:border-blue-200 transition space-y-3 flex flex-col justify-between shadow-2xs"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-3xl">{aid.emoji}</span>
                  <button
                    onClick={() => {
                      setActiveAidIndex(idx);
                      speak(aid.audioText);
                    }}
                    className="p-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{t('listen')}</span>
                  </button>
                </div>

                <h3 className="text-sm font-black text-slate-900">
                  {language === 'te' ? aid.titleTe : language === 'hi' ? aid.titleHi : aid.title}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {aid.action}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-200/60 text-[11px] text-slate-400">
                Non-diagnostic first aid guidance
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
