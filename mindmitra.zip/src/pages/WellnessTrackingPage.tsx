import React, { useState, useEffect } from 'react';
import {
  Flame,
  Droplets,
  Moon,
  Footprints,
  Plus,
  Minus,
  CheckCircle2,
  Calendar,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { WellnessData } from '../types/index.ts';

export const WellnessTrackingPage: React.FC = () => {
  const [wellness, setWellness] = useState<WellnessData | null>(null);
  const [history, setHistory] = useState<WellnessData[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  // Local editable state
  const [sleepHours, setSleepHours] = useState<number>(0);
  const [sleepQuality, setSleepQuality] = useState<'excellent' | 'good' | 'fair' | 'poor'>('good');
  const [waterIntakeMl, setWaterIntakeMl] = useState<number>(0);
  const [waterTargetMl, setWaterTargetMl] = useState<number>(2000);
  const [stepsCount, setStepsCount] = useState<number>(0);
  const [activityMinutes, setActivityMinutes] = useState<number>(0);

  const loadWellness = async () => {
    try {
      const [todayRes, histRes] = await Promise.all([
        api.getTodayWellness(),
        api.getWellnessHistory(),
      ]);

      if (todayRes.wellness) {
        setWellness(todayRes.wellness);
        setSleepHours(todayRes.wellness.sleepHours);
        setSleepQuality(todayRes.wellness.sleepQuality as any);
        setWaterIntakeMl(todayRes.wellness.waterIntakeMl);
        setWaterTargetMl(todayRes.wellness.waterTargetMl);
        setStepsCount(todayRes.wellness.stepsCount);
        setActivityMinutes(todayRes.wellness.physicalActivityMinutes);
      }
      if (histRes.logs) {
        setHistory(histRes.logs);
      }
    } catch (err) {
      console.error('Failed to load wellness data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadWellness();
  }, []);

  const handleSaveData = async () => {
    try {
      const res = await api.logWellness({
        sleepHours,
        sleepQuality,
        waterIntakeMl,
        waterTargetMl,
        stepsCount,
        physicalActivityMinutes: activityMinutes,
      });
      setWellness(res.wellness);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
      loadWellness();
    } catch (err) {
      console.error('Failed to save wellness data:', err);
    }
  };

  const handleQuickAddWater = async (amount: number) => {
    const updated = Math.max(0, waterIntakeMl + amount);
    setWaterIntakeMl(updated);
    try {
      const res = await api.logWellness({ waterIntakeMl: updated });
      setWellness(res.wellness);
    } catch (err) {
      console.error('Failed to log water:', err);
    }
  };

  const waterPercent = Math.min(100, Math.round((waterIntakeMl / (waterTargetMl || 2500)) * 100));
  const stepsPercent = Math.min(100, Math.round((stepsCount / 10000) * 100));

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-2">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Flame className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                Personal Wellness & Vitality Tracking
              </h1>
              <p className="text-xs sm:text-sm text-slate-500">
                Monitor sleep hygiene, optimal cellular hydration, and daily physical movement.
              </p>
            </div>
          </div>

          <button
            id="save-wellness-btn"
            onClick={handleSaveData}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm rounded-xl transition shadow-xs flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Save Wellness Update</span>
          </button>
        </div>

        {saveSuccess && (
          <div className="mt-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold p-2.5 rounded-xl flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Wellness log updated successfully for today!</span>
          </div>
        )}
      </div>

      {/* Grid of 3 Core Trackers: Hydration, Sleep, Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 1. Hydration Tracker */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs flex flex-col justify-between space-y-5">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Droplets className="w-4 h-4 text-cyan-600" />
                <span>Hydration Tracker</span>
              </h3>
              <span className="text-xs font-extrabold text-cyan-700">{waterPercent}%</span>
            </div>

            <div className="text-center py-3">
              <div className="text-3xl font-black text-slate-900">{waterIntakeMl}</div>
              <div className="text-xs text-slate-500 font-medium mt-0.5">
                Target: {waterTargetMl} ml
              </div>
            </div>

            {/* Visual Tank Progress */}
            <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden p-0.5 border border-slate-200">
              <div
                className="bg-cyan-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${waterPercent}%` }}
              />
            </div>
          </div>

          {/* Quick Add Buttons */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Quick Log:
            </span>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => handleQuickAddWater(150)}
                className="p-2 text-xs font-bold bg-cyan-50 hover:bg-cyan-100 text-cyan-900 rounded-xl border border-cyan-200 transition"
              >
                +150ml (Cup)
              </button>
              <button
                onClick={() => handleQuickAddWater(250)}
                className="p-2 text-xs font-bold bg-cyan-50 hover:bg-cyan-100 text-cyan-900 rounded-xl border border-cyan-200 transition"
              >
                +250ml (Glass)
              </button>
              <button
                onClick={() => handleQuickAddWater(500)}
                className="p-2 text-xs font-bold bg-cyan-50 hover:bg-cyan-100 text-cyan-900 rounded-xl border border-cyan-200 transition"
              >
                +500ml (Bottle)
              </button>
            </div>
          </div>
        </div>

        {/* 2. Sleep Tracker */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Moon className="w-4 h-4 text-indigo-600" />
                <span>Sleep Hygiene & Recovery</span>
              </h3>
              <span className="text-xs font-bold text-indigo-700 capitalize">{sleepQuality}</span>
            </div>

            <div className="text-center py-2">
              <div className="text-3xl font-black text-slate-900">{sleepHours}</div>
              <div className="text-xs text-slate-500 font-medium mt-0.5">Hours Slept</div>
            </div>

            {/* Slider */}
            <div className="space-y-1">
              <input
                type="range"
                min="3"
                max="12"
                step="0.5"
                value={sleepHours}
                onChange={(e) => setSleepHours(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>3h</span>
                <span>Recommended: 7-9 hrs</span>
                <span>12h</span>
              </div>
            </div>

            {/* Quality Pills */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Sleep Quality:
              </span>
              <div className="grid grid-cols-4 gap-1.5">
                {(['excellent', 'good', 'fair', 'poor'] as const).map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setSleepQuality(q)}
                    className={`py-1.5 rounded-lg text-xs font-semibold capitalize border transition ${
                      sleepQuality === q
                        ? 'bg-indigo-700 text-white border-indigo-700 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="p-2.5 bg-indigo-50/60 rounded-xl border border-indigo-100 text-[11px] text-indigo-950">
            Tip: Dim blue-light screens 45 minutes before bedtime to maintain natural melatonin secretion.
          </div>
        </div>

        {/* 3. Physical Activity Tracker */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Footprints className="w-4 h-4 text-emerald-600" />
                <span>Physical Movement</span>
              </h3>
              <span className="text-xs font-bold text-emerald-700">{stepsPercent}% of 10k</span>
            </div>

            <div className="text-center py-2">
              <div className="text-3xl font-black text-slate-900">{stepsCount.toLocaleString()}</div>
              <div className="text-xs text-slate-500 font-medium mt-0.5">Steps Walked</div>
            </div>

            <div className="space-y-2">
              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Daily Steps:</span>
                  <span>{stepsCount} / 10,000</span>
                </div>
                <input
                  type="number"
                  step="250"
                  value={stepsCount}
                  onChange={(e) => setStepsCount(Number(e.target.value))}
                  className="w-full p-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-900"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Active Exercise Minutes:</span>
                  <span>{activityMinutes} mins</span>
                </div>
                <input
                  type="number"
                  min="0"
                  max="300"
                  value={activityMinutes}
                  onChange={(e) => setActivityMinutes(Number(e.target.value))}
                  className="w-full p-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-900"
                />
              </div>
            </div>
          </div>

          <div className="p-2.5 bg-emerald-50/60 rounded-xl border border-emerald-100 text-[11px] text-emerald-950">
            WHO recommends at least 150 minutes of moderate physical activity throughout each week.
          </div>
        </div>
      </div>

      {/* History Log Table */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-600" />
            <span>Past Wellness Trends & History</span>
          </h3>
          <span className="text-xs text-slate-400 font-semibold">{history.length} logged days</span>
        </div>

        {history.length === 0 ? (
          <div className="text-center py-6 text-slate-400 text-xs">
            No past logs found. As you record daily metrics, your weekly trend will display here.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Sleep</th>
                  <th className="py-2.5 px-3">Quality</th>
                  <th className="py-2.5 px-3">Hydration</th>
                  <th className="py-2.5 px-3">Steps</th>
                  <th className="py-2.5 px-3">Active Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {history.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50 transition">
                    <td className="py-2.5 px-3 font-semibold text-slate-900">{row.date}</td>
                    <td className="py-2.5 px-3">{row.sleepHours} hrs</td>
                    <td className="py-2.5 px-3 capitalize">
                      <span className="bg-slate-100 px-2 py-0.5 rounded font-medium">
                        {row.sleepQuality}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-medium text-cyan-700">
                      {row.waterIntakeMl} / {row.waterTargetMl} ml
                    </td>
                    <td className="py-2.5 px-3 font-medium text-emerald-700">
                      {row.stepsCount.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3">{row.physicalActivityMinutes} mins</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
