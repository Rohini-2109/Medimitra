import React, { useState, useEffect } from 'react';
import {
  Radio,
  Siren,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Navigation,
  RefreshCw,
  Building2,
  MapPin,
  Flame,
  Zap,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { AmbulanceDispatch } from '../types/index.ts';
import { NavTab } from '../components/Navbar.tsx';

interface Props {
  onNavigate: (tab: NavTab) => void;
}

export const TrafficControlPage: React.FC<Props> = ({ onNavigate }) => {
  const [activeDispatches, setActiveDispatches] = useState<AmbulanceDispatch[]>([]);
  const [selectedDispatch, setSelectedDispatch] = useState<AmbulanceDispatch | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAcking, setIsAcking] = useState<boolean>(false);
  const [ackNotice, setAckNotice] = useState<string | null>(null);

  const fetchTrafficData = async () => {
    try {
      const res = await api.getActiveAmbulances();
      setActiveDispatches(res.dispatches || []);
      if (res.dispatches && res.dispatches.length > 0) {
        setSelectedDispatch(res.dispatches[0]);
      } else {
        setSelectedDispatch(null);
      }
    } catch (err) {
      console.error('Failed to load active traffic data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTrafficData();
    const interval = setInterval(fetchTrafficData, 6000);
    return () => clearInterval(interval);
  }, []);

  const handleAcknowledgeAlert = async () => {
    if (!selectedDispatch) return;
    setIsAcking(true);
    try {
      const res = await api.ackAmbulanceAlert(selectedDispatch.id);
      setSelectedDispatch(res.dispatch);
      setAckNotice('Green corridor activated! Signals along route preempted for emergency vehicle.');
      setTimeout(() => setAckNotice(null), 5000);
      fetchTrafficData();
    } catch (err: any) {
      alert(err.message || 'Failed to acknowledge alert');
    } finally {
      setIsAcking(false);
    }
  };

  const handleStepSimulation = async () => {
    if (!selectedDispatch) return;
    try {
      const res = await api.stepAmbulanceSimulation(selectedDispatch.id);
      setSelectedDispatch(res.dispatch);
      fetchTrafficData();
    } catch (err) {
      console.error('Failed to step simulation:', err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Command Center Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black shadow-md">
              <Radio className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
                  Traffic Control Command Dashboard
                </h1>
                <span className="text-[10px] uppercase font-black bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full">
                  Simulator
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Automated signal preemption & green corridor management prototype
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchTrafficData}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition border border-slate-700"
              title="Refresh Telemetry"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Sync</span>
            </button>

            <button
              id="traffic-to-sos-btn"
              onClick={() => onNavigate('ambulance')}
              className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
            >
              <Siren className="w-4 h-4" />
              <span>Ambulance Dispatch View</span>
            </button>
          </div>
        </div>

        {/* Prototype Safety Notice */}
        <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-2xl text-xs text-slate-300 flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
          <p>
            <strong>Architectural Simulation Mode:</strong> This dashboard visualizes how municipal intelligent transportation systems (ITS) can ingest automated ambulance telemetry and engage adaptive green light corridors. No live municipal signals or real authorities are connected.
          </p>
        </div>
      </div>

      {!selectedDispatch ? (
        <div className="bg-white rounded-3xl p-12 border border-slate-200 text-center space-y-4 shadow-2xs">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <Radio className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-800">
            No Emergency Ambulances Currently Active in Transit
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Dispatch a simulated emergency ambulance from the Ambulance SOS module to test junction alerts and signal preemption in this dashboard.
          </p>
          <button
            id="launch-test-dispatch-btn"
            onClick={() => onNavigate('ambulance')}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition shadow-xs inline-flex items-center gap-2"
          >
            <Siren className="w-4 h-4" />
            <span>Go to Ambulance SOS & Dispatch</span>
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Priority Emergency Broadcast Box */}
          <div className="bg-gradient-to-r from-rose-950 via-slate-950 to-slate-900 rounded-3xl p-6 border-2 border-rose-600 text-white shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-rose-400">
                <span className="flex h-3 w-3 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-600" />
                </span>
                <span className="font-mono text-xs font-black uppercase tracking-wider">
                  PRIORITY 1 EMERGENCY DISPATCH NOTIFICATION
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs bg-rose-900/80 text-rose-200 border border-rose-700 px-3 py-1 rounded-full font-bold">
                  AMBULANCE ID: {selectedDispatch.id.toUpperCase()}
                </span>
                <span className="text-xs bg-emerald-950 text-emerald-300 border border-emerald-700 px-3 py-1 rounded-full font-bold">
                  ETA: {selectedDispatch.etaMinutes} MINS
                </span>
              </div>
            </div>

            {/* Broadcast Message Container */}
            <div className="bg-black/60 border border-rose-900/50 p-4 rounded-2xl">
              <div className="text-[10px] font-mono text-rose-400 uppercase tracking-wider mb-1">
                Active Traffic Alert Feed:
              </div>
              <p className="font-mono text-sm sm:text-base font-extrabold text-emerald-400 leading-relaxed">
                "{selectedDispatch.alertMessage}"
              </p>
            </div>

            {/* Alert Acknowledgement Action */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
              <div className="text-xs text-slate-300">
                {selectedDispatch.alertAcknowledgedByControl ? (
                  <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Alert Acknowledged by Control at {selectedDispatch.acknowledgedAt || 'Recently'}
                  </span>
                ) : (
                  <span className="text-amber-400 font-semibold flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    Action Required: Acknowledge alert to preempt traffic lights.
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  id="traffic-step-btn"
                  onClick={handleStepSimulation}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition"
                >
                  Step Next Junction
                </button>

                <button
                  id="ack-traffic-alert-btn"
                  onClick={handleAcknowledgeAlert}
                  disabled={isAcking || selectedDispatch.alertAcknowledgedByControl}
                  className={`flex-1 sm:flex-none px-6 py-2.5 rounded-xl font-extrabold text-xs transition shadow-md flex items-center justify-center gap-2 ${
                    selectedDispatch.alertAcknowledgedByControl
                      ? 'bg-emerald-600 text-white cursor-default'
                      : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 hover:text-white'
                  }`}
                >
                  <Zap className="w-4 h-4" />
                  <span>
                    {selectedDispatch.alertAcknowledgedByControl
                      ? 'GREEN CORRIDOR ENGAGED'
                      : 'ACKNOWLEDGE & ENGAGE GREEN CORRIDOR'}
                  </span>
                </button>
              </div>
            </div>

            {ackNotice && (
              <div className="bg-emerald-950 text-emerald-200 text-xs font-semibold p-2.5 rounded-xl border border-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{ackNotice}</span>
              </div>
            )}
          </div>

          {/* Telemetry & Junction Management Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left 2 Cols: Junction Signal Management */}
            <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                  <Navigation className="w-4 h-4 text-blue-600" />
                  <span>Junction Signal Preemption Matrix</span>
                </h3>
                <span className="text-xs text-slate-500 font-semibold">
                  Total Junctions: {selectedDispatch.junctions.length}
                </span>
              </div>

              <div className="space-y-3">
                {selectedDispatch.junctions.map((junc, idx) => {
                  const isCurrent = idx === selectedDispatch.currentJunctionIndex;
                  const isCleared = idx < selectedDispatch.currentJunctionIndex || junc.status === 'cleared';

                  return (
                    <div
                      key={junc.id}
                      className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition ${
                        isCurrent
                          ? 'bg-rose-50/70 border-rose-300'
                          : isCleared
                          ? 'bg-emerald-50/50 border-emerald-200'
                          : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center font-mono font-bold text-xs">
                            {idx + 1}
                          </span>
                          <span className="font-extrabold text-sm text-slate-900">
                            {junc.name}
                          </span>
                          <span className="text-xs text-slate-500 font-medium">
                            ({junc.distanceMeters}m)
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 pl-8">
                          {isCurrent
                            ? 'Vehicle approaching. Cross-traffic holds red.'
                            : isCleared
                            ? 'Cleared safely. Normal cycle restored.'
                            : 'In queue for automated signal clearing.'}
                        </p>
                      </div>

                      {/* Traffic Light Visual Indicator */}
                      <div className="flex items-center gap-3 self-end sm:self-auto">
                        <div className="flex items-center gap-1.5 bg-slate-900 p-2 rounded-xl border border-slate-700">
                          <div
                            className={`w-3.5 h-3.5 rounded-full ${
                              junc.trafficLevel === 'red' && !selectedDispatch.greenCorridorActive
                                ? 'bg-red-500 shadow-md shadow-red-500/50'
                                : 'bg-red-950 opacity-40'
                            }`}
                            title="Red Signal"
                          />
                          <div
                            className={`w-3.5 h-3.5 rounded-full ${
                              junc.trafficLevel === 'yellow' && !selectedDispatch.greenCorridorActive
                                ? 'bg-yellow-400 shadow-md shadow-yellow-400/50'
                                : 'bg-yellow-950 opacity-40'
                            }`}
                            title="Yellow Signal"
                          />
                          <div
                            className={`w-3.5 h-3.5 rounded-full ${
                              selectedDispatch.greenCorridorActive || junc.trafficLevel === 'green'
                                ? 'bg-emerald-400 shadow-md shadow-emerald-400/50'
                                : 'bg-emerald-950 opacity-40'
                            }`}
                            title="Green Signal"
                          />
                        </div>

                        <span
                          className={`text-xs font-bold px-2.5 py-1 rounded-xl uppercase ${
                            selectedDispatch.greenCorridorActive
                              ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                              : isCurrent
                              ? 'bg-rose-100 text-rose-900 border border-rose-300'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {selectedDispatch.greenCorridorActive ? 'GREEN CORRIDOR' : junc.status}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right 1 Col: Vehicle & Hospital Specifications */}
            <div className="space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
                <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-blue-600" />
                  <span>Destination Trauma Facility</span>
                </h4>

                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-slate-400 font-medium block">Hospital Name:</span>
                    <strong className="text-slate-900 text-sm block">
                      {selectedDispatch.destinationHospital.name}
                    </strong>
                  </div>

                  <div>
                    <span className="text-slate-400 font-medium block">Address:</span>
                    <span className="text-slate-700">
                      {selectedDispatch.destinationHospital.address}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 font-medium block">Trauma Desk Direct:</span>
                    <a
                      href={`tel:${selectedDispatch.destinationHospital.phone}`}
                      className="font-bold text-blue-600 hover:underline"
                    >
                      {selectedDispatch.destinationHospital.phone}
                    </a>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-3">
                <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>Telemetry Coordinates</span>
                </h4>

                <div className="space-y-1.5 text-xs text-slate-600 font-mono">
                  <div className="flex justify-between bg-slate-50 p-2 rounded-lg">
                    <span>Ambulance Lat:</span>
                    <span className="font-bold text-slate-900">{selectedDispatch.currentLocation.lat.toFixed(5)}</span>
                  </div>
                  <div className="flex justify-between bg-slate-50 p-2 rounded-lg">
                    <span>Ambulance Long:</span>
                    <span className="font-bold text-slate-900">{selectedDispatch.currentLocation.lng.toFixed(5)}</span>
                  </div>
                  <div className="flex justify-between bg-slate-50 p-2 rounded-lg">
                    <span>Corridor Status:</span>
                    <span className="font-bold text-emerald-600">
                      {selectedDispatch.greenCorridorActive ? 'ENGAGED' : 'STANDBY'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
