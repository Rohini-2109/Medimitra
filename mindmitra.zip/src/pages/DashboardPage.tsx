import React, { useState, useEffect } from 'react';
import {
  Activity,
  Heart,
  Droplets,
  Moon,
  Footprints,
  Pill,
  Smile,
  AlertCircle,
  Siren,
  ChevronRight,
  Plus,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Bot,
  Stethoscope,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { NavTab } from '../components/Navbar.tsx';
import { MoodEntry, PrescribedMedicine, WellnessData } from '../types/index.ts';

interface Props {
  onNavigate: (tab: NavTab) => void;
}

export const DashboardPage: React.FC<Props> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [wellness, setWellness] = useState<WellnessData | null>(null);
  const [medicines, setMedicines] = useState<PrescribedMedicine[]>([]);
  const [recentMood, setRecentMood] = useState<MoodEntry | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [waterAdding, setWaterAdding] = useState<boolean>(false);

  const loadDashboardData = async () => {
    try {
      const [wellRes, medRes, moodRes] = await Promise.all([
        api.getTodayWellness().catch(() => ({ wellness: null })),
        api.getMedicines().catch(() => ({ medicines: [] })),
        api.getMoodHistory().catch(() => ({ logs: [] })),
      ]);

      if (wellRes.wellness) setWellness(wellRes.wellness);
      if (medRes.medicines) setMedicines(medRes.medicines);
      if (moodRes.logs && moodRes.logs.length > 0) setRecentMood(moodRes.logs[0]);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, [user]);

  const handleQuickAddWater = async (amount: number) => {
    if (!wellness) return;
    setWaterAdding(true);
    const newIntake = (wellness.waterIntakeMl || 0) + amount;
    try {
      const res = await api.logWellness({ waterIntakeMl: newIntake });
      setWellness(res.wellness);
    } catch (err) {
      console.error('Failed to log water:', err);
    } finally {
      setWaterAdding(false);
    }
  };

  const handleMarkDoseTaken = async (medId: string, slot: string) => {
    try {
      await api.markDose(medId, slot, 'taken');
      loadDashboardData();
    } catch (err) {
      console.error('Failed to mark dose taken:', err);
    }
  };

  // Calculate medication adherence percentage
  const totalPrescriptions = medicines.length;
  let totalDosesLogged = 0;
  let takenDosesCount = 0;
  medicines.forEach((m) => {
    m.history.forEach((h) => {
      totalDosesLogged++;
      if (h.status === 'taken') takenDosesCount++;
    });
  });
  const adherenceRate = totalDosesLogged > 0 ? Math.round((takenDosesCount / totalDosesLogged) * 100) : 0;

  const waterPercent = wellness && wellness.waterTargetMl
    ? Math.min(100, Math.round((wellness.waterIntakeMl / wellness.waterTargetMl) * 100))
    : 0;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Top Welcome & Quick SOS Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white rounded-3xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-64 h-64 bg-white/5 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-blue-950/60 backdrop-blur-xs text-blue-200 border border-blue-600/50 px-3 py-1 rounded-full text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-300" />
              <span>Personal Health & Wellness System</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome, {user?.name || 'Friend'}
            </h1>
            <p className="text-sm text-blue-100 max-w-xl">
              {user?.age ? `${user.age} yrs old` : 'Profile active'}
              {user?.bloodGroup ? ` • Blood Group: ${user.bloodGroup}` : ''}
              {user?.allergies && user.allergies.length > 0
                ? ` • Allergies: ${user.allergies.join(', ')}`
                : ''}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              id="dash-ai-assistant-btn"
              onClick={() => onNavigate('assistant')}
              className="flex items-center gap-2 bg-white text-blue-900 hover:bg-blue-50 font-bold px-4 py-2.5 rounded-xl text-xs sm:text-sm transition shadow-sm"
            >
              <Bot className="w-4 h-4 text-blue-700" />
              <span>Consult AI Assistant</span>
            </button>

            <button
              id="dash-emergency-sos-btn"
              onClick={() => onNavigate('ambulance')}
              className="flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs sm:text-sm transition shadow-sm animate-pulse"
            >
              <Siren className="w-4 h-4" />
              <span>Emergency Ambulance SOS</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid (Mood, Sleep, Water, Activity, Medication) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* 1. Mood Tracker */}
        <div
          onClick={() => onNavigate('mental')}
          className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs hover:shadow-md transition cursor-pointer flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Mental State
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Smile className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-extrabold text-slate-900 capitalize">
                {recentMood ? recentMood.mood : 'Not logged'}
              </span>
              {recentMood ? (
                <span className="text-xs text-slate-500">
                  Stress: {recentMood.stressLevel}/10
                </span>
              ) : null}
            </div>
            <p className="text-xs text-slate-500 mt-1 line-clamp-1">
              {recentMood ? (recentMood.journalNote || 'Mindset logged') : 'Tap to check-in mood'}
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-700 group-hover:text-blue-900">
            <span>Check-in & Breathing</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition" />
          </div>
        </div>

        {/* 2. Sleep Tracker */}
        <div
          onClick={() => onNavigate('wellness')}
          className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs hover:shadow-md transition cursor-pointer flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Sleep Duration
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Moon className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-extrabold text-slate-900">
                {wellness ? wellness.sleepHours : 0}
              </span>
              <span className="text-xs text-slate-500 font-semibold">hours</span>
            </div>
            <span className="inline-block mt-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 capitalize">
              {wellness ? `Quality: ${wellness.sleepQuality}` : 'Not logged today'}
            </span>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-700 group-hover:text-blue-900">
            <span>Wellness log</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition" />
          </div>
        </div>

        {/* 3. Water Intake Tracker */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs hover:shadow-md transition flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Hydration
            </span>
            <div className="w-8 h-8 rounded-lg bg-cyan-50 text-cyan-600 flex items-center justify-center">
              <Droplets className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-extrabold text-slate-900">
                {wellness ? wellness.waterIntakeMl : 0}
              </span>
              <span className="text-xs text-slate-500 font-semibold">
                / {wellness ? wellness.waterTargetMl : 2000} ml
              </span>
            </div>
            {/* Progress Bar */}
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-2">
              <div
                className="bg-cyan-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${waterPercent}%` }}
              />
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">{waterPercent}% Target</span>
            <button
              id="quick-water-250-btn"
              disabled={waterAdding}
              onClick={(e) => {
                e.stopPropagation();
                handleQuickAddWater(250);
              }}
              className="text-[11px] font-bold bg-cyan-50 hover:bg-cyan-100 text-cyan-800 px-2 py-1 rounded-md transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3" /> +250ml
            </button>
          </div>
        </div>

        {/* 4. Physical Activity */}
        <div
          onClick={() => onNavigate('wellness')}
          className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs hover:shadow-md transition cursor-pointer flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Activity
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Footprints className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-extrabold text-slate-900">
                {wellness && wellness.stepsCount ? wellness.stepsCount.toLocaleString() : '0'}
              </span>
              <span className="text-xs text-slate-500 font-semibold">steps</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Active: {wellness ? wellness.physicalActivityMinutes : 0} minutes today
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-700 group-hover:text-blue-900">
            <span>Activity history</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition" />
          </div>
        </div>

        {/* 5. Medication Adherence */}
        <div
          onClick={() => onNavigate('prescriptions')}
          className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs hover:shadow-md transition cursor-pointer flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Adherence
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
              <Pill className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-extrabold text-slate-900">
                {totalDosesLogged > 0 ? `${adherenceRate}%` : '0%'}
              </span>
              <span className={`text-xs font-bold ${totalDosesLogged > 0 ? 'text-emerald-600' : 'text-slate-400'}`}>
                {totalDosesLogged > 0 ? 'On track' : 'No logs'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {totalPrescriptions} Doctor Prescriptions
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-700 group-hover:text-blue-900">
            <span>Prescription box</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition" />
          </div>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Today's Medication Schedule & Quick Triage */}
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Prescribed Medicine Schedule */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                  <Pill className="w-4 h-4 text-blue-600" />
                  Prescribed Medicine Reminders
                </h3>
                <p className="text-xs text-slate-500">
                  Strictly prescribed by qualified physicians. MediMitra does not independently prescribe medicines.
                </p>
              </div>
              <button
                id="view-all-prescriptions-btn"
                onClick={() => onNavigate('prescriptions')}
                className="text-xs font-bold text-blue-600 hover:text-blue-700 hover:underline"
              >
                Manage All
              </button>
            </div>

            {medicines.length === 0 ? (
              <div className="text-center py-6 text-slate-500 text-xs">
                No active prescriptions logged. You can add doctor-prescribed medicines in the Prescriptions module.
              </div>
            ) : (
              <div className="space-y-3">
                {medicines.map((med) => (
                  <div
                    key={med.id}
                    className="p-3.5 rounded-2xl bg-slate-50/80 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-100/60 transition"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">
                          {med.medicineName}
                        </span>
                        <span className="text-xs bg-white border border-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-medium">
                          {med.dosage}
                        </span>
                        <span className="text-[11px] bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full font-semibold">
                          {med.instruction}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">
                        Prescribed by <span className="font-medium text-slate-700">{med.doctorName}</span> • Duration: {med.durationDays} days
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {med.timing.map((slot) => {
                        const todayStr = new Date().toISOString().split('T')[0];
                        const isTaken = med.history.some(
                          (h) => h.date === todayStr && h.timingSlot === slot && h.status === 'taken'
                        );
                        return (
                          <button
                            key={slot}
                            onClick={() => handleMarkDoseTaken(med.id, slot)}
                            className={`text-xs px-2.5 py-1.5 rounded-xl font-bold flex items-center gap-1 transition ${
                              isTaken
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                : 'bg-white hover:bg-blue-50 text-slate-700 border border-slate-300'
                            }`}
                          >
                            {isTaken ? (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                <span>{slot}: Taken</span>
                              </>
                            ) : (
                              <span>Take {slot}</span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Symptom & Health Check Section */}
          <div className="bg-gradient-to-br from-sky-50/70 via-blue-50/50 to-white rounded-3xl p-6 border border-blue-100 shadow-2xs space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] uppercase tracking-wider font-bold text-blue-800">
                  Triage & Educational Guidance
                </span>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mt-0.5">
                  <Stethoscope className="w-5 h-5 text-blue-600" />
                  Feeling Unwell? Check Symptoms Without Guesswork
                </h3>
                <p className="text-xs text-slate-600 mt-1 max-w-xl">
                  Describe symptoms via voice or text. MediMitra organizes them into clinical categories and advises if medical attention is appropriate without diagnosing diseases.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                id="dash-start-symptom-check-btn"
                onClick={() => onNavigate('symptoms')}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm rounded-xl transition shadow-xs flex items-center gap-2"
              >
                <Stethoscope className="w-4 h-4" />
                <span>Launch Symptom Checker</span>
              </button>

              <button
                id="dash-find-doctors-btn"
                onClick={() => onNavigate('doctors')}
                className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 font-semibold text-xs sm:text-sm rounded-xl transition"
              >
                <span>Find Nearby Doctors & Clinics</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Emergency SOS Quick Card & Mental Snapshot */}
        <div className="space-y-6">
          {/* Smart Ambulance Emergency Card */}
          <div className="bg-rose-50 border border-rose-200 rounded-3xl p-6 space-y-4 shadow-2xs">
            <div className="flex items-center gap-2 text-rose-800">
              <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center">
                <Siren className="w-4 h-4 animate-bounce" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-rose-950 leading-tight">
                  Emergency Ambulance Simulation
                </h4>
                <p className="text-[10px] text-rose-700 font-semibold">
                  Smart Traffic Coordination Prototype
                </p>
              </div>
            </div>

            <p className="text-xs text-rose-900/90 leading-relaxed">
              When dispatched, MediMitra simulates real-time ambulance routing, junction traffic preemption, and alerts an authorized Traffic Control Dashboard to facilitate emergency clearance.
            </p>

            <div className="space-y-2 pt-1">
              <button
                id="dash-ambulance-dispatch-btn"
                onClick={() => onNavigate('ambulance')}
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition shadow-xs flex items-center justify-center gap-2"
              >
                <Siren className="w-4 h-4" />
                <span>Open Ambulance Dispatcher</span>
              </button>

              <button
                id="dash-traffic-control-btn"
                onClick={() => onNavigate('traffic')}
                className="w-full py-2 bg-white hover:bg-rose-100 text-rose-900 border border-rose-300 font-semibold text-xs rounded-xl transition flex items-center justify-center gap-1.5"
              >
                <span>Open Traffic Control Dashboard</span>
                <span className="text-[9px] bg-rose-200 text-rose-900 px-1 py-0.5 rounded font-bold uppercase">
                  Simulator
                </span>
              </button>
            </div>
          </div>

          {/* Mental Well-being Quick Check-in Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/90 space-y-4 shadow-2xs">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                <Smile className="w-4 h-4 text-amber-500" />
                <span>Daily Well-being Check</span>
              </h4>
              <button
                onClick={() => onNavigate('mental')}
                className="text-xs text-blue-600 font-bold hover:underline"
              >
                Open Guide
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              How are you feeling right now? Taking 30 seconds to reflect and regulate your breathing helps reduce stress hormones.
            </p>

            <div className="grid grid-cols-5 gap-1.5">
              {[
                { emoji: '😄', label: 'Great', val: 'great' },
                { emoji: '🙂', label: 'Good', val: 'good' },
                { emoji: '😐', label: 'Neutral', val: 'neutral' },
                { emoji: '😰', label: 'Anxious', val: 'anxious' },
                { emoji: '😔', label: 'Low', val: 'sad' },
              ].map((m) => (
                <button
                  key={m.val}
                  onClick={() => onNavigate('mental')}
                  className="flex flex-col items-center p-2 rounded-xl border border-slate-100 hover:border-blue-300 hover:bg-blue-50 transition text-center"
                >
                  <span className="text-xl">{m.emoji}</span>
                  <span className="text-[10px] font-semibold text-slate-600 mt-1">{m.label}</span>
                </button>
              ))}
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-600 font-medium">Box Breathing Exercise</span>
              <button
                onClick={() => onNavigate('mental')}
                className="font-bold text-blue-800 hover:underline flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Start 4-4-4-4 Pacing</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
