import React, { useState } from 'react';
import {
  Stethoscope,
  Mic,
  Volume2,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  ArrowRight,
  RotateCcw,
  Sparkles,
  PhoneCall,
  MapPin,
  HeartPulse,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { SymptomAnalysisResult } from '../types/index.ts';
import { useSettings } from '../context/SettingsContext.tsx';
import { NavTab } from '../components/Navbar.tsx';
import { VoiceInputModal } from '../components/VoiceInputModal.tsx';

interface Props {
  onNavigate: (tab: NavTab) => void;
}

export const SymptomCheckerPage: React.FC<Props> = ({ onNavigate }) => {
  const { language, t, speak } = useSettings();
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [duration, setDuration] = useState<string>('1-3 days');
  const [customText, setCustomText] = useState<string>('');
  const [isVoiceOpen, setIsVoiceOpen] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<SymptomAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Large Visual Symptom Buttons (User Request Section 8)
  const symptomButtons = [
    { id: 'headache', emoji: '🤕', name: t('headache'), textEn: 'Headache' },
    { id: 'fever', emoji: '🌡️', name: t('fever'), textEn: 'Fever' },
    { id: 'cough', emoji: '🤧', name: t('cough'), textEn: 'Cough' },
    { id: 'stomach', emoji: '🤢', name: t('stomachProblem'), textEn: 'Stomach problem' },
    { id: 'breathing', emoji: '🫁', name: t('breathingProblem'), textEn: 'Breathing problem' },
    { id: 'pain', emoji: '😣', name: t('bodyPain'), textEn: 'Body Pain' },
  ];

  const durationOptions = [
    { label: language === 'te' ? 'ఈ రోజే మొదలైంది' : language === 'hi' ? 'आज ही शुरू हुआ' : 'Today (few hours ago)', value: 'Today' },
    { label: language === 'te' ? '1-3 రోజులు' : language === 'hi' ? '1-3 दिन' : '1-3 days', value: '1-3 days' },
    { label: language === 'te' ? 'సుమారు 1 వారం' : language === 'hi' ? 'लगभग 1 हफ्ता' : '4-7 days', value: '1 week' },
    { label: language === 'te' ? '2 వారాలకు పైగా' : language === 'hi' ? '2 हफ्ते से अधिक' : 'More than 2 weeks', value: 'Over 2 weeks' },
  ];

  const toggleSymptom = (textEn: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(textEn) ? prev.filter((s) => s !== textEn) : [...prev, textEn]
    );
  };

  const handleVoiceCaptured = (transcript: string) => {
    setCustomText((prev) => (prev ? prev + ', ' + transcript : transcript));
    setSelectedSymptoms((prev) => (prev.includes(transcript) ? prev : [...prev, transcript]));
  };

  const handleAnalyze = async () => {
    const combined = [
      ...selectedSymptoms,
      ...(customText.trim() ? [customText.trim()] : []),
    ].join(', ');

    if (!combined.trim()) {
      setError(
        language === 'te'
          ? 'దయచేసి పైన ఉన్న బటన్లపై నొక్కండి లేదా మీ లక్షణాలను చెప్పండి.'
          : language === 'hi'
          ? 'कृपया ऊपर दिए गए बटनों पर टैप करें या बोलकर बताएं।'
          : 'Please tap one or more symptoms above or speak your symptoms.'
      );
      return;
    }

    setError(null);
    setIsLoading(true);

    try {
      const data = await api.checkSymptoms(combined, duration, language);
      setResult(data);

      // Voice readout of recommended next steps
      const voiceSummary =
        language === 'te'
          ? `లక్షణాల సమీక్ష పూర్తయింది. తదుపరి సిఫార్సు: ${data.urgencyLevel}. విశ్రాంతి తీసుకోండి మరియు అవసరమైతే డాక్టర్ను సంప్రదించండి.`
          : language === 'hi'
          ? `लक्षणों की समीक्षा पूरी हो गई है। अनुशंसित अगला कदम: ${data.urgencyLevel}। डॉक्टर से परामर्श लें।`
          : `Symptom review complete. Next Step: ${data.urgencyLevel}. Please review self-care and consult a physician if symptoms persist.`;
      speak(voiceSummary);
    } catch {
      setError(
        language === 'te'
          ? 'లక్షణాలను విశ్లేషించడంలో సమస్య ఏర్పడింది. దయచేసి మళ్ళీ ప్రయత్నించండి.'
          : language === 'hi'
          ? 'लक्षणों का विश्लेषण करने में असमर्थ। कृपया पुनः प्रयास करें।'
          : 'Unable to organize symptoms at this moment. Please try again.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setSelectedSymptoms([]);
    setCustomText('');
    setResult(null);
    setError(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16 animate-in fade-in duration-300">
      {/* 1. Header with Plain Language Guidance */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200/90 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
              <Stethoscope className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {t('symptomCheckerTitle')}
              </h1>
              <p className="text-xs sm:text-sm font-semibold text-slate-500">
                {t('symptomCheckerSub')}
              </p>
            </div>
          </div>

          {(selectedSymptoms.length > 0 || result) && (
            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition border border-slate-200"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>

        {/* Clinical Boundary Strip */}
        <div className="bg-blue-50 border border-blue-200/80 rounded-2xl p-3 text-xs text-blue-950 flex items-start gap-2.5">
          <ShieldAlert className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Safety Protocol:</strong> MediMitra organizes your symptoms into clear next steps. It does <strong>not</strong> produce a medical diagnosis.
          </p>
        </div>
      </div>

      {/* 2. LARGE VISUAL BUTTONS (Section 8) */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200/90 shadow-2xs space-y-4">
        <h2 className="text-sm sm:text-base font-extrabold text-slate-800 uppercase tracking-wider">
          {t('tapSymptomsBelow')}
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          {symptomButtons.map((sym) => {
            const isSelected = selectedSymptoms.includes(sym.textEn);
            return (
              <button
                key={sym.id}
                id={`sym-btn-${sym.id}`}
                onClick={() => toggleSymptom(sym.textEn)}
                className={`p-4 sm:p-5 rounded-2xl border-2 transition-all duration-200 flex flex-col items-center justify-center gap-2 text-center active:scale-95 shadow-2xs ${
                  isSelected
                    ? 'bg-blue-600 text-white border-blue-600 shadow-md ring-4 ring-blue-100'
                    : 'bg-slate-50 hover:bg-blue-50 text-slate-800 border-slate-200 hover:border-blue-300'
                }`}
              >
                <span className="text-3xl sm:text-4xl">{sym.emoji}</span>
                <span className="text-sm font-black leading-tight">
                  {sym.name}
                </span>
                {isSelected && (
                  <CheckCircle2 className="w-4 h-4 text-white animate-bounce" />
                )}
              </button>
            );
          })}

          {/* 🎤 Tell us by voice button */}
          <button
            id="sym-tell-by-voice-btn"
            onClick={() => setIsVoiceOpen(true)}
            className="p-4 sm:p-5 rounded-2xl border-2 border-dashed border-blue-400 bg-blue-50/70 hover:bg-blue-100 text-blue-800 transition flex flex-col items-center justify-center gap-2 text-center active:scale-95"
          >
            <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Mic className="w-5 h-5" />
            </div>
            <span className="text-sm font-black leading-tight">
              {t('tellByVoice')}
            </span>
          </button>

          {/* ➕ Other symptom toggle */}
          <button
            id="sym-other-btn"
            onClick={() => {
              const inputVal = prompt('Please enter any other symptom:');
              if (inputVal && inputVal.trim()) {
                handleVoiceCaptured(inputVal.trim());
              }
            }}
            className="p-4 sm:p-5 rounded-2xl border-2 border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 transition flex flex-col items-center justify-center gap-2 text-center active:scale-95"
          >
            <span className="text-3xl">➕</span>
            <span className="text-sm font-bold leading-tight">
              {t('otherProblem')}
            </span>
          </button>
        </div>

        {/* Selected Symptoms Summary Chips */}
        {selectedSymptoms.length > 0 && (
          <div className="pt-3 border-t border-slate-100 flex items-center flex-wrap gap-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Selected:
            </span>
            {selectedSymptoms.map((item, i) => (
              <span
                key={i}
                className="px-3 py-1 bg-blue-100 text-blue-900 rounded-full text-xs font-bold flex items-center gap-1.5"
              >
                <span>{item}</span>
                <button
                  onClick={() => toggleSymptom(item)}
                  className="hover:text-red-600"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        )}

        {/* Duration Selector */}
        <div className="space-y-2 pt-2">
          <label className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
            How long have you had this?
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {durationOptions.map((opt, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setDuration(opt.value)}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition border ${
                  duration === opt.value
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs font-bold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Big Action Button */}
        <button
          id="analyze-symptoms-action-btn"
          onClick={handleAnalyze}
          disabled={isLoading}
          className="w-full py-4 px-6 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 text-white text-base font-black rounded-2xl shadow-md transition flex items-center justify-center gap-2"
        >
          <Sparkles className="w-5 h-5" />
          <span>{isLoading ? 'Organizing with AI...' : 'Review Symptoms & Get Next Steps'}</span>
        </button>
      </div>

      {/* 3. THREE-STAGE FLOW RESULT: SYMPTOMS → AI ORGANIZATION → NEXT STEP */}
      {result && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-blue-500 shadow-xl space-y-6 animate-in slide-in-from-bottom-3 duration-300">
          {/* Step Banner */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2 text-xs font-bold text-blue-700 uppercase tracking-wider">
              <span>SYMPTOMS</span>
              <span>→</span>
              <span>AI ORGANIZATION</span>
              <span>→</span>
              <span className="bg-blue-600 text-white px-2 py-0.5 rounded-md">NEXT STEP</span>
            </div>

            <button
              onClick={() => {
                const textToRead = `${result.urgencyLevel}. ${result.generalGuidance.join('. ')}`;
                speak(textToRead);
              }}
              className="flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-800 bg-blue-50 px-3 py-1.5 rounded-xl transition"
            >
              <Volume2 className="w-4 h-4" />
              <span>{t('listen')}</span>
            </button>
          </div>

          {/* Urgency / Next Step Hero Card */}
          <div
            className={`p-5 sm:p-6 rounded-3xl border-2 space-y-3 ${
              result.urgencyLevel.includes('Emergency') || result.urgencyLevel.includes('Immediate')
                ? 'bg-red-50 border-red-300 text-red-950'
                : result.urgencyLevel.includes('Doctor')
                ? 'bg-amber-50 border-amber-300 text-amber-950'
                : 'bg-emerald-50 border-emerald-300 text-emerald-950'
            }`}
          >
            <div className="flex items-center gap-3">
              <div
                className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-xl shrink-0 ${
                  result.urgencyLevel.includes('Emergency')
                    ? 'bg-red-600'
                    : result.urgencyLevel.includes('Doctor')
                    ? 'bg-amber-600'
                    : 'bg-emerald-600'
                }`}
              >
                {result.urgencyLevel.includes('Emergency') ? '🚨' : result.urgencyLevel.includes('Doctor') ? '🩺' : '✓'}
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider block opacity-75">
                  {t('symptomNextStep')}
                </span>
                <h3 className="text-xl sm:text-2xl font-black">
                  {result.urgencyLevel}
                </h3>
              </div>
            </div>

            {/* Quick Action Buttons according to urgency */}
            <div className="pt-2 flex flex-wrap gap-2.5">
              {result.urgencyLevel.includes('Emergency') ? (
                <button
                  onClick={() => onNavigate('emergency')}
                  className="py-3 px-5 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-xs font-black flex items-center gap-2 shadow-md"
                >
                  <span>Launch Emergency SOS & Ambulance</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={() => onNavigate('doctors')}
                  className="py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl text-xs font-bold flex items-center gap-2 shadow-xs"
                >
                  <MapPin className="w-4 h-4" />
                  <span>Find Nearby Doctors & Clinics</span>
                </button>
              )}
            </div>
          </div>

          {/* General Self-Care & Supportive Information */}
          {result.generalGuidance.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">
                Supportive Self-Care Steps:
              </h4>
              <ul className="space-y-2">
                {result.generalGuidance.map((guide, idx) => (
                  <li
                    key={idx}
                    className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-700 flex items-start gap-2.5"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                    <span>{guide}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Questions to ask a Doctor */}
          {result.potentialQuestionsForDoctor.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <h4 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider">
                Helpful questions to ask your Doctor:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {result.potentialQuestionsForDoctor.map((q, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-blue-900 font-medium"
                  >
                    "{q}"
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Voice Dictation Modal */}
      <VoiceInputModal
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
        onTranscriptCaptured={handleVoiceCaptured}
      />
    </div>
  );
};
