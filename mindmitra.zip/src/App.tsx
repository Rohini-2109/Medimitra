import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { SettingsProvider, useSettings } from './context/SettingsContext.tsx';
import { EmergencyBanner } from './components/EmergencyBanner.tsx';
import { Navbar, NavTab } from './components/Navbar.tsx';
import { VoiceAssistantModal } from './components/VoiceAssistantModal.tsx';
import { MedicineReminderModal } from './components/MedicineReminderModal.tsx';
import { MedicalDisclaimerModal } from './components/MedicalDisclaimerModal.tsx';

import { AuthPage } from './pages/AuthPage.tsx';
import { HomePage } from './pages/HomePage.tsx';
import { HealthAssistantPage } from './pages/HealthAssistantPage.tsx';
import { MyHealthPage } from './pages/MyHealthPage.tsx';
import { DoctorFinderPage } from './pages/DoctorFinderPage.tsx';
import { PrescriptionsPage } from './pages/PrescriptionsPage.tsx';
import { EmergencyHubPage } from './pages/EmergencyHubPage.tsx';
import { TrafficControlPage } from './pages/TrafficControlPage.tsx';
import { SymptomCheckerPage } from './pages/SymptomCheckerPage.tsx';
import { ProfilePage } from './pages/ProfilePage.tsx';

import { HeartPulse, ShieldCheck, Heart } from 'lucide-react';

function MediMitraApp() {
  const { user, isLoading } = useAuth();
  const { isEasyMode } = useSettings();
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [isDisclaimerOpen, setIsDisclaimerOpen] = useState<boolean>(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState<boolean>(false);
  const [voiceInitialQuery, setVoiceInitialQuery] = useState<string | undefined>(undefined);
  const [preselectedHospitalId, setPreselectedHospitalId] = useState<string | undefined>(undefined);

  const handleOpenVoice = (initialPrompt?: string) => {
    setVoiceInitialQuery(initialPrompt);
    setIsVoiceModalOpen(true);
  };

  const handleSelectHospitalForAmbulance = (hospitalId: string) => {
    setPreselectedHospitalId(hospitalId);
    setActiveTab('emergency');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-bold text-slate-600">Loading MediMitra...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  return (
    <div
      className={`w-full min-h-screen flex flex-col font-sans transition-colors overflow-x-hidden ${
        isEasyMode
          ? 'bg-amber-50/40 text-slate-950 text-base'
          : 'bg-slate-50/70 text-slate-800 text-sm'
      }`}
    >
      {/* 1. Emergency Top Helpline Bar */}
      <EmergencyBanner onOpenSOS={() => setActiveTab('emergency')} />

      {/* 2. Top Navigation Bar with Language & Easy Mode Controls */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenDisclaimer={() => setIsDisclaimerOpen(true)}
        onOpenVoiceAssistant={() => handleOpenVoice()}
      />

      {/* 3. Main Active Content View (Full-width viewport responsive) */}
      <main className="flex-1 w-full mx-auto px-3 sm:px-6 lg:px-10 pt-3 sm:pt-6 pb-24 lg:pb-10">
        {activeTab === 'home' && (
          <HomePage
            onNavigate={(tab) => {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenVoiceModal={(prompt) => handleOpenVoice(prompt)}
          />
        )}

        {activeTab === 'assistant' && (
          <HealthAssistantPage
            onNavigateToEmergency={() => setActiveTab('emergency')}
            onNavigateToDoctors={() => setActiveTab('doctors')}
            onNavigateToMedicines={() => setActiveTab('medicines')}
          />
        )}

        {activeTab === 'health' && <MyHealthPage />}

        {activeTab === 'doctors' && (
          <DoctorFinderPage
            onNavigate={(tab) => setActiveTab(tab)}
            onSelectHospitalForAmbulance={handleSelectHospitalForAmbulance}
          />
        )}

        {activeTab === 'medicines' && <PrescriptionsPage />}

        {activeTab === 'emergency' && (
          <EmergencyHubPage
            onNavigate={(tab) => setActiveTab(tab)}
            selectedHospitalId={preselectedHospitalId}
          />
        )}

        {activeTab === 'traffic' && (
          <TrafficControlPage onNavigate={(tab) => setActiveTab(tab)} />
        )}

        {activeTab === 'symptoms' && (
          <SymptomCheckerPage onNavigate={(tab) => setActiveTab(tab)} />
        )}

        {activeTab === 'profile' && <ProfilePage />}
      </main>

      {/* 4. Global Footer */}
      <footer className="mt-auto bg-white border-t border-slate-200 py-8 px-4 sm:px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <HeartPulse className="w-5 h-5" />
            </div>
            <div>
              <span className="font-extrabold text-slate-900 text-sm">
                Medi<span className="text-blue-600">Mitra</span>
              </span>
              <p className="text-[11px] text-slate-400">
                Your Health. Your Companion. Your Safety.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <button
              onClick={() => setIsDisclaimerOpen(true)}
              className="hover:text-blue-600 underline"
            >
              Medical Disclaimer
            </button>
            <button
              onClick={() => setActiveTab('emergency')}
              className="hover:text-red-600 font-bold"
            >
              Emergency & Smart Traffic Demo
            </button>
            <button
              onClick={() => setActiveTab('profile')}
              className="hover:text-blue-600"
            >
              Profile & Safety
            </button>
          </div>
        </div>

        <div className="max-w-7xl mx-auto mt-4 pt-4 border-t border-slate-100 text-[11px] text-slate-400 text-center sm:text-left leading-relaxed">
          MediMitra is designed strictly for individual users as a personal health companion. It does not diagnose diseases or prescribe or alter medications. In medical emergencies, immediately contact official national emergency lines (108 / 112 / 911). Smart Ambulance Traffic Coordination is an architectural demonstration.
        </div>
      </footer>

      {/* 5. Global Floating Interactive Modals */}
      <VoiceAssistantModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        initialPrompt={voiceInitialQuery}
        onNavigate={(tab) => {
          setIsVoiceModalOpen(false);
          setActiveTab(tab);
        }}
      />

      <MedicineReminderModal />

      <MedicalDisclaimerModal
        isOpen={isDisclaimerOpen}
        onClose={() => setIsDisclaimerOpen(false)}
      />
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <SettingsProvider>
        <MediMitraApp />
      </SettingsProvider>
    </AuthProvider>
  );
}

export default App;
