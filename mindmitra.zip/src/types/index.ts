export interface UserProfile {
  id: string;
  name: string;
  email: string;
  age: number;
  gender: 'male' | 'female' | 'non-binary' | 'prefer-not-to-say';
  bloodGroup: string;
  allergies: string[];
  existingConditions?: string[];
  chronicConditions?: string[];
  address?: string;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  locationConsent: boolean;
  preferredRegion?: string;
  createdAt?: string;
}

export interface AuthResponse {
  user: UserProfile;
  token: string;
}

export interface ChatResponse {
  reply: string;
  disclaimer: string;
  urgencyLevel: 'routine' | 'moderate' | 'emergency';
}

export interface MoodEntry {
  id: string;
  userId: string;
  mood: 'great' | 'good' | 'neutral' | 'anxious' | 'sad' | 'stressed';
  score: number; // 1-5
  stressLevel: number; // 1-10
  emotions: string[];
  journalNote: string;
  date: string;
  timestamp: number;
}

export interface PrescribedMedicine {
  id: string;
  userId: string;
  medicineName: string;
  dosage: string;
  doctorName: string;
  prescriptionDate?: string;
  timing: (string)[];
  instruction: string;
  durationDays: number;
  startDate?: string;
  active?: boolean;
  notes?: string;
  instructionsNotes?: string;
  history: {
    date: string;
    takenAt: string;
    timingSlot: string;
    status: 'taken' | 'skipped';
  }[];
}

export interface WellnessData {
  id: string;
  userId: string;
  date: string;
  sleepHours: number;
  sleepQuality: 'poor' | 'fair' | 'good' | 'excellent';
  waterIntakeMl: number;
  waterTargetMl: number;
  physicalActivityMinutes: number;
  stepsCount: number;
  notes?: string;
}

export interface DoctorOrClinic {
  id: string;
  name: string;
  type: 'Doctor' | 'Clinic' | 'Hospital' | 'Emergency Center';
  specialization: string;
  phone: string;
  address: string;
  city: string;
  distanceKm: number;
  timings: string;
  rating: number;
  isEmergencyFacility: boolean;
  emergencyPhone?: string;
  verifiedDemo: boolean;
  lat: number;
  lng: number;
}

export interface JunctionInfo {
  id: string;
  name: string;
  status: 'cleared' | 'approaching' | 'pending';
  distanceMeters: number;
  trafficLevel: 'green' | 'yellow' | 'red';
  clearedAt?: string;
}

export interface AmbulanceDispatch {
  id: string;
  userId: string;
  patientName: string;
  callerPhone: string;
  status: 'dispatched' | 'en_route' | 'arrived' | 'cancelled';
  origin: {
    lat: number;
    lng: number;
    address: string;
  };
  destinationHospital: {
    id: string;
    name: string;
    address: string;
    phone: string;
    lat: number;
    lng: number;
  };
  currentLocation: {
    lat: number;
    lng: number;
  };
  etaMinutes: number;
  currentJunctionIndex: number;
  junctions: JunctionInfo[];
  routeCoordinates: [number, number][];
  trafficCondition: 'clear' | 'moderate' | 'heavy';
  priority: 'CRITICAL' | 'URGENT';
  alertMessage: string;
  alertAcknowledgedByControl: boolean;
  acknowledgedAt?: string;
  greenCorridorActive: boolean;
  createdAt: string;
}

export interface SymptomAnalysisResult {
  extractedSymptoms: string[];
  duration: string;
  healthCategories: string[];
  urgencyLevel: 'Routine / Home Care' | 'Prompt Doctor Visit' | 'Immediate Emergency Care';
  generalGuidance: string[];
  potentialQuestionsForDoctor: string[];
  medicalDisclaimer: string;
}

export interface HealthAssistantMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  isDisclaimer?: boolean;
  urgencyBadge?: 'routine' | 'moderate' | 'emergency';
}
